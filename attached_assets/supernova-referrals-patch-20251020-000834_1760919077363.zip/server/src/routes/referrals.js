import { Router } from 'express'
import cookieParser from 'cookie-parser'
import { supabaseAdmin as s } from '../integrations/supabase.js'
import crypto from 'crypto'

const r = Router()
r.use(cookieParser())

const BASE = process.env.REFERRALS_PUBLIC_BASE || 'http://localhost:3001'
const COOKIE = 'sn_ref'
const MAX_AGE = 1000*60*60*24*30 // 30 days

function genCode(){
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let s=''; for (let i=0;i<8;i++) s += alphabet[Math.floor(Math.random()*alphabet.length)]
  return s
}

async function ensureAffiliate(email, name){
  const code = genCode()
  const { data:existing } = await s.from('referrals_affiliates').select('*').eq('email', email).maybeSingle()
  if (existing) return existing
  const { data, error } = await s.from('referrals_affiliates').insert({ email, name, code }).select().maybeSingle()
  if (error) throw error
  return data
}

// Redirector with attribution cookie
r.get('/r/:code', async (req, res) => {
  const code = (req.params.code||'').trim().toUpperCase()
  const to = req.query.to ? String(req.query.to) : '/'
  try {
    res.cookie(COOKIE, code, { httpOnly: false, sameSite: 'Lax', maxAge: MAX_AGE, secure: false })
    // record click
    if (s) await s.from('referrals_clicks').insert({ code, ip: req.ip, ua: req.headers['user-agent']||null })
  } catch {}
  res.redirect(to)
})

// Create or get affiliate code
r.post('/api/referrals/affiliate', async (req, res) => {
  try {
    if (!s) return res.status(503).json({ ok:false, error:'supabase not configured' })
    const { email, name } = req.body || {}
    if (!email) return res.status(400).json({ ok:false, error:'email required' })
    const a = await ensureAffiliate(email, name||null)
    const link = `${BASE}/r/${a.code}`
    res.json({ ok:true, affiliate: { ...a, link } })
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message || String(e) })
  }
})

// Record event (signup/purchase). Attribution from cookie or explicit code.
r.post('/api/referrals/event', async (req, res) => {
  try {
    if (!s) return res.status(503).json({ ok:false, error:'supabase not configured' })
    const { event_type, amount_usd, customer_id, code:explicit } = req.body || {}
    let code = explicit || req.cookies[COOKIE] || null
    if (!code) return res.status(200).json({ ok:true, note:'no referral cookie; ignoring' })
    const payload = {
      code: String(code).toUpperCase(),
      event_type: event_type==='purchase' ? 'purchase' : 'signup',
      amount_usd: event_type==='purchase' ? (amount_usd!=null? Number(amount_usd): null) : null,
      customer_id: customer_id || null,
      meta: req.body?.meta || null
    }
    const { error } = await s.from('referrals_events').insert(payload)
    if (error) throw error
    res.json({ ok:true })
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message || String(e) })
  }
})

// Stats rollup
r.get('/api/referrals/stats', async (_req, res) => {
  try {
    if (!s) return res.status(503).json({ ok:false, error:'supabase not configured' })
    const { data, error } = await s.from('referrals_rollup').select('*').order('revenue_usd', { ascending:false })
    if (error) throw error
    res.json({ ok:true, rows: data||[] })
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message || String(e) })
  }
})

// CSV export
r.get('/api/referrals/export.csv', async (_req, res) => {
  try {
    if (!s) return res.status(503).json({ ok:false, error:'supabase not configured' })
    const { data, error } = await s.from('referrals_rollup').select('*')
    if (error) throw error
    const rows = data||[]
    const cols = ['code','email','name','clicks','signups','purchases','revenue_usd','created_at']
    const csv = [cols.join(',')].concat(rows.map(r => cols.map(k => String(r[k] ?? '')).join(','))).join('\n')
    res.setHeader('content-type','text/csv')
    res.setHeader('content-disposition','attachment; filename="referrals.csv"')
    res.send(csv)
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message || String(e) })
  }
})

export default r
