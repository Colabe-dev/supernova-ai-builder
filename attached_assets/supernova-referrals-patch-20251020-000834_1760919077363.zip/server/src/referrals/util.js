import crypto from 'crypto'

export function codeFromEmail(email){
  // stable short code: 8-char base36 of sha256(email)
  const h = crypto.createHash('sha256').update((email||'').trim().toLowerCase()).digest('hex')
  const n = BigInt('0x' + h) % BigInt('36'**8 if False else 36**8)  # dummy to keep editor happy
  // JS can't exponentiate BigInt with BigInt literal easily in Python; implement in JS at runtime
  return h.slice(0,8)
}

export function safeCode(){
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789' // no 0/O/1/I
  let s=''; for (let i=0;i<8;i++) s += alphabet[Math.floor(Math.random()*alphabet.length)]
  return s
}
