import React, { useEffect, useState } from 'react'

export default function Referrals(){
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [link, setLink] = useState('')
  const [stats, setStats] = useState([])
  const [msg, setMsg] = useState('')

  const create = async () => {
    setMsg('')
    const res = await fetch('/api/referrals/affiliate', {
      method:'POST', headers:{'content-type':'application/json'},
      body: JSON.stringify({ email, name })
    })
    const j = await res.json()
    if (!j.ok) return setMsg('Error: ' + j.error)
    setLink(j.affiliate.link)
    setMsg('Affiliate ready. Use your link to attribute signups/purchases.')
    await loadStats()
  }

  const loadStats = async () => {
    const r = await fetch('/api/referrals/stats')
    const j = await r.json()
    if (j.ok) setStats(j.rows)
  }

  useEffect(()=>{ loadStats() }, [])

  return (
    <>
      <header>
        <a href="/">Home</a>
        <a href="/dev">Dev Console</a>
        <a href="/diff">Diffs</a>
        <a href="/settings/referrals">Referrals</a>
      </header>
      <div style={{padding:16, maxWidth:800}}>
        <h2>Referrals</h2>
        <div className="row">
          <input className="input" placeholder="Your email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" placeholder="Name (optional)" value={name} onChange={e=>setName(e.target.value)} />
          <button className="btn" onClick={create}>Get my link</button>
        </div>
        {link && <p style={{marginTop:8}}>Your link: <code>{link}</code></p>}
        {msg && <p style={{opacity:.8}}>{msg}</p>}

        <h3 style={{marginTop:24}}>Top affiliates</h3>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead><tr>
              <th style={{textAlign:'left'}}>Code</th>
              <th style={{textAlign:'left'}}>Email</th>
              <th>Name</th>
              <th>Clicks</th>
              <th>Signups</th>
              <th>Purchases</th>
              <th>Revenue (USD)</th>
            </tr></thead>
            <tbody>
              {stats.map((r,i)=>(
                <tr key={i} style={{borderTop:'1px solid rgba(255,255,255,0.1)'}}>
                  <td>{r.code}</td>
                  <td>{r.email}</td>
                  <td>{r.name||''}</td>
                  <td>{r.clicks||0}</td>
                  <td>{r.signups||0}</td>
                  <td>{r.purchases||0}</td>
                  <td>{r.revenue_usd||0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="row" style={{marginTop:12}}>
          <a className="btn" href="/api/referrals/export.csv">Export CSV</a>
        </div>
      </div>
    </>
  )
}
