-- Referrals / Affiliates schema
create extension if not exists pgcrypto;

create table if not exists public.referrals_affiliates (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  code text unique not null,
  name text,
  payout_account text,     -- e.g., stripe account id or wallet
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists public.referrals_clicks (
  id bigserial primary key,
  code text not null,
  ip text,
  ua text,
  ts timestamptz default now()
);

create table if not exists public.referrals_events (
  id bigserial primary key,
  code text not null,
  event_type text not null check (event_type in ('signup','purchase')),
  amount_usd numeric(10,2),
  customer_id text,
  meta jsonb,
  ts timestamptz default now()
);

-- Optional materialized rollup (refresh manually/cron)
create materialized view if not exists public.referrals_rollup as
select
  a.code,
  a.email,
  a.name,
  a.created_at,
  coalesce(c.clicks,0) as clicks,
  coalesce(s.signups,0) as signups,
  coalesce(p.purchases,0) as purchases,
  coalesce(p.revenue_usd,0) as revenue_usd
from public.referrals_affiliates a
left join (
  select code, count(*) clicks from public.referrals_clicks group by 1
) c on c.code=a.code
left join (
  select code, count(*) signups from public.referrals_events where event_type='signup' group by 1
) s on s.code=a.code
left join (
  select code, count(*) purchases, sum(coalesce(amount_usd,0)) revenue_usd
  from public.referrals_events where event_type='purchase' group by 1
) p on p.code=a.code;

-- No RLS since server uses service role; if you enable RLS, create service policies.
