# Supernova — Referrals Patch
Date: 20251020-000834

This patch adds a neutral **referral/affiliate** system that works with your existing Supabase connection:
- `/r/:code` link redirection + cookie attribution (30d).
- `/api/referrals/affiliate` create/manage affiliate codes.
- `/api/referrals/event` record events (`signup` / `purchase` with amount).
- `/api/referrals/stats` rollups; `/api/referrals/export.csv` for payouts.
- Simple UI at `/settings/referrals`.

**Requirements**
- Server has `@supabase/supabase-js` configured (from the Supabase patch).
- Set `REFERRALS_PUBLIC_BASE` (optional, defaults to `http://localhost:3001`).

**Install**
1) Copy files.
2) `cd server && npm i cookie-parser`
3) Restart server and client.

**SQL**
Apply `sql/referrals.sql` in Supabase SQL editor.
