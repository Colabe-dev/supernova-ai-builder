# S4 — Security Pro Overlay (JWKS + Redis Rate Limiting)

**What this adds**
- **JWKS-based JWT verification** with key rotation (RS256/ES256) using `jose`.
- **JWKS publisher** (self-hosted): `GET /auth/.well-known/jwks.json`.
- **Key generator**: `tools/gen-jwks.mjs` (creates new RSA key, updates JWKS).
- **Redis-backed rate limiter** (fixed window) with graceful in-memory fallback.
- **Secured routes** sample for entitlements: `routes.db.secpro.js`.

## Install
```bash
npm i jose ioredis
```

## Env
```
# Auth (verifier)
AUTH_JWKS_URL=https://<your-domain>/auth/.well-known/jwks.json   # or external IdP
AUTH_ISSUER=https://collab.supernova.auth
AUTH_AUDIENCE=supernova-api
DEV_AUTH_OPEN=false

# JWKS publisher (only if self-hosting keys)
JWKS_DIR=server/auth/jwks/keys

# Redis
REDIS_URL=redis://localhost:6379
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_READ_MAX=120
RATE_LIMIT_WRITE_MAX=30
RATE_LIMIT_WEBHOOK_MAX=1200
```

## Wire (server)
```js
// server/index.js
import jwksRouter from './auth/jwks/publish.js';     // optional (if self-hosted keys)
app.use('/auth', jwksRouter);

import { parseAuthJwks, requireAuth } from './auth/verify.js';
import { rateLimit } from './rateLimit/index.js';

// Example: secure entitlements routes (Postgres variant)
import entitlementsRoutes from './entitlements/routes.db.secpro.js';
app.use('/api', entitlementsRoutes);
```

## Key rotation
```bash
node tools/gen-jwks.mjs              # generates new key under JWKS_DIR and updates jwks.json
git add server/auth/jwks/keys && git commit -m "rotate jwks"
```
