#!/usr/bin/env node
import { generateKeyPairSync, createPublicKey } from 'crypto';
import fs from 'fs'; import path from 'path';
import { createHash } from 'crypto';

const JWKS_DIR = process.env.JWKS_DIR || path.join(process.cwd(), 'server', 'auth', 'jwks', 'keys');
fs.mkdirSync(JWKS_DIR, { recursive: true });

function thumbprintPem(pem){
  const pub = createPublicKey(pem).export({ type: 'spki', format: 'der' });
  return createHash('sha256').update(pub).digest('base64url').slice(0,16);
}

const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const privPem = privateKey.export({ type: 'pkcs1', format: 'pem' });
const pubPem = publicKey.export({ type: 'spki', format: 'pem' });

const kid = thumbprintPem(pubPem);
const now = new Date().toISOString().replace(/[:.]/g,'-');
const dir = path.join(JWKS_DIR, kid);
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'private.pem'), privPem);
fs.writeFileSync(path.join(dir, 'public.pem'), pubPem);

function pemToJwk(pem){
  // Minimal RSA JWK (n,e) from PEM
  const { KeyObject } = await import('crypto'); // not available here; fallback simple
}
/* Simpler approach: rely on jose to convert, but to avoid dependency here,
   we embed a minimal JWK with "x5c" omitted. We'll keep jwks.json as pointers to pub PEM.
   Many verifiers require n/e; since our verifier fetches remote JWKS, we will store n/e using jose at runtime.
*/

import * as jose from 'jose';
const jwk = await jose.exportJWK(publicKey);
jwk.kid = kid; jwk.kty = 'RSA'; jwk.use = 'sig'; jwk.alg = 'RS256';

const jwksPath = path.join(JWKS_DIR, 'jwks.json');
let jwks = { keys: [] };
try { jwks = JSON.parse(fs.readFileSync(jwksPath,'utf8')); } catch {}

jwks.keys = [jwk, ...(jwks.keys || []).filter(k => k.kid !== kid)];
fs.writeFileSync(jwksPath, JSON.stringify(jwks, null, 2));
console.log('Generated key kid=', kid, 'and updated', jwksPath);
