import Redis from 'ioredis';

let client;
export function getRedis(){
  if (client) return client;
  const url = process.env.REDIS_URL;
  if (!url) return null;
  client = new Redis(url, { maxRetriesPerRequest: 1, enableOfflineQueue: false });
  client.on('error', () => {});
  return client;
}

export function rateLimitRedis({ windowMs = 60_000, max = 60, keyFn } = {}){
  const redis = getRedis();
  if (!redis) return null;

  return async (req, res, next) => {
    try {
      const key = (keyFn ? keyFn(req) : req.ip) || 'global';
      const bucket = `rl:${key}`;
      const ttl = Math.max(1, Math.floor(windowMs / 1000));

      const multi = redis.multi();
      multi.incr(bucket);
      multi.expire(bucket, ttl, 'NX'); // set expire only if not existing
      const [count] = await multi.exec().then(results => results.map(r => r[1]));

      if (Number(count) > max) {
        res.setHeader('Retry-After', String(ttl));
        return res.status(429).json({ error: 'rate_limited', retryAfter: ttl });
      }
      next();
    } catch (_e) {
      next(); // fail-open
    }
  };
}
