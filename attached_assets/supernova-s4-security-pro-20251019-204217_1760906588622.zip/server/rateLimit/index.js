import { rateLimitRedis, getRedis } from './redis.js';

const buckets = new Map();
function memoryLimit({ windowMs = 60_000, max = 60, keyFn } = {}){
  return (req, res, next) => {
    const now = Date.now();
    const key = (keyFn ? keyFn(req) : req.ip) || 'global';
    let b = buckets.get(key);
    if (!b || b.resetAt < now) {
      b = { count: 0, resetAt: now + windowMs };
      buckets.set(key, b);
    }
    b.count += 1;
    if (b.count > max) {
      const retry = Math.max(0, Math.ceil((b.resetAt - now)/1000));
      res.setHeader('Retry-After', String(retry));
      return res.status(429).json({ error: 'rate_limited', retryAfter: retry });
    }
    next();
  };
}

export function rateLimit(opts){
  const redis = getRedis();
  const r = rateLimitRedis(opts);
  return r || memoryLimit(opts);
}
