# S4 — Entitlements Prisma Overlay

Typed data layer for entitlements using Prisma. Maps to existing tables created earlier (`ent_*`), no schema rewrite required.

## Install
```bash
npm i @prisma/client
npm i -D prisma
npx prisma generate
```

> If you don't have the DB tables yet, run the SQL migrations from the Entitlements DB overlay first, or do `npx prisma db pull` to introspect.

## Wire
- Use the provided routes or call the data layer directly.
- To combine with Security overlay, import from `server/auth/jwt.js` and `server/rateLimit/memory.js`.
