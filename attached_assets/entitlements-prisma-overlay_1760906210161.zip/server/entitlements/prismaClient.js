import { PrismaClient } from '@prisma/client';
export const prisma = new PrismaClient();

export async function getEntitlements(profileId){
  const [bal, subs] = await Promise.all([
    prisma.coinsBalance.findUnique({ where: { profileId } }),
    prisma.subscription.findMany({ where: { profileId, status: 'active' } })
  ]);
  return { coins: Number((bal?.balance ?? 0)), subscriptions: subs };
}

export async function grantCoins(profileId, amount, reason, source, externalRef){
  const amt = BigInt(Number(amount));
  return await prisma.$transaction(async (tx) => {
    if (externalRef) {
      const exists = await tx.coinsLedger.findFirst({ where: { externalRef } });
      if (exists) {
        const b = await tx.coinsBalance.findUnique({ where: { profileId } });
        return { id: exists.id, balance: Number(b?.balance ?? 0), duplicate: true };
      }
    }
    const ins = await tx.coinsLedger.create({ data: { profileId, amount: amt, reason, source, externalRef } });
    await tx.coinsBalance.upsert({
      where: { profileId },
      update: { balance: { increment: amt } },
      create: { profileId, balance: amt }
    });
    const b = await tx.coinsBalance.findUnique({ where: { profileId } });
    return { id: ins.id, balance: Number(b?.balance ?? 0) };
  });
}

export async function activateSubscription(profileId, plan, source){
  return await prisma.subscription.upsert({
    where: { profileId_plan: { profileId, plan } },
    update: { status: 'active', renewedAt: new Date(), cancelledAt: null, source },
    create: { profileId, plan, status: 'active', source }
  });
}

export async function cancelSubscription(profileId, plan, source){
  return await prisma.subscription.update({
    where: { profileId_plan: { profileId, plan } },
    data: { status: 'cancelled', cancelledAt: new Date(), source }
  }).catch(() => null);
}
