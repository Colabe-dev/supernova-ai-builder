import { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { supabaseAdmin as s } from '../integrations/supabase.js'
import crypto from 'crypto'
import bcrypt from 'bcryptjs'
const r = Router()
const rl = rateLimit({ windowMs: 60_000, limit: 120 })

r.post('/api/rooms/:id/shares', rl, async (req,res)=>{
  const { can_write=false, expires_at=null, created_by=null } = req.body||{}
  const raw = 'snr_' + crypto.randomBytes(24).toString('base64url')
  const last4 = raw.slice(-4)
  const token_hint = raw.slice(0,8)
  const token_hash = await bcrypt.hash(raw, 12)
  const { data, error } = await s.from('room_shares').insert({ room_id:req.params.id, token_hash, token_hint, last4, can_write, expires_at, created_by }).select('id,last4,can_write,expires_at').maybeSingle()
  if (error) return res.status(500).json({ok:false,error:error.message})
  const origin = (req.headers['x-forwarded-proto'] ? req.headers['x-forwarded-proto'] : req.protocol) + '://' + req.get('host')
  res.json({ ok:true, id:data.id, last4:data.last4, link: `${origin}/r/${raw}`, can_write:data.can_write, expires_at:data.expires_at })
})

r.get('/api/rooms/:id/shares', rl, async (req,res)=>{
  const { data, error } = await s.from('room_shares').select('id,last4,can_write,expires_at,created_at,revoked_at').eq('room_id', req.params.id).order('created_at',{ascending:false})
  if (error) return res.status(500).json({ok:false,error:error.message})
  res.json({ ok:true, shares:data })
})

r.delete('/api/rooms/:id/shares/:sid', rl, async (req,res)=>{
  const { error } = await s.from('room_shares').update({ revoked_at: new Date().toISOString() }).eq('id', req.params.sid)
  if (error) return res.status(500).json({ok:false,error:error.message})
  res.json({ ok:true })
})

r.get('/api/rooms/share/:token/messages', rl, async (req,res)=>{
  const token = req.params.token
  if (!token || token.length < 16) return res.status(400).json({ ok:false, error:'invalid token' })
  const hint = token.slice(0,8)
  const { data: candidates, error } = await s.from('room_shares').select('id,room_id,token_hash,can_write,expires_at,revoked_at').eq('token_hint', hint).limit(20)
  if (error) return res.status(500).json({ok:false,error:error.message})
  let match = null
  for (const row of candidates||[]) {
    const ok = await bcrypt.compare(token, row.token_hash).catch(()=>false)
    if (ok) { match = row; break }
  }
  if (!match) return res.status(404).json({ok:false,error:'not found'})
  if (match.revoked_at) return res.status(403).json({ok:false,error:'revoked'})
  if (match.expires_at && new Date(match.expires_at) < new Date()) return res.status(403).json({ok:false,error:'expired'})
  const { data: room } = await s.from('rooms').select('id,name,created_at').eq('id', match.room_id).maybeSingle()
  const { data: messages } = await s.from('room_messages').select('role,type,text,payload,ts').eq('room_id', match.room_id).order('ts',{ascending:true}).limit(2000)
  res.json({ ok:true, room, messages })
})

r.get('/api/rooms/:id/export.md', rl, async (req,res)=>{
  const { data: room } = await s.from('rooms').select('id,name,created_at').eq('id', req.params.id).maybeSingle()
  const { data: messages } = await s.from('room_messages').select('role,type,text,payload,ts').eq('room_id', req.params.id).order('ts',{ascending:true}).limit(5000)
  const lines = []
  lines.push(`# Room: ${room?.name || req.params.id}`)
  lines.push('')
  for (const m of (messages||[])) {
    const ts = new Date(m.ts).toISOString()
    lines.push(`- **${m.role||m.type||'note'}** · ${ts}`)
    const body = (m.text || m.payload?.text || m.payload?.stderr || m.payload?.stdout || '')
    if (body) lines.push('\n```\n'+String(body).slice(0,8000)+'\n```\n')
  }
  const md = lines.join('\n')
  res.setHeader('content-type','text/markdown; charset=utf-8')
  res.setHeader('content-disposition', `attachment; filename="room-${req.params.id}.md"`)
  res.send(md)
})

export default r
