import React, { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import '../styles/workbench.css'

export default function SharedRoom(){
  const { token } = useParams()
  const [state, setState] = useState({ loading:true, error:'', room:null, messages:[] })
  const logRef = useRef(null)

  useEffect(()=>{
    ;(async()=>{
      try{
        const r = await fetch('/api/rooms/share/' + encodeURIComponent(token) + '/messages')
        const j = await r.json()
        if (!j.ok) throw new Error(j.error || 'error')
        setState({ loading:false, error:'', room: j.room, messages: j.messages })
      }catch(e){
        setState({ loading:false, error:String(e.message||e), room:null, messages:[] })
      }
    })()
  }, [token])

  useEffect(()=>{
    if (!logRef.current) return
    logRef.current.scrollTop = logRef.current.scrollHeight
  }, [state.messages])

  if (state.loading) return <div style={{padding:16}}>Loading…</div>
  if (state.error) return <div style={{padding:16, color:'#ffb3b3'}}>Error: {state.error}</div>

  return (
    <div style={{padding:16}}>
      <h2>Shared Room — {state.room?.name}</h2>
      <div className="chat-embed" style={{height:'70vh'}}>
        <div className="log" ref={logRef}>
          {state.messages.map((m,i)=>(
            <div key={i} className={'msg ' + (m.role==='user'?'user':m.type==='tool_result'?'tool':'')}>
              <div style={{opacity:.7, fontSize:12}}>{m.role || m.type} · {new Date(m.ts).toLocaleString()}</div>
              {m.text && <div>{m.text}</div>}
              {m.payload?.stdout && <pre style={{whiteSpace:'pre-wrap'}}>{m.payload.stdout}</pre>}
              {m.payload?.stderr && <pre style={{whiteSpace:'pre-wrap', color:'#ffb3b3'}}>{m.payload.stderr}</pre>}
              {m.payload?.diff && <pre style={{whiteSpace:'pre-wrap'}}>{m.payload.diff}</pre>}
            </div>
          ))}
        </div>
        <div className="composer">
          <div style={{opacity:.7}}>Read-only shared view</div>
        </div>
      </div>
    </div>
  )
}
