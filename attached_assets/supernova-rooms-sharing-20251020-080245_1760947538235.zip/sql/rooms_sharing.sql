create table if not exists public.room_shares (
  id bigserial primary key,
  room_id uuid not null references public.rooms(id) on delete cascade,
  token_hash text not null,
  token_hint text not null,
  last4 text not null,
  can_write boolean default false,
  expires_at timestamptz,
  created_by uuid,
  created_at timestamptz default now(),
  revoked_at timestamptz
);
create index if not exists room_shares_hint_idx on public.room_shares(token_hint);
create index if not exists room_shares_room_idx on public.room_shares(room_id);
