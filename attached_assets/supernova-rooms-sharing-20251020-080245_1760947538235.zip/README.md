# Rooms Sharing
Date: 20251020-080245

- Share links (bcrypt hashed, revocable, optional expiry)
- Read-only shared page `/r/:token`
- Export Markdown

## Apply
```bash
unzip supernova-rooms-sharing-20251020-080245.zip -d .
psql < sql/rooms_sharing.sql

git apply patches/0001-server-index-mount-roomshare.patch || echo "merge server/index.js manually"
git apply patches/0002-client-rooms-sidebar-share-ui.patch || echo "merge RoomsSidebar.jsx manually"
git apply patches/0003-client-route-shared-room.patch || echo "merge main.jsx manually"

cd server && npm i bcryptjs && npm run dev
cd ../client && npm run dev
```
