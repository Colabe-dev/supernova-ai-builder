import { openDB } from 'idb';

export async function db() {
  return openDB('ai-notes', 1, {
    upgrade(db) {
      db.createObjectStore('notes', { keyPath: 'id' });
      db.createObjectStore('queue', { keyPath: 'id', autoIncrement: true });
    }
  });
}

export async function saveLocal(note: any) {
  const d = await db();
  await d.put('notes', note);
}

export async function getLocal(id: string) {
  const d = await db();
  return d.get('notes', id);
}

export async function listLocal() {
  const d = await db();
  return d.getAll('notes');
}
