type Headers = Record<string, string>;

export class ColabeServerClient {
  constructor(private opts: { token?: string } = {}) {}

  private base(name: string) {
    const url = process.env[name];
    return url && url.trim().length ? url : null;
  }

  private headers(): Headers {
    const h: Headers = { 'Content-Type': 'application/json' };
    if (this.opts.token) h['Authorization'] = `Bearer ${this.opts.token}`;
    return h;
  }

  async get(baseEnv: string, path: string) {
    const base = this.base(baseEnv);
    if (!base) return { ok: true, offline: true, data: null };
    const res = await fetch(`${base}${path}`, { headers: this.headers(), cache: 'no-store' });
    return { ok: res.ok, data: await res.json().catch(()=>null) };
  }

  async post(baseEnv: string, path: string, body: any) {
    const base = this.base(baseEnv);
    if (!base) return { ok: true, offline: true, data: null };
    const res = await fetch(`${base}${path}`, { method: 'POST', headers: this.headers(), body: JSON.stringify(body) });
    return { ok: res.ok, data: await res.json().catch(()=>null) };
  }
}
