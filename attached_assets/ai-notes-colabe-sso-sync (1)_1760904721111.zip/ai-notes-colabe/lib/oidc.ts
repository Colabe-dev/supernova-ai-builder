import { createRemoteJWKSet, jwtVerify } from 'jose';

export async function discover(issuer:string) {
  const res = await fetch(`${issuer.replace(/\/$/,'')}/.well-known/openid-configuration`, { cache: 'no-store' });
  if (!res.ok) throw new Error('OIDC discovery failed');
  return res.json() as Promise<{ authorization_endpoint:string; token_endpoint:string; jwks_uri:string; }>
}

export async function exchangeToken(tokenEndpoint:string, clientId:string, clientSecret:string, code:string, redirectUri:string, codeVerifier:string) {
  const body = new URLSearchParams();
  body.set('grant_type','authorization_code');
  body.set('client_id', clientId);
  body.set('client_secret', clientSecret);
  body.set('code', code);
  body.set('redirect_uri', redirectUri);
  body.set('code_verifier', codeVerifier);
  const res = await fetch(tokenEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
  if (!res.ok) throw new Error('Token exchange failed');
  return res.json();
}

export async function verifyJwt(jwksUri:string, token:string, audience?:string, issuer?:string) {
  const JWKS = createRemoteJWKSet(new URL(jwksUri));
  const { payload } = await jwtVerify(token, JWKS, { audience, issuer });
  return payload;
}
