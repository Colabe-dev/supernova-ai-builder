import { supabase } from './supabaseClient';
import { db } from './idb';

/** Simple line-based merge that prefers the most-recent edit, but keeps unique lines from both sides */
export function mergeContent(base: string, local: string, remote: string) {
  if (remote === base) return local;
  if (local === base) return remote;
  const baseSet = new Set(base.split('\n'));
  const localLines = local.split('\n');
  const remoteLines = remote.split('\n');
  const out: string[] = [];
  const seen = new Set<string>();
  function push(line:string) {
    if (seen.has(line)) return;
    seen.add(line);
    out.push(line);
  }
  // keep order: take remote, then local, preserving new lines not in base
  for (const l of remoteLines) if (!baseSet.has(l)) push(l);
  for (const l of localLines) if (!baseSet.has(l)) push(l);
  // finally add common baseline if nothing merged
  if (out.length === 0) return local; // fallback
  return out.join('\n');
}

export async function enqueue(note:any) {
  const d = await db();
  await d.add('queue', { id: Date.now(), kind: 'note-upsert', payload: note });
}

export async function flushQueue() {
  const d = await db();
  const items = await d.getAll('queue');
  for (const it of items) {
    if (it.kind === 'note-upsert') {
      await supabase.from('notes').upsert(it.payload, { onConflict: 'id' });
    }
    await d.delete('queue', it.id);
  }
}

/** Sync a single note: attempt merge if changed remotely */
export async function syncNote(note:any) {
  const { data } = await supabase.from('notes').select('*').eq('id', note.id).single();
  if (!data) {
    try { await supabase.from('notes').insert(note); } catch { await enqueue(note); }
    return note;
  }
  // compare timestamps
  const localTime = new Date(note.updated_at || note.created_at).getTime();
  const remoteTime = new Date(data.updated_at || data.created_at).getTime();
  if (localTime >= remoteTime) {
    try { await supabase.from('notes').upsert(note, { onConflict: 'id' }); }
    catch { await enqueue(note); }
    return note;
  } else {
    // remote is newer; merge
    const merged = {
      ...note,
      content: mergeContent(data.content || '', note.content || '', data.content || ''),
      title: data.title || note.title,
      updated_at: new Date().toISOString()
    };
    try { await supabase.from('notes').upsert(merged, { onConflict: 'id' }); }
    catch { await enqueue(merged); }
    return merged;
  }
}
