export type ServiceId = 'chat'|'automations'|'images'|'analytics'|'docs'|'payments';
export type OAuthConfig = {
  issuer: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
};

function env(name:string) { return process.env[name] || ''; }

export function serviceOAuthEnv(service: ServiceId): OAuthConfig | null {
  const key = service.toUpperCase();
  const issuer = env(`COLABE_${key}_OAUTH_ISSUER`);
  const clientId = env(`COLABE_${key}_OAUTH_CLIENT_ID`);
  const clientSecret = env(`COLABE_${key}_OAUTH_CLIENT_SECRET`);
  const base = env('COLABE_OAUTH_REDIRECT_BASE') || env('NEXT_PUBLIC_APP_URL') || 'http://localhost:3000';
  const redirectUri = `${base}/api/colabe/oauth/callback?service=${service}`;
  if (!issuer || !clientId || !clientSecret) return null;
  return { issuer, clientId, clientSecret, redirectUri };
}

export function wellKnown(issuer:string) {
  return `${issuer.replace(/\/$/,'')}/.well-known/openid-configuration`;
}
