'use client';
import { useState } from 'react';
import { callAI } from '@/lib/ai';

export function AICommandBar({ getText, setText }:{ getText:()=>string; setText:(v:string)=>void }) {
  const [loading, setLoading] = useState<string | null>(null);

  async function run(kind:string, extras:any={}) {
    try {
      setLoading(kind);
      const res = await callAI(kind, { text: getText(), ...extras });
      if (res.text) setText(res.text);
      if (res.mermaid) setText(getText() + '\n```mermaid\n' + res.mermaid + '\n```\n');
    } finally {
      setLoading(null);
    }
  }

  return (
    <div className="flex flex-wrap gap-2">
      <button onClick={()=>run('structure')} className="px-3 py-1 rounded-lg bg-brand/20 hover:bg-brand/30">Structure</button>
      <button onClick={()=>run('summarize')} className="px-3 py-1 rounded-lg bg-brand/20 hover:bg-brand/30">Summarize</button>
      <button onClick={()=>run('translate', { to: 'es' })} className="px-3 py-1 rounded-lg bg-brand/20 hover:bg-brand/30">Translate → ES</button>
      <button onClick={()=>run('diagram')} className="px-3 py-1 rounded-lg bg-brand/20 hover:bg-brand/30">Auto Diagram</button>
      <button onClick={()=>run('codegen', { lang: 'python' })} className="px-3 py-1 rounded-lg bg-brand/20 hover:bg-brand/30">Code from Notes</button>
      <span className="text-xs opacity-70 ml-2">{loading ? `Running ${loading}…` : ''}</span>
    </div>
  );
}
