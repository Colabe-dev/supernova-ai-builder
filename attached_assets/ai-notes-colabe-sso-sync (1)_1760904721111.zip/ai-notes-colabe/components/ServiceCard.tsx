'use client';
import Link from 'next/link';

export default function ServiceCard({ svc, onConnect }:{ svc: any; onConnect:(id:string)=>void }) {
  const configured = !!svc.baseUrl;
  return (
    <div className="neon-card p-4 flex flex-col gap-2">
      <div className="font-semibold">{svc.name}</div>
      <div className="text-xs opacity-70 break-all">{configured ? svc.baseUrl : 'Not configured'}</div>
      <div className="flex gap-2 mt-2">
        <button
          onClick={()=>onConnect(svc.id)}
          className="px-3 py-1 rounded-lg bg-brand/30 hover:bg-brand/40 text-sm"
        >
          {configured ? 'Link workspace' : 'Configure URL first'}
        </button>
        {svc.docs && <Link href={svc.docs} target="_blank" className="px-3 py-1 rounded-lg border border-white/10 text-sm">Docs</Link>}
      </div>
    </div>
  );
}
