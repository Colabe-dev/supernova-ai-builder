'use client';
import { useState } from 'react';

export default function ExportPanel({ title, getContent, getPreviewSelector }:{ title:()=>string; getContent:()=>string; getPreviewSelector:()=>string }) {
  const [busy, setBusy] = useState<string>('');

  async function call(path:string, type:'blob'|'text'='blob') {
    setBusy(path);
    const res = await fetch(`/api/exports/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: title(), content: getContent() })
    });
    if (!res.ok) { setBusy(''); alert('Export failed'); return; }
    if (type === 'text') {
      const text = await res.text();
      download(`${title().replace(/[^a-z0-9-_]+/gi,'_')}.${path === 'markdown' ? 'md' : 'txt'}`, new Blob([text]));
    } else {
      const blob = await res.blob();
      const fname = path === 'html' ? 'html' : path;
      download(`${title().replace(/[^a-z0-9-_]+/gi,'_')}.${fname}`, blob);
    }
    setBusy('');
  }

  function download(filename:string, blob:Blob) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href), 5000);
  }

  async function exportPNG() {
    setBusy('png');
    const sel = getPreviewSelector();
    const node = document.querySelector(sel) as HTMLElement | null;
    if (!node) { setBusy(''); return alert('Preview not found'); }
    const { toPng } = await import('html-to-image');
    const dataUrl = await toPng(node, { pixelRatio: 2 });
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    download(`${title().replace(/[^a-z0-9-_]+/gi,'_')}.png`, blob);
    setBusy('');
  }

  return (
    <div className="neon-card p-3 mt-3">
      <div className="text-sm opacity-70 mb-2">Export</div>
      <div className="flex flex-wrap gap-2">
        <button onClick={()=>call('html')} className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20">HTML</button>
        <button onClick={()=>call('markdown')} className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20">Markdown</button>
        <button onClick={()=>call('pdf')} className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20">PDF</button>
        <button onClick={()=>call('docx')} className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20">DOCX</button>
        <button onClick={exportPNG} className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20">PNG (preview)</button>
        <span className="text-xs opacity-60">{busy ? `Exporting ${busy}…` : ''}</span>
      </div>
    </div>
  );
}
