'use client';
import { useWorkspace } from '@/contexts/WorkspaceContext';

export default function WorkspaceSwitcher() {
  const { workspaceId, setWorkspaceId, workspaces } = useWorkspace();
  if (!workspaces?.length) return null;
  return (
    <select
      value={workspaceId || ''}
      onChange={(e)=>setWorkspaceId(e.target.value)}
      className="bg-black/30 border border-white/10 rounded-lg px-2 py-1 text-sm"
      title="Workspace"
    >
      {workspaces.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
    </select>
  );
}
