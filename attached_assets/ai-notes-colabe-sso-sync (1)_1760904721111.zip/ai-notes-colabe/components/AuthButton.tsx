'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import Link from 'next/link';

export function AuthButton() {
  const [user, setUser] = useState<any>(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user || null));
    return () => sub.subscription.unsubscribe();
  }, []);
  if (!user) return <Link href="/auth" className="text-sm hover:underline">Sign in</Link>;
  return (
    <div className="flex items-center gap-2 text-sm">
      <span className="opacity-80">{user.email}</span>
      <button onClick={()=>supabase.auth.signOut()} className="underline">Sign out</button>
    </div>
  );
}
