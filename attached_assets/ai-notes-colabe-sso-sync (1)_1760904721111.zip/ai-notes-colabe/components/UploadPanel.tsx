'use client';
import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useWorkspace } from '@/contexts/WorkspaceContext';

export default function UploadPanel({ noteId }:{ noteId:string }) {
  const { workspaceId } = useWorkspace();
  const [files, setFiles] = useState<any[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const bucket = 'notes-files';
  const basePath = `${workspaceId || 'personal'}/notes/${noteId}`;

  async function list() {
    const { data, error } = await supabase.storage.from(bucket).list(basePath, { limit: 100 });
    setFiles(data || []);
  }

  useEffect(() => { list(); }, [workspaceId, noteId]);

  async function upload(e:any) {
    const f = e.target.files?.[0];
    if (!f) return;
    const path = `${basePath}/${Date.now()}-${f.name}`;
    const { error } = await supabase.storage.from(bucket).upload(path, f, { upsert: true });
    if (error) alert(error.message);
    list();
    if (inputRef.current) inputRef.current.value='';
  }

  async function download(name:string) {
    const { data } = await supabase.storage.from(bucket).download(`${basePath}/${name}`);
    if (!data) return;
    const url = URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 2500);
  }

  return (
    <div className="neon-card p-3">
      <div className="text-sm opacity-70 mb-2">Attachments</div>
      <div className="flex items-center gap-2">
        <input ref={inputRef} type="file" onChange={upload} className="text-sm" />
      </div>
      <ul className="mt-3 space-y-2">
        {files.map(f => (
          <li key={f.name} className="flex items-center justify-between bg-black/30 p-2 rounded-lg">
            <span className="text-sm break-all">{f.name}</span>
            <button onClick={()=>download(f.name)} className="px-2 py-1 rounded-lg bg-white/10 text-xs">Download</button>
          </li>
        ))}
        {files.length===0 && <div className="text-xs opacity-60">No files yet.</div>}
      </ul>
      <div className="text-[11px] opacity-60 mt-2">Create Supabase Storage bucket <code>{bucket}</code> (public or with RLS).</div>
    </div>
  );
}
