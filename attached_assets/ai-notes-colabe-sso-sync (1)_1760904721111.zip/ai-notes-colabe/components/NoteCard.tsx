import Link from 'next/link';

export function NoteCard({ note }:{ note: any }) {
  return (
    <Link href={`/notes/${note.id}`} className="neon-card p-4 block hover:scale-[1.01] transition">
      <div className="text-xs opacity-60">{new Date(note.updated_at || note.created_at).toLocaleString()}</div>
      <div className="font-semibold mt-1">{note.title || 'Untitled'}</div>
      <p className="opacity-70 line-clamp-2 mt-2">{note.summary || ''}</p>
    </Link>
  );
}
