'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function NoteAccessPanel({ noteId }:{ noteId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('viewer');

  async function refresh() {
    const { data } = await supabase.from('note_acl').select('user_id, role');
    setRows(data || []);
  }
  useEffect(() => { refresh(); }, [noteId]);

  async function grant() {
    // Look up user by email: requires a public "profiles" view mapping to auth.users (you can add it later). For MVP, accept raw UUID in email field.
    const user_id = email.trim();
    const res = await fetch('/api/notes/acl/grant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ note_id: noteId, user_id, role }) });
    if (!res.ok) return alert(await res.text());
    setEmail('');
    refresh();
  }

  async function revoke(user_id:string) {
    const res = await fetch('/api/notes/acl/revoke', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ note_id: noteId, user_id }) });
    if (!res.ok) return alert(await res.text());
    refresh();
  }

  return (
    <div className="neon-card p-3">
      <div className="text-sm opacity-70 mb-2">Per-note access</div>
      <div className="flex flex-wrap items-center gap-2">
        <input className="bg-black/30 p-2 rounded-lg border border-white/10" placeholder="user UUID (MVP)" value={email} onChange={(e)=>setEmail(e.target.value)} />
        <select className="bg-black/30 p-2 rounded-lg border border-white/10" value={role} onChange={(e)=>setRole(e.target.value)}>
          <option value="viewer">viewer</option>
          <option value="editor">editor</option>
          <option value="owner">owner</option>
        </select>
        <button onClick={grant} className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20">Grant</button>
      </div>
      <ul className="mt-3 space-y-2">
        {rows.map(r => (
          <li key={r.user_id} className="flex items-center justify-between bg-black/30 p-2 rounded-lg">
            <span className="text-sm">{r.user_id}</span>
            <span className="text-xs opacity-70">{r.role}</span>
            <button onClick={()=>revoke(r.user_id)} className="px-2 py-1 rounded-lg bg-white/10 text-xs">Revoke</button>
          </li>
        ))}
        {rows.length===0 && <div className="text-xs opacity-60">No extra access granted.</div>}
      </ul>
      <div className="text-[11px] opacity-60 mt-2">Tip: add a public `profiles` view to show emails instead of UUIDs.</div>
    </div>
  );
}
