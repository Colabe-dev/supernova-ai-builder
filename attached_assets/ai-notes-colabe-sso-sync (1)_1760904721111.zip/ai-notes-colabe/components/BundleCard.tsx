'use client';
export default function BundleCard({ plan, onBuy }:{ plan:any; onBuy:(id:string)=>void }) {
  return (
    <div className="neon-card p-4 flex flex-col gap-2">
      <div className="font-semibold">{plan.name}</div>
      <div className="text-sm opacity-80">{plan.description}</div>
      <div className="text-xs opacity-60">Includes: {plan.services.join(', ')}</div>
      <div className="text-lg font-bold mt-2">{Intl.NumberFormat(undefined, { style:'currency', currency: plan.currency || 'EUR' }).format((plan.price_cents || 0)/100)}</div>
      <button onClick={()=>onBuy(plan.id)} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40 mt-1">Activate</button>
    </div>
  );
}
