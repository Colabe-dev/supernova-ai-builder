'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { marked } from 'marked';
import mermaid from 'mermaid';
import { AICommandBar } from './AICommandBar';
import { saveLocal } from '@/lib/idb';

marked.use({
  breaks: true,
  mangle: false,
  headerIds: false
});

export default function Editor({ note, onSave }:{ note:any; onSave:(n:any)=>void }) {
  const [text, setText] = useState<string>(note.content || '');
  const [title, setTitle] = useState<string>(note.title || '');
  const previewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setInterval(() => {
      const updated = { ...note, title, content: text, updated_at: new Date().toISOString() };
      onSave(updated);
      saveLocal(updated);
    }, 1200);
    return () => clearInterval(t);
  }, [text, title]);

  useEffect(() => { mermaid.initialize({ startOnLoad: false, theme: 'dark' }); }, []);

  useEffect(() => {
    if (!previewRef.current) return;
    previewRef.current.innerHTML = marked.parse(text) as string;
    previewRef.current.querySelectorAll('.language-mermaid, code.language-mermaid').forEach((el) => {
      const code = el.textContent || '';
      const container = document.createElement('div');
      container.className = 'mermaid';
      el.parentElement?.replaceWith(container);
      mermaid.render('m' + Math.random().toString(36).slice(2), code, (svgCode) => {
        container.innerHTML = svgCode;
      });
    });
  }, [text]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="neon-card p-4 flex flex-col">
        <input
          className="mb-3 bg-black/30 border border-white/10 rounded-lg px-3 py-2 outline-none"
          placeholder="Title"
          value={title}
          onChange={(e)=>setTitle(e.target.value)}
        />
        <AICommandBar getText={()=>text} setText={setText} />
        <textarea
          className="mt-3 grow bg-black/30 border border-white/10 rounded-lg p-3 font-mono text-sm outline-none"
          placeholder="Write in Markdown. Add ```mermaid for diagrams."
          value={text}
          onChange={(e)=>setText(e.target.value)}
        />
        <div className="text-xs opacity-60 mt-2">Autosaving locally & remotely…</div>
      </div>
      <div className="neon-card p-4 overflow-auto">
        <div ref={previewRef} id="note-preview" className="prose prose-invert max-w-none" />
      </div>
    </div>
  );
}
