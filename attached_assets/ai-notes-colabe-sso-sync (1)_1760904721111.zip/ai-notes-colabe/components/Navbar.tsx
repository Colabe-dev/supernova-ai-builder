'use client';
import Link from 'next/link';
import { AuthButton } from './AuthButton';
import dynamic from 'next/dynamic';

const WorkspaceSwitcher = dynamic(() => import('@/components/WorkspaceSwitcher'), { ssr: false });

export function Navbar() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur border-b border-white/10 bg-black/30">
      <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-4">
        <Link href="/" className="font-semibold tracking-wide">
          <span className="text-brand">Colabe</span> <span className="text-brand-yellow">AI Notes</span>
        </Link>
        <nav className="flex items-center gap-4 text-sm">
          <Link href="/notes" className="hover:underline">Notes</Link>
          <Link href="/workspaces" className="hover:underline">Workspaces</Link>
          <Link href="/ecosystem" className="hover:underline">Ecosystem</Link>
          <Link href="/bundles" className="hover:underline">Bundles</Link>
          <Link href="/ecosystem/analytics" className="hover:underline">Analytics</Link>
          <Link href="/billing" className="hover:underline">Billing</Link>
          <Link href="/studio/voice" className="hover:underline">Voice</Link>
          <Link href="/studio/builder" className="hover:underline">Builder</Link>
          <Link href="/studio/email" className="hover:underline">Email</Link>
          <WorkspaceSwitcher />
          <AuthButton />
        </nav>
      </div>
    </header>
  );
}
