'use client';
import { useEffect } from 'react';
import { flushQueue } from '@/lib/sync';

export default function NeonGridBackground() {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }
    const online = () => { flushQueue().catch(()=>{}); };
    window.addEventListener('online', online);
    return () => window.removeEventListener('online', online);
  }, []);
  return null;
}
