export type ServiceDef = {
  id: string;
  name: string;
  baseUrlEnv: string; // env var name that has the base URL
  docs?: string;
  scopes?: string[];
};

export const defaultServices: ServiceDef[] = [
  { id: 'chat', name: 'Colabe Chat', baseUrlEnv: 'COLABE_SERVICE_CHAT_URL', docs: 'https://colabe.dev/chat' },
  { id: 'automations', name: 'Colabe Automations', baseUrlEnv: 'COLABE_SERVICE_AUTOMATIONS_URL', docs: 'https://colabe.dev/automations' },
  { id: 'images', name: 'Colabe Images', baseUrlEnv: 'COLABE_SERVICE_IMAGES_URL', docs: 'https://colabe.dev/images' },
  { id: 'analytics', name: 'Colabe Analytics', baseUrlEnv: 'COLABE_SERVICE_ANALYTICS_URL', docs: 'https://colabe.dev/analytics' },
  { id: 'docs', name: 'Colabe Docs', baseUrlEnv: 'COLABE_SERVICE_DOCS_URL', docs: 'https://colabe.dev/docs' },
  { id: 'payments', name: 'Colabe Payments', baseUrlEnv: 'COLABE_SERVICE_PAYMENTS_URL', docs: 'https://colabe.dev/payments' }
];
