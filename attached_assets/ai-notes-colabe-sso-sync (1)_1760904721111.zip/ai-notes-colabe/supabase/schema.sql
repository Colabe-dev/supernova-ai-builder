-- Enable UUID generation (if not already)
create extension if not exists "pgcrypto";

create table if not exists public.notes (
  id uuid primary key,
  user_id uuid,
  title text,
  content text,
  summary text generated always as (left(content, 240)) stored,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Basic RLS
alter table public.notes enable row level security;
create policy "user can select own notes" on public.notes for select using (auth.uid() = user_id);
create policy "user can insert own notes" on public.notes for insert with check (auth.uid() = user_id);
create policy "user can update own notes" on public.notes for update using (auth.uid() = user_id);

-- Trigger to auto-update updated_at
create or replace function public.touch_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_touch_updated_at on public.notes;
create trigger trg_touch_updated_at
before update on public.notes
for each row execute procedure public.touch_updated_at();


-- Sharing (public links)
create table if not exists public.shared_notes (
  id uuid primary key default gen_random_uuid(),
  token text unique not null,
  title text,
  content text,
  watermark_text text,
  screenshot_resist boolean default false,
  created_at timestamptz default now()
);

alter table public.shared_notes enable row level security;
-- Public can read shared notes by token (MVP)
drop policy if exists "shared public read" on public.shared_notes;
create policy "shared public read" on public.shared_notes for select using (true);
-- Allow inserts (MVP). Tighten later with service key or auth.
drop policy if exists "shared insert" on public.shared_notes;
create policy "shared insert" on public.shared_notes for insert with check (true);


-- Roles & Workspaces
do $$ begin
  create type public.role_level as enum ('owner','admin','editor','viewer');
exception when duplicate_object then null; end $$;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);

create table if not exists public.workspace_members (
  workspace_id uuid references public.workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  role role_level not null default 'editor',
  created_at timestamptz default now(),
  primary key (workspace_id, user_id)
);

alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;

-- Policies: members can see their workspaces
create policy if not exists "workspace select for members"
  on public.workspaces for select
  using (exists (select 1 from public.workspace_members m where m.workspace_id = id and m.user_id = auth.uid()));

create policy if not exists "workspace insert for users"
  on public.workspaces for insert
  with check (auth.uid() = created_by);

create policy if not exists "workspace_members select self"
  on public.workspace_members for select
  using (user_id = auth.uid());

create policy if not exists "workspace_members insert self"
  on public.workspace_members for insert
  with check (user_id = auth.uid());

-- Notes: add workspace_id and tighten policies
alter table public.notes add column if not exists workspace_id uuid references public.workspaces(id);
drop policy if exists "user can select own notes" on public.notes;
drop policy if exists "user can insert own notes" on public.notes;
drop policy if exists "user can update own notes" on public.notes;

create policy "select notes in member workspaces"
  on public.notes for select
  using (
    (user_id = auth.uid())
    or
    (workspace_id is not null and exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()))
  );

create policy "insert notes in member workspaces"
  on public.notes for insert
  with check (
    (user_id = auth.uid())
    and
    (workspace_id is null or exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()))
  );

create policy "update notes in member workspaces (editor or higher)"
  on public.notes for update
  using (
    (user_id = auth.uid())
    or
    (workspace_id is not null and exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid() and m.role in ('owner','admin','editor')))
  );


-- Invites
create table if not exists public.invites (
  token text primary key,
  workspace_id uuid references public.workspaces(id) on delete cascade,
  email text not null,
  role role_level not null default 'viewer',
  created_by uuid references auth.users(id),
  accepted_by uuid references auth.users(id),
  used_at timestamptz,
  created_at timestamptz default now()
);
alter table public.invites enable row level security;

-- Policies: owner/admin can create/list their workspace invites
create policy if not exists "invites select for members"
  on public.invites for select
  using (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()));

create policy if not exists "invites insert by admin"
  on public.invites for insert
  with check (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid() and m.role in ('owner','admin')));

create policy if not exists "invites update accept"
  on public.invites for update
  using (true)  -- simplify for MVP
  with check (true);

-- Per-note ACL
create table if not exists public.note_acl (
  note_id uuid references public.notes(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  role role_level not null default 'viewer',
  created_at timestamptz default now(),
  primary key (note_id, user_id)
);
alter table public.note_acl enable row level security;

create policy if not exists "note_acl select self"
  on public.note_acl for select using (user_id = auth.uid());

create policy if not exists "note_acl insert by editors"
  on public.note_acl for insert
  with check (
    exists (
      select 1 from public.notes n
      join public.workspace_members m on m.workspace_id = n.workspace_id
      where n.id = note_id and m.user_id = auth.uid() and m.role in ('owner','admin','editor')
    )
  );

create policy if not exists "note_acl delete by editors"
  on public.note_acl for delete
  using (
    exists (
      select 1 from public.notes n
      join public.workspace_members m on m.workspace_id = n.workspace_id
      where n.id = note_id and m.user_id = auth.uid() and m.role in ('owner','admin','editor')
    )
  );

-- Expand notes policies to respect note_acl
drop policy if exists "update notes in member workspaces (editor or higher)" on public.notes;
create policy "update notes via workspace or ACL"
  on public.notes for update
  using (
    (user_id = auth.uid())
    or
    (workspace_id is not null and exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid() and m.role in ('owner','admin','editor')))
    or
    (exists (select 1 from public.note_acl a where a.note_id = id and a.user_id = auth.uid() and a.role in ('owner','editor')))
  );

-- Audit logs
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id),
  actor_id uuid references auth.users(id),
  entity_type text not null,
  entity_id uuid,
  action text not null,
  data jsonb,
  created_at timestamptz default now()
);
alter table public.audit_logs enable row level security;

create policy if not exists "audit logs read by workspace members"
  on public.audit_logs for select
  using (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()));

create policy if not exists "audit logs insert by members"
  on public.audit_logs for insert
  with check (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()));


-- Colabe Ecosystem integration tables
create table if not exists public.integrations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  service_id text not null,          -- e.g., 'chat', 'automations'
  external_account_id text,          -- the remote account id at the service
  status text default 'disconnected',
  scopes text[] default '{}',
  meta jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.integrations enable row level security;

create policy if not exists "integrations read by members"
  on public.integrations for select
  using (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()));

create policy if not exists "integrations write by editors"
  on public.integrations for insert with check (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid() and m.role in ('owner','admin','editor')));
create policy if not exists "integrations update by editors"
  on public.integrations for update using (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid() and m.role in ('owner','admin','editor')));

-- Ecosystem bundles
create table if not exists public.bundle_plans (
  id text primary key,           -- e.g., 'starter', 'pro', 'studio'
  name text not null,
  description text,
  services text[] not null,      -- list of service ids included
  price_cents int default 0,
  currency text default 'EUR',
  created_at timestamptz default now()
);
alter table public.bundle_plans enable row level security;
create policy if not exists "bundle plans public read" on public.bundle_plans for select using (true);

create table if not exists public.bundle_subscriptions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  bundle_id text references public.bundle_plans(id),
  status text default 'active',
  started_at timestamptz default now(),
  cancel_at timestamptz
);
alter table public.bundle_subscriptions enable row level security;
create policy if not exists "bundle subs read by members"
  on public.bundle_subscriptions for select
  using (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()));
create policy if not exists "bundle subs insert by editors"
  on public.bundle_subscriptions for insert
  with check (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid() and m.role in ('owner','admin','editor')));

-- Webhook event log (ecosystem -> app)
create table if not exists public.colabe_events (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id),
  service_id text not null,
  type text not null,
  payload jsonb not null,
  created_at timestamptz default now()
);
alter table public.colabe_events enable row level security;
create policy if not exists "events read by members"
  on public.colabe_events for select
  using (exists (select 1 from public.workspace_members m where m.workspace_id = workspace_id and m.user_id = auth.uid()));


-- Aggregated daily metrics from colabe_events
drop view if exists public.daily_metrics;
create view public.daily_metrics as
  select date_trunc('day', created_at)::date as day,
         service_id,
         type,
         count(*)::bigint as events
  from public.colabe_events
  group by 1,2,3
  order by 1 desc;

comment on column public.integrations.scopes is 'Fine-grained scopes granted for this integration';
