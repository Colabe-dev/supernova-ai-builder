'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

type Ctx = { workspaceId: string | null, setWorkspaceId: (id:string)=>void, workspaces: any[] };
const WorkspaceContext = createContext<Ctx>({ workspaceId: null, setWorkspaceId: ()=>{}, workspaces: [] });

export function WorkspaceProvider({ children }:{ children: React.ReactNode }) {
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const [workspaces, setWorkspaces] = useState<any[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('workspaceId');
    if (saved) setWorkspaceId(saved);
    (async () => {
      const { data } = await supabase.from('workspace_members').select('workspace:workspaces(id,name)').maybeSingle();
      // Fallback fetch all memberships
      const { data: rows } = await supabase.from('workspace_members').select('workspace_id, workspaces(name, id)');
      if (rows) {
        const list = rows.map((r:any) => ({ id: r.workspace_id, name: r.workspaces?.name || 'Workspace' }));
        setWorkspaces(list);
        if (!saved && list.length) {
          setWorkspaceId(list[0].id);
          localStorage.setItem('workspaceId', list[0].id);
        }
      }
    })();
  }, []);

  function set(id:string) {
    setWorkspaceId(id);
    localStorage.setItem('workspaceId', id);
  }

  return <WorkspaceContext.Provider value={{ workspaceId, setWorkspaceId: set, workspaces }}>{children}</WorkspaceContext.Provider>;
}

export function useWorkspace() {
  return useContext(WorkspaceContext);
}
