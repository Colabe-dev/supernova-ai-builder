# Colabe AI Notes — App Router (Next.js 14)

AI-first note-taking with structure, diagrams, and exports. PWA + offline sync (IndexedDB), Supabase storage, optional OpenAI for higher-quality transforms. Cyber‑lux Colabe theme.

## Quick Start

```bash
pnpm i   # or npm/yarn
cp .env.example .env.local  # fill keys
pnpm dev
```

### Required env
- `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` from Supabase
- Optional: `OPENAI_API_KEY` for AI transforms
- Optional: `COLABE_PAYMENTS_*` for coin/subscription integration

### Database
Run `supabase/schema.sql` in your project (SQL Editor). Create a Storage bucket `notes-files` if you plan to upload files.

### Features
- Markdown editor with **AI command bar** (structure, summarize, translate, diagram, codegen)
- Mermaid diagrams via fenced blocks
- Offline‑first with IndexedDB + background sync to Supabase
- PWA service worker + manifest
- Email drafting studio, Logo prompt studio
- Colabe theme (dark, animated neon raster)

### Roadmap
- Exports: PDF, DOCX, HTML
- Voice‑to‑text (browser + Whisper proxy)
- Payments: Colabe Coins + Subscriptions
- Sharing: link‑based + watermarking
- Team workspaces

### Notes
- Without `OPENAI_API_KEY`, AI routes fall back to deterministic stubs so the app remains usable offline.
- This repo is “batteries included but optional”; integrate with the wider Colabe ecosystem at your pace.


## Packs Included

### 1) Exports Pack
- API endpoints: `/api/exports/html|markdown|pdf|docx`
- Editor → **Export** panel with **HTML / Markdown / PDF / DOCX / PNG (preview)**

### 2) Voice Pack
- Page: `/studio/voice` to **record**, transcribe (OpenAI Whisper if `OPENAI_API_KEY`), and **save as note**.
- Server route: `/api/voice/whisper`

### 3) Colabe Payments Pack (stub/proxy)
- Page: `/billing` with **Subscribe** and **Buy Coins** actions.
- Server routes: `/api/payments/checkout` (proxies to `COLABE_PAYMENTS_BASE_URL`) and `/api/payments/webhook`.
- Add your gateway URL + key in `.env.local` to go live.

### 4) Sharing Pack
- Table `shared_notes` with public-select policy.
- API: `/api/share/create` creates a tokenized public link.
- Public viewer: `/s/[token]` with **watermark** and optional **screenshot‑resist** mode.


### 5) Auth UI
- `/auth` with **magic-link email** sign-in via Supabase.
- Navbar shows signed-in user and a sign-out button.

### 6) Team Workspaces & Roles
- Tables: `workspaces`, `workspace_members` (enum `role_level`).
- RLS policies restrict access to members; editors/admins/owners can update.
- UI: `/workspaces` to create/select; **Workspace switcher** in navbar.
- Notes have `workspace_id` and list by current workspace.

### 7) File Uploads
- Component: `UploadPanel` in note editor; uploads to Supabase Storage bucket `notes-files` at `workspaces/{id}/notes/{noteId}/...`.
- Create the bucket in Supabase (public or RLS per your policy).

### 8) Offline Merge & Sync
- `lib/sync.ts` with background queue and `mergeContent()` (line-based merge).
- Autosave still works offline; queue flushes on `online` event.
- When remote changed, performs a conservative merge favoring newest changes and preserving unique lines.


### 9) Team Pack 2 (Invites, Roles UI, Note ACL, Audit Logs)
- `/workspaces/members`: invite users, change roles.
- `/invites/[token]`: accept via magic link.
- `note_acl` table + grant/revoke API for per-note sharing.
- `audit_logs` table (hooks available; add logs in your flows as needed).

### 10) Pro Exports
- `/api/exports/pdf-pro` — paginated PDF with page numbers + watermark.
- `/api/exports/html-themed` — dark-themed HTML with watermark layer.
- `/api/exports/docx-pro` — DOCX with header/footer and total page count.


### 11) Project Builder (Idea → Code)
- UI: `/studio/builder` — describe your idea, choose **Next.js**, **Express**, or **FastAPI**, toggle Tailwind/Auth/CRUD/Docker.
- API: `/api/builder/zip` — returns a ready-to-run ZIP of the generated project.
- Works offline with deterministic templates; can be upgraded to LLM-powered generation when `OPENAI_API_KEY` is provided.


### 12) Colabe Ecosystem Pack
- **Ecosystem Hub** `/ecosystem`: view services, health, and link workspace to each service.
- **Bundles** `/bundles`: sell/activate multi-service bundles (MVP uses local records; wire to gateway).
- **API**: `/api/colabe/services`, `/api/colabe/health`, `/api/colabe/connect`, `/api/colabe/bundle/checkout`, `/api/colabe/webhook`.
- **DB**: `integrations`, `bundle_plans`, `bundle_subscriptions`, `colabe_events` (with RLS).
- **Config**: set `COLABE_SERVICE_*_URL` envs to point at live services; hub auto-detects availability.


### 13) SSO/OAuth + Service Embeds + Metrics
- **OAuth**: `/api/colabe/oauth/authorize` and `/api/colabe/oauth/callback` with PKCE + discovery; tokens stored in `integrations.meta` (MVP).
- **JWKS-ready** verification helpers (see `lib/oidc.ts`).
- **Service UIs**: `/ecosystem/chat`, `/ecosystem/images`, `/ecosystem/automations` embed iframes when base URLs are set.
- **Registry sync**: `/api/colabe/registry/sync` imports bundle plans from `COLABE_SERVICE_REGISTRY_URL` (expects JSON array).
- **Payments wiring**: bundle checkout calls existing payments proxy; webhook syncs `bundle_subscriptions` status.
- **Usage Analytics**: `daily_metrics` view + `/api/metrics/daily` + `/ecosystem/analytics` line chart.
- **Fine-grained scopes**: stored in `integrations.scopes` and shown in UI; enforce downstream as needed.
