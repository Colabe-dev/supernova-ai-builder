'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function AuthPage() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  async function signInMagic() {
    setMessage('Sending magic link…');
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: (process.env.NEXT_PUBLIC_APP_URL || window.location.origin) + '/notes' }
    });
    if (error) setMessage(error.message);
    else setMessage('Check your email for the login link.');
  }

  async function signOut() {
    await supabase.auth.signOut();
    setMessage('Signed out.');
  }

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session) window.location.href = '/notes';
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <div className="mx-auto max-w-md neon-card p-6 space-y-4">
      <h1 className="text-2xl font-bold">Sign in</h1>
      <input className="w-full bg-black/30 p-3 rounded-lg" placeholder="you@example.com" value={email} onChange={(e)=>setEmail(e.target.value)} />
      <button onClick={signInMagic} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40 w-full">Send magic link</button>
      <button onClick={signOut} className="px-3 py-2 rounded-xl border border-white/10 w-full">Sign out</button>
      <div className="text-sm opacity-70">{message}</div>
      <div className="text-xs opacity-60">We use passwordless email links. Configure providers in Supabase if you want OAuth.</div>
    </div>
  );
}
