'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabaseClient';
import { listLocal } from '@/lib/idb';
import { NoteCard } from '@/components/NoteCard';
import { useWorkspace } from '@/contexts/WorkspaceContext';

export default function NotesPage() {
  const [notes, setNotes] = useState<any[]>([]);
  const { workspaceId } = useWorkspace();

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { window.location.href = '/auth'; return; }
      let list:any[] = [];
      if (workspaceId) {
        const { data } = await supabase.from('notes').select('*').eq('workspace_id', workspaceId).order('updated_at', { ascending: false });
        list = data || [];
      } else {
        const { data } = await supabase.from('notes').select('*').order('updated_at', { ascending: false });
        list = data || [];
      }
      if (list.length === 0) list = await listLocal();
      setNotes(list);
    })();
  }, [workspaceId]);

  function newHref() {
    const id = crypto.randomUUID();
    return `/notes/${id}`;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Your Notes</h2>
        <Link href={newHref()} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">New Note</Link>
      </div>
      {notes.length === 0 ? (
        <div className="opacity-70">No notes yet. Create one!</div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {notes.map((n) => <NoteCard key={n.id} note={n} />)}
        </div>
      )}
    </div>
  );
}
