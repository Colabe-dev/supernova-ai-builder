'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import Editor from '@/components/Editor';
import { getLocal, saveLocal } from '@/lib/idb';
import ExportPanel from '@/components/ExportPanel';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import UploadPanel from '@/components/UploadPanel';
import NoteAccessPanel from '@/components/NoteAccessPanel';
import { syncNote } from '@/lib/sync';

export default function NoteEditor({ params }:{ params:{ id:string } }) {
  const [note, setNote] = useState<any>({ id: params.id, title: '', content: '', created_at: new Date().toISOString() });
  const [shareURL, setShareURL] = useState<string>('');
  const { workspaceId } = useWorkspace();

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { window.location.href = '/auth'; return; }

      const { data } = await supabase.from('notes').select('*').eq('id', params.id).single();
      if (data) setNote(data);
      else {
        const local = await getLocal(params.id);
        if (local) setNote(local);
        else setNote((n:any)=>({ ...n, user_id: user.id, workspace_id: workspaceId || null }));
      }
    })();
  }, [params.id, workspaceId]);

  async function save(updated:any) {
    const enriched = { ...updated, workspace_id: updated.workspace_id || workspaceId || null };
    setNote(enriched);
    saveLocal(enriched);
    const merged = await syncNote(enriched);
    setNote(merged);
  }

  async function share(screenshot_resist=false) {
    const res = await fetch('/api/share/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: note.title || 'Note', content: note.content || '', watermark_text: 'Colabe AI Notes', screenshot_resist })
    });
    if (!res.ok) return alert('Share failed');
    const j = await res.json();
    setShareURL(j.url);
  }

  return (
    <div className="space-y-4">
      <Editor note={note} onSave={save} />
      <ExportPanel title={()=>note.title || 'Note'} getContent={()=>note.content || ''} getPreviewSelector={()=>'#note-preview'} />
      <UploadPanel noteId={params.id} />
      <div className="flex flex-wrap gap-2">
        <button onClick={()=>share(false)} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Share (public link)</button>
        <button onClick={()=>share(true)} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Share + Screenshot-Resist</button>
        {shareURL && <a href={shareURL} className="px-3 py-2 rounded-xl border border-white/10" target="_blank">Open Shared Link</a>}
      </div>
    </div>
  );
}
