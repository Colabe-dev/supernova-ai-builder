'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { marked } from 'marked';

export default function SharedView() {
  const params = useParams();
  const token = params?.token as string;
  const [title, setTitle] = useState('');
  const [html, setHtml] = useState('');
  const [wm, setWm] = useState('');
  const [sr, setSr] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('shared_notes').select('*').eq('token', token).single();
      if (data) {
        setTitle(data.title || 'Shared Note');
        setHtml(marked.parse(data.content || '') as string);
        setWm(data.watermark_text || '');
        setSr(!!data.screenshot_resist);
      }
    })();
  }, [token]);

  useEffect(() => {
    if (sr) {
      // Basic screenshot-resist UX hardening
      const prevent = (e: Event) => e.preventDefault();
      document.addEventListener('contextmenu', prevent);
      document.addEventListener('keydown', (e:any) => {
        if (e.key === 'PrintScreen' || (e.ctrlKey && e.key.toLowerCase() === 'p')) e.preventDefault();
      });
      return () => {
        document.removeEventListener('contextmenu', prevent);
      }
    }
  }, [sr]);

  return (
    <div className="relative neon-card p-6">
      {wm && (
        <div className="pointer-events-none select-none absolute inset-0 opacity-10 [background:repeating-linear-gradient(45deg,transparent,transparent_32px,currentColor_32px,currentColor_64px)] text-3xl flex items-center justify-center text-brand">
          <div className="rotate-[-20deg]">{wm}</div>
        </div>
      )}
      <h1 className="text-2xl font-bold mb-4">{title}</h1>
      <article className="prose prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: html }} />
      {sr && <div className="mt-4 text-xs opacity-60">Screenshot-resist mode is on. Printing is disabled.</div>}
    </div>
  );
}
