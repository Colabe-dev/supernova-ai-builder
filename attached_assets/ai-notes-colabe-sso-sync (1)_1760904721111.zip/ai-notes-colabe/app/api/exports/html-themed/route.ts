import { NextRequest } from 'next/server';
import { marked } from 'marked';

export async function POST(req: NextRequest) {
  const { title = 'Document', content = '', watermark = 'Colabe AI Notes' } = await req.json();
  const body = marked.parse(content) as string;
  const html = `<!doctype html><html><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"/><title>${title}</title>
  <style>
    :root { --bg:#0b0d10; --card:#0f1216; --txt:#e6f0ff; --accent:#0a84ff; }
    body { background:var(--bg); color:var(--txt); font-family: Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif; padding: 32px; }
    .card { background: var(--card); border:1px solid #1d2330; border-radius: 16px; padding: 24px; }
    pre, code { background:#0a0a0a; padding:2px 4px; border-radius:6px; }
    pre { padding:12px; overflow:auto; }
    a { color: var(--accent); }
    h1,h2,h3 { color: white; }
    .wm { position: fixed; inset:0; pointer-events:none; display:flex; align-items:center; justify-content:center; opacity:.08; color:#00ffd5; font-size:64px; transform: rotate(-20deg); }
  </style></head><body>
  <div class="wm">${watermark}</div>
  <div class="card"><h1>${title}</h1>${body}</div>
  </body></html>`;
  return new Response(html, {
    status: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Disposition': `attachment; filename="${title.replace(/[^a-z0-9-_]+/gi,'_')}.html"`
    }
  });
}
