import { NextRequest } from 'next/server';
import { marked } from 'marked';

export async function POST(req: NextRequest) {
  const { title = 'Document', content = '' } = await req.json();
  const body = marked.parse(content) as string;
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <style>
    body { font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif; line-height: 1.55; padding: 24px; color:#111;}
    pre, code { background:#f5f5f5; padding:2px 4px; border-radius:6px; }
    pre { padding:12px; overflow:auto; }
    h1,h2,h3 { margin-top: 1.2em; }
  </style></head><body><h1>${title}</h1>${body}</body></html>`;
  return new Response(html, {
    status: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Disposition': `attachment; filename="${title.replace(/[^a-z0-9-_]+/gi,'_')}.html"`
    }
  });
}
