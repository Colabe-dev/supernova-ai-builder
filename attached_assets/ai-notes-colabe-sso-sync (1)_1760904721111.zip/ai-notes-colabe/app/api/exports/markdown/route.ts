import { NextRequest } from 'next/server';

export async function POST(req: NextRequest) {
  const { title = 'Note', content = '' } = await req.json();
  return new Response(content, {
    status: 200,
    headers: {
      'Content-Type': 'text/markdown; charset=utf-8',
      'Content-Disposition': `attachment; filename="${title.replace(/[^a-z0-9-_]+/gi,'_')}.md"`
    }
  });
}
