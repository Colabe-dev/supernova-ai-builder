import { NextRequest } from 'next/server';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

function strip(md: string) {
  return md
    .replace(/```[\s\S]*?```/g, (m)=>'\n' + m + '\n') // keep code blocks
    .replace(/^#{1,6}\s*/gm, '')
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .replace(/\[(.*?)\]\((.*?)\)/g, '$1 ($2)');
}

export async function POST(req: NextRequest) {
  const { title = 'Document', content = '' } = await req.json();
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([595.28, 841.89]); // A4
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const margin = 48;
  let x = margin, y = page.getHeight() - margin;

  // Title
  const titleSize = 20;
  page.drawText(title, { x, y, size: titleSize, font: fontBold, color: rgb(0,0,0) });
  y -= titleSize + 12;

  // Content
  const text = strip(content);
  const words = text.split(/\s+/);
  const size = 11;
  const lineHeight = size * 1.35;
  const maxWidth = page.getWidth() - margin * 2;

  let line = '';
  function widthOf(s:string) { return font.widthOfTextAtSize(s, size); }

  for (const w of words) {
    const test = line ? line + ' ' + w : w;
    if (widthOf(test) > maxWidth) {
      page.drawText(line, { x, y, size, font, color: rgb(0,0,0) });
      y -= lineHeight;
      if (y < margin + lineHeight) {
        y = page.getHeight() - margin;
        pdf.addPage(page);
      }
      line = w;
    } else {
      line = test;
    }
  }
  if (line) page.drawText(line, { x, y, size, font, color: rgb(0,0,0) });

  const bytes = await pdf.save();
  return new Response(Buffer.from(bytes), {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${title.replace(/[^a-z0-9-_]+/gi,'_')}.pdf"`
    }
  });
}
