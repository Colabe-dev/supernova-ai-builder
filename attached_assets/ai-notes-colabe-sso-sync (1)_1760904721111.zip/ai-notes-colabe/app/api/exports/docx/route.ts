import { NextRequest } from 'next/server';
import { Document, Packer, Paragraph, HeadingLevel, TextRun } from 'docx';

function mdToParagraphs(md:string) {
  const lines = md.split(/\n/);
  const paras: Paragraph[] = [];
  for (const l of lines) {
    if (/^#\s+/.test(l)) paras.push(new Paragraph({ text: l.replace(/^#\s+/, ''), heading: HeadingLevel.HEADING_1 }));
    else if (/^##\s+/.test(l)) paras.push(new Paragraph({ text: l.replace(/^##\s+/, ''), heading: HeadingLevel.HEADING_2 }));
    else if (/^###\s+/.test(l)) paras.push(new Paragraph({ text: l.replace(/^###\s+/, ''), heading: HeadingLevel.HEADING_3 }));
    else paras.push(new Paragraph({ children: [new TextRun(l)] }));
  }
  return paras;
}

export async function POST(req: NextRequest) {
  const { title = 'Document', content = '' } = await req.json();
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        new Paragraph({ text: title, heading: HeadingLevel.TITLE }),
        ...mdToParagraphs(content)
      ]
    }]
  });
  const buffer = await Packer.toBuffer(doc);
  return new Response(buffer, {
    status: 200,
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'Content-Disposition': `attachment; filename="${title.replace(/[^a-z0-9-_]+/gi,'_')}.docx"`
    }
  });
}
