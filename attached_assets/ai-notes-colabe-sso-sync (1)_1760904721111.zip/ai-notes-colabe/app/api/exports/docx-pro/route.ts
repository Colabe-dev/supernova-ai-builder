import { NextRequest } from 'next/server';
import { Document, Packer, Paragraph, HeadingLevel, TextRun, AlignmentType, Header, Footer, PageNumber } from 'docx';

function mdToParas(md:string) {
  const out: Paragraph[] = [];
  for (const line of md.split('\n')) {
    if (/^#\s+/.test(line)) out.push(new Paragraph({ text: line.replace(/^#\s+/, ''), heading: HeadingLevel.HEADING_1 }));
    else if (/^##\s+/.test(line)) out.push(new Paragraph({ text: line.replace(/^##\s+/, ''), heading: HeadingLevel.HEADING_2 }));
    else out.push(new Paragraph({ children: [new TextRun(line)] }));
  }
  return out;
}

export async function POST(req: NextRequest) {
  const { title='Document', content='', watermark='Colabe AI Notes' } = await req.json();
  const doc = new Document({
    sections: [{
      headers: { default: new Header({ children: [ new Paragraph({ children: [new TextRun({ text: title, bold: true })] }) ] }) },
      footers: { default: new Footer({ children: [ new Paragraph({ alignment: AlignmentType.RIGHT, children: [ new TextRun('Page '), PageNumber.CURRENT, new TextRun(' / '), PageNumber.TOTAL_PAGES ] }) ] }) },
      properties: { page: { margin: { top: 720, right: 720, bottom: 720, left: 720 } } },
      children: [
        new Paragraph({ text: title, heading: HeadingLevel.TITLE }),
        ...mdToParas(content),
        new Paragraph({ text: '', pageBreakBefore: true }),
        new Paragraph({ text: watermark, alignment: AlignmentType.CENTER })
      ]
    }]
  });
  const buffer = await Packer.toBuffer(doc);
  return new Response(buffer, {
    status: 200,
    headers: { 'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Content-Disposition': `attachment; filename="${title.replace(/[^a-z0-9-_]+/gi,'_')}.docx"` }
  });
}
