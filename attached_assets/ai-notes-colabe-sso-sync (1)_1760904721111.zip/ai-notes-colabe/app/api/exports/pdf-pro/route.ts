import { NextRequest } from 'next/server';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

function mdToLines(md:string) {
  // super-lightweight: keep code blocks and headings, otherwise plain text
  const lines = md.replace(/\r/g,'').split('\n');
  return lines;
}

export async function POST(req: NextRequest) {
  const { title='Document', content='', watermark='Colabe AI Notes' } = await req.json();
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const margin = 54, size = 11, lh = size * 1.4;
  let page = pdf.addPage([595.28, 841.89]);
  let y = page.getHeight() - margin;

  // Header
  page.drawText(title, { x: margin, y, size: 14, font: bold, color: rgb(0.1,0.1,0.1) });
  y -= 24;

  // Watermark
  page.drawText(watermark, { x: 150, y: 400, rotate: { type: 'degrees', angle: -30 }, size: 48, font: bold, color: rgb(0.85,0.85,0.85) , opacity: 0.08 });

  const lines = mdToLines(content);
  const maxW = page.getWidth()-margin*2;
  function width(t:string, f:any=font, s:number=size){ return f.widthOfTextAtSize(t, s); }
  function newPage() {
    page = pdf.addPage([595.28, 841.89]);
    y = page.getHeight() - margin;
    page.drawText(title, { x: margin, y, size: 14, font: bold, color: rgb(0.1,0.1,0.1) });
    y -= 24;
    page.drawText(watermark, { x: 150, y: 400, rotate: { type: 'degrees', angle: -30 }, size: 48, font: bold, color: rgb(0.85,0.85,0.85), opacity: 0.08 });
  }

  for (const raw of lines) {
    let line = raw;
    let f = font, s = size;
    if (/^#\s+/.test(line)) { line = line.replace(/^#\s+/, ''); f = bold; s = 16; }
    else if (/^##\s+/.test(line)) { line = line.replace(/^##\s+/, ''); f = bold; s = 13; }
    else if (/^```/.test(line)) { /* keep as-is */ }

    if (line.trim()==='') { y -= lh; if (y < margin) newPage(); continue; }

    let buf = '';
    for (const w of line.split(/\s+/)) {
      const test = buf ? buf + ' ' + w : w;
      if (width(test, f, s) > maxW) {
        page.drawText(buf, { x: margin, y, size: s, font: f, color: rgb(0,0,0) });
        y -= lh;
        if (y < margin) newPage();
        buf = w;
      } else buf = test;
    }
    if (buf) {
      page.drawText(buf, { x: margin, y, size: s, font: f, color: rgb(0,0,0) });
      y -= lh;
      if (y < margin) newPage();
    }
  }

  // Footer page numbers
  const pages = pdf.getPages();
  pages.forEach((p, i) => {
    const text = `Page ${i+1} / ${pages.length}`;
    p.drawText(text, { x: p.getWidth()-margin- bold.widthOfTextAtSize(text, 10), y: margin/2, size: 10, font: bold, color: rgb(0.3,0.3,0.3) });
  });

  const bytes = await pdf.save();
  return new Response(Buffer.from(bytes), {
    status: 200,
    headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${title.replace(/[^a-z0-9-_]+/gi,'_')}.pdf"` }
  });
}
