import { NextRequest } from 'next/server';
import { json } from '../../ai/_shared';

export async function POST(req: NextRequest) {
  const { kind } = await req.json();
  const base = process.env.COLABE_PAYMENTS_BASE_URL;
  const key = process.env.COLABE_PAYMENTS_API_KEY;

  if (!base || !key) {
    // Offline stub
    if (kind === 'subscribe') return json({ ok: true, message: 'Subscribed (stub). Add COLABE_PAYMENTS_* to enable live billing.' });
    if (kind === 'coins') return json({ ok: true, message: 'Coins added (stub). Add COLABE_PAYMENTS_* to enable live billing.' });
    return json({ ok: true });
  }

  // Proxy example (customize to your gateway)
  try {
    const res = await fetch(`${base}/api/checkout`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
      body: JSON.stringify({ kind })
    });
    const j = await res.json();
    return json(j);
  } catch (e:any) {
    return new Response(e?.message || 'Payment error', { status: 500 });
  }
}
