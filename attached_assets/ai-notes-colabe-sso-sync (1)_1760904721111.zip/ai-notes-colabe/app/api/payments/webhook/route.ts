import { NextRequest } from 'next/server';
import { json } from '../../ai/_shared';
import { supabase } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(()=>({}));
  // Expect events like { type:'bundle.active' | 'bundle.canceled', workspace_id, bundle_id }
  if (body.type && body.workspace_id && body.bundle_id) {
    if (body.type === 'bundle.active') {
      await supabase.from('bundle_subscriptions').upsert({ workspace_id: body.workspace_id, bundle_id: body.bundle_id, status: 'active' });
    } else if (body.type === 'bundle.canceled') {
      await supabase.from('bundle_subscriptions').upsert({ workspace_id: body.workspace_id, bundle_id: body.bundle_id, status: 'canceled', cancel_at: new Date().toISOString() });
    }
  }
  return json({ received: true });
}
