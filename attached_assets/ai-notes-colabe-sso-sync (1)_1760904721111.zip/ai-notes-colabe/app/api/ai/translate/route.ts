import { maybeOpenAI, json } from '../_shared';

export async function POST(request: Request) {
  const { text, to='es' } = await request.json();
  const openai = await maybeOpenAI();
  if (!openai) {
    return json({ text: `[${to}] ${text}` });
  }
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role:'user', content: `Translate to ${to}. Preserve markdown:\n\n${text}` }],
    temperature: 0.2
  });
  return json({ text: res.choices[0].message?.content || '' });
}
