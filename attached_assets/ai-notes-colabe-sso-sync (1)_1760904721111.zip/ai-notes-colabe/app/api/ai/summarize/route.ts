import { maybeOpenAI, json } from '../_shared';

export async function POST(request: Request) {
  const { text } = await request.json();
  const openai = await maybeOpenAI();
  if (!openai) {
    const words = text.split(/\s+/).slice(0,80).join(' ');
    return json({ text: `Summary (offline mode): ${words}...` });
  }
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role:'user', content: `Summarize in 5 bullet points:\n\n${text}` }],
    temperature: 0.3
  });
  return json({ text: res.choices[0].message?.content || '' });
}
