import OpenAI from 'openai';

export async function maybeOpenAI() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return null;
  return new OpenAI({ apiKey: key });
}

export function json(data:any, init: ResponseInit = {}) {
  return new Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json' }, ...init });
}

export function bad(message:string, status=400) {
  return new Response(message, { status });
}
