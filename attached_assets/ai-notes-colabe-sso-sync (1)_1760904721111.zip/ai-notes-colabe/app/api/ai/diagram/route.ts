import { maybeOpenAI, json } from '../_shared';

export async function POST(request: Request) {
  const { text } = await request.json();
  const openai = await maybeOpenAI();
  if (!openai) {
    // Offline: simple flowchart
    return json({ mermaid: `flowchart TD\n A[Start] --> B[Parse Notes]\n B --> C{Decide}\n C -->|Docs| D[Export]\n C -->|Code| E[Generate]\n D --> F[Done]\n E --> F[Done]` });
  }
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role:'user', content: `From the note below, produce a concise Mermaid diagram (flowchart or sequence) that captures the core logic. Return ONLY mermaid code.\n\n${text}` }],
    temperature: 0.2
  });
  return json({ mermaid: res.choices[0].message?.content || '' });
}
