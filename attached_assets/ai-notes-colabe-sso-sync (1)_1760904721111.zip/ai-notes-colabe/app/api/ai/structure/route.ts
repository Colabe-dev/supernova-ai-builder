import { maybeOpenAI, json } from '../_shared';

export async function POST(request: Request) {
  const { text } = await request.json();
  const openai = await maybeOpenAI();
  if (!openai) {
    // Basic heuristic structuring without LLM
    const lines = text.split('\n').map(l => l.trim());
    const bullets = lines.filter(Boolean).map(l => `- ${l}`);
    return json({ text: `# Structured Note\n\n${bullets.join('\n')}` });
  }
  const prompt = `Organize the following notes into a clean markdown document with sections, bullet points, and action items. Keep it concise.\n\n${text}`;
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role:'user', content: prompt }],
    temperature: 0.2
  });
  return json({ text: res.choices[0].message?.content || '' });
}
