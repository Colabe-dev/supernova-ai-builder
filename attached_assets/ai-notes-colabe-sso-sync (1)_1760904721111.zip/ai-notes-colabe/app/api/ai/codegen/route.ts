import { maybeOpenAI, json } from '../_shared';

export async function POST(request: Request) {
  const { text, lang='python' } = await request.json();
  const openai = await maybeOpenAI();
  if (!openai) {
    // Offline: wrap text in a comment
    return json({ text: `# ${lang} code (offline stub)\n# ${text.split('\n').join('\n# ')}` });
  }
  const res = await openai.chat.completions.create({
    model: 'gpt-4.1-mini',
    messages: [{ role:'user', content: `Write idiomatic ${lang} code based on this spec. Include docstrings and tests inline when possible.\n\n${text}` }],
    temperature: 0.1
  });
  return json({ text: res.choices[0].message?.content || '' });
}
