import { NextRequest } from 'next/server';
import { maybeOpenAI, json, bad } from '../../ai/_shared';

export const runtime = 'nodejs'; // ensure Node (for file handling)

export async function POST(req: NextRequest) {
  const openai = await maybeOpenAI();
  const form = await req.formData();
  const file = form.get('file') as File | null;
  if (!file) return bad('No file', 400);
  if (!openai) return json({ text: '' }); // offline

  // Convert File to a compatible blob (Web API File works in Node 18+)
  const res = await openai.audio.transcriptions.create({
    file,
    model: 'whisper-1'
  } as any);
  const text = (res as any).text || '';
  return json({ text });
}
