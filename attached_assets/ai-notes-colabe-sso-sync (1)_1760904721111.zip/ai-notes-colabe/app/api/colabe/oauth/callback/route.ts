import { NextRequest } from 'next/server';
import { serviceOAuthEnv, wellKnown } from '@/lib/colabeConfig';
import { exchangeToken } from '@/lib/oidc';
import { supabase } from '@/lib/supabaseServer';

export async function GET(req: NextRequest) {
  const service = (req.nextUrl.searchParams.get('service') || '').toLowerCase() as any;
  const code = req.nextUrl.searchParams.get('code');
  const state = req.nextUrl.searchParams.get('state');
  if (!service || !code) return new Response('Missing params', { status: 400 });

  const cfg = serviceOAuthEnv(service);
  if (!cfg) return new Response('Service OAuth not configured', { status: 400 });

  const cookie = req.headers.get('cookie') || '';
  const verifier = (/colabe_oauth_verifier=([^;]+)/.exec(cookie) || [])[1];
  const storedState = (/colabe_oauth_state=([^;]+)/.exec(cookie) || [])[1];
  if (!verifier || !storedState || storedState !== state) return new Response('Bad state', { status: 400 });

  const well = await fetch(wellKnown(cfg.issuer), { cache: 'no-store' }).then(r=>r.json());
  const tokenEndpoint = well.token_endpoint as string;

  const token = await exchangeToken(tokenEndpoint, cfg.clientId, cfg.clientSecret, code, cfg.redirectUri, verifier);

  // Persist on 'integrations' (workspace selection is required client-side; for MVP, store without workspace)
  const { error } = await supabase.from('integrations').upsert({
    workspace_id: null,
    service_id: service,
    external_account_id: token?.id_token ? 'oidc' : 'account',
    status: 'connected',
    scopes: (token?.scope || '').split(' ').filter(Boolean),
    meta: token
  });
  const redir = new URL('/ecosystem', req.nextUrl.origin).toString();
  return new Response(null, { status: 302, headers: { Location: redir } });
}
