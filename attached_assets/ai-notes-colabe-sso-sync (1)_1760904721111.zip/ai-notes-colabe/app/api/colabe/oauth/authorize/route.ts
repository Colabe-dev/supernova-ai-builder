import { NextRequest } from 'next/server';
import { serviceOAuthEnv, wellKnown } from '@/lib/colabeConfig';

function base64url(input: ArrayBuffer) {
  let str = Buffer.from(input).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return str;
}
async function sha256(verifier:string) {
  const data = new TextEncoder().encode(verifier);
  const buf = await crypto.subtle.digest('SHA-256', data);
  return base64url(buf);
}

export async function GET(req: NextRequest) {
  const service = (req.nextUrl.searchParams.get('service') || '').toLowerCase() as any;
  const cfg = serviceOAuthEnv(service);
  if (!cfg) return new Response('Service OAuth not configured', { status: 400 });

  const well = await fetch(wellKnown(cfg.issuer), { cache: 'no-store' }).then(r=>r.json());
  const auth = well.authorization_endpoint as string;
  const verifier = base64url(crypto.getRandomValues(new Uint8Array(32)));
  const challenge = await sha256(verifier);

  const state = base64url(crypto.getRandomValues(new Uint8Array(16)));
  const url = new URL(auth);
  url.searchParams.set('response_type','code');
  url.searchParams.set('client_id', cfg.clientId);
  url.searchParams.set('redirect_uri', cfg.redirectUri);
  url.searchParams.set('scope','openid offline_access profile email');
  url.searchParams.set('state', state);
  url.searchParams.set('code_challenge', challenge);
  url.searchParams.set('code_challenge_method', 'S256');

  // Set cookies for verifier/state (short TTL)
  const headers = new Headers({ 'Location': url.toString() });
  headers.append('Set-Cookie', `colabe_oauth_verifier=${verifier}; HttpOnly; Secure; Path=/; Max-Age=600; SameSite=Lax`);
  headers.append('Set-Cookie', `colabe_oauth_state=${state}; HttpOnly; Secure; Path=/; Max-Age=600; SameSite=Lax`);

  return new Response(null, { status: 302, headers });
}
