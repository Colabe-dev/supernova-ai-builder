import { NextRequest } from 'next/server';
import { defaultServices } from '@/ecosystem/config';

export async function GET(_req: NextRequest) {
  const list = defaultServices.map(s => ({
    id: s.id,
    name: s.name,
    baseUrl: process.env[s.baseUrlEnv] || null,
    docs: s.docs || null
  }));
  return new Response(JSON.stringify({ services: list }), { status: 200, headers: { 'Content-Type': 'application/json' } });
}
