import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';
import { json } from '../../../ai/_shared';

export async function POST(req: NextRequest) {
  const { workspace_id, bundle_id } = await req.json();
  if (!workspace_id || !bundle_id) return new Response('Missing params', { status: 400 });

  // Call existing payments proxy to create a checkout session
  try {
    const res = await fetch('/api/payments/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'bundle', bundle_id, workspace_id })
    } as any);
    const j = await res.json();
    // Create pending subscription locally
    await supabase.from('bundle_subscriptions').insert({ workspace_id, bundle_id, status: 'pending' });
    return json({ ok: true, checkout: j });
  } catch (e:any) {
    // Fallback: stub activate
    await supabase.from('bundle_subscriptions').insert({ workspace_id, bundle_id, status: 'active' });
    return json({ ok: true, message: 'Bundle activated (stub: payments disabled).' });
  }
}
