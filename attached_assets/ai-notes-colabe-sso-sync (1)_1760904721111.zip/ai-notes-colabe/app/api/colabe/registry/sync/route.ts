import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';

export async function POST(_req: NextRequest) {
  const url = process.env.COLABE_SERVICE_REGISTRY_URL;
  if (!url) return new Response('No COLABE_SERVICE_REGISTRY_URL set', { status: 400 });
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) return new Response('Failed to fetch registry', { status: 502 });
  const items = await res.json().catch(()=>null);
  if (!Array.isArray(items)) return new Response('Registry must be array JSON', { status: 400 });

  // Expect bundle-like objects: { id, name, description, services[], price_cents, currency }
  for (const it of items) {
    if (!it.id || !it.name || !Array.isArray(it.services)) continue;
    await supabase.from('bundle_plans').upsert({
      id: it.id, name: it.name, description: it.description || '',
      services: it.services, price_cents: it.price_cents || 0, currency: it.currency || 'EUR'
    });
  }
  return new Response('ok', { status: 200 });
}
