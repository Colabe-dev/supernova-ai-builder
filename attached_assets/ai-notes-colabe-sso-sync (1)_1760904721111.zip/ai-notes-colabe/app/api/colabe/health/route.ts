import { NextRequest } from 'next/server';
import { defaultServices } from '@/ecosystem/config';
import { ColabeServerClient } from '@/lib/colabeServer';

export async function GET(_req: NextRequest) {
  const client = new ColabeServerClient({ token: process.env.COLABE_INTERNAL_TOKEN });
  const statuses = await Promise.all(defaultServices.map(async s => {
    const base = process.env[s.baseUrlEnv];
    if (!base) return { id: s.id, name: s.name, status: 'not-configured' };
    try {
      const res = await fetch(`${base}/health`, { cache: 'no-store' });
      return { id: s.id, name: s.name, status: res.ok ? 'ok' : 'degraded' };
    } catch {
      return { id: s.id, name: s.name, status: 'offline' };
    }
  }));
  return new Response(JSON.stringify({ statuses }), { status: 200, headers: { 'Content-Type': 'application/json' } });
}
