import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  const { workspace_id, service_id, external_account_id, scopes=[] } = await req.json();
  const { error } = await supabase.from('integrations').upsert({ workspace_id, service_id, external_account_id, scopes, status: 'connected' }, { onConflict: 'workspace_id,service_id' as any });
  if (error) return new Response(error.message, { status: 500 });
  return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'Content-Type': 'application/json' } });
}
