import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  const sig = req.headers.get('x-colabe-signature');
  const body = await req.json();
  // TODO: verify 'sig' with COLABE_SSO_PUBLIC_JWKS if provided
  const { workspace_id, service_id, type } = body;
  await supabase.from('colabe_events').insert({ workspace_id, service_id, type, payload: body });
  return new Response('ok', { status: 200 });
}
