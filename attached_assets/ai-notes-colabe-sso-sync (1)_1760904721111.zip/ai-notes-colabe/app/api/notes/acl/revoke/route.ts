import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  const { note_id, user_id } = await req.json();
  const { error } = await supabase.from('note_acl').delete().match({ note_id, user_id });
  if (error) return new Response(error.message, { status: 403 });
  return new Response('OK', { status: 200 });
}
