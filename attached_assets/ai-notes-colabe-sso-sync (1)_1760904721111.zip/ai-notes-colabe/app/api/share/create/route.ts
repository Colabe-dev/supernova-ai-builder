import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  const { title, content, watermark_text = 'Colabe AI Notes', screenshot_resist = false } = await req.json();
  const token = crypto.randomUUID().replace(/-/g, '');
  const { data, error } = await supabase.from('shared_notes').insert({
    token, title, content, watermark_text, screenshot_resist
  }).select().single();
  if (error) return new Response(error.message, { status: 500 });
  return new Response(JSON.stringify({ url: `/s/${token}` }), { status: 200, headers: { 'Content-Type': 'application/json' } });
}
