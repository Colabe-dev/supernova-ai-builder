import { NextRequest } from 'next/server';
import JSZip from 'jszip';

export const runtime = 'nodejs';

type Options = { tailwind?: boolean; auth?: boolean; crud?: boolean; docker?: boolean };
type Spec = { idea: string; stack: 'nextjs'|'express'|'fastapi'; options: Options };

function slugify(s:string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');
}
function safeName(s:string) {
  const t = s.replace(/[^a-zA-Z0-9 _-]+/g, '').trim();
  return t || 'My App';
}

function nowISO() { return new Date().toISOString().split('T')[0]; }

function nextTemplate(appName:string, desc:string, opt:Options) {
  const files: Record<string,string> = {};
  const pkg = {
    name: slugify(appName),
    version: "0.1.0",
    private: true,
    scripts: { dev: "next dev", build: "next build", start: "next start", lint: "next lint" },
    dependencies: {
      next: "14.2.11",
      react: "18.3.1",
      "react-dom": "18.3.1"
    },
    devDependencies: {
      typescript: "^5.6.3",
      "@types/node": "^22.7.5",
      "@types/react": "^18.3.5",
      "@types/react-dom": "^18.3.0"
    }
  } as any;
  if (opt.tailwind) {
    pkg.devDependencies = { ...pkg.devDependencies, tailwindcss: "^3.4.13", autoprefixer: "^10.4.20", postcss: "^8.4.47" };
    files["postcss.config.js"] = `module.exports={ plugins:{ tailwindcss:{}, autoprefixer:{} } }`;
    files["tailwind.config.ts"] = `export default { content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'], theme:{ extend:{} }, plugins:[] }`;
    files["app/globals.css"] = `@tailwind base;@tailwind components;@tailwind utilities; body{font-family:ui-sans-serif,system-ui}`;
  }
  files["package.json"] = JSON.stringify(pkg, null, 2);
  files["tsconfig.json"] = `{"compilerOptions":{"target":"ES2022","lib":["dom","es2022"],"module":"esnext","moduleResolution":"bundler","jsx":"preserve","strict":true,"noEmit":true}}`;
  files["next.config.mjs"] = `export default {}`;
  files["README.md"] = `# ${appName}\n\n${desc}\n\nGenerated on ${nowISO()} by Colabe AI Notes Builder.`;
  files[".env.example"] = `NEXT_PUBLIC_APP_NAME=${appName}\n`;
  files["app/layout.tsx"] = `import './globals.css'; export default function Root({children}:{children:React.ReactNode}){return <html lang='en'><body><main className='p-8 max-w-5xl mx-auto'>{children}</main></body></html>}`;
  files["app/page.tsx"] = `export default function Page(){return (<div><h1 className='text-3xl font-bold'>${appName}</h1><p className='opacity-75'>${desc}</p></div>);}`;
  if (opt.crud) {
    files["app/api/items/route.ts"] = `const store:any[]=[]; export async function GET(){return new Response(JSON.stringify(store),{headers:{'content-type':'application/json'}})} export async function POST(req:Request){const body=await req.json(); const it={id:crypto.randomUUID(),...body}; store.push(it); return new Response(JSON.stringify(it),{headers:{'content-type':'application/json'}})}`;
    files["app/items/page.tsx"] = `'use client'; import { useEffect,useState } from 'react'; export default function Items(){const [items,setItems]=useState<any[]>([]); const [name,setName]=useState(''); useEffect(()=>{fetch('/api/items').then(r=>r.json()).then(setItems)},[]); async function add(){const r=await fetch('/api/items',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})}); const it=await r.json(); setItems([...items,it]); setName(''); } return <div><h2 className='text-2xl font-semibold mb-3'>Items</h2><div className='flex gap-2 mb-3'><input className='border p-2 rounded' value={name} onChange={e=>setName(e.target.value)} /><button onClick={add} className='px-3 py-2 rounded bg-black/10'>Add</button></div><ul>{items.map(i=><li key={i.id}>{i.name}</li>)}</ul></div>}`;
  }
  if (opt.docker) {
    files["Dockerfile"] = `FROM node:20-alpine\nWORKDIR /app\nCOPY package*.json ./\nRUN npm ci\nCOPY . .\nRUN npm run build\nEXPOSE 3000\nCMD [\"npm\",\"start\"]`;
  }
  return files;
}

function expressTemplate(appName:string, desc:string, opt:Options) {
  const files: Record<string,string> = {};
  const pkg = {
    name: slugify(appName) + "-api",
    version: "0.1.0",
    private: true,
    type: "module",
    scripts: { dev: "node --watch ./src/index.js", start: "node ./src/index.js" },
    dependencies: { express: "^4.18.3", cors: "^2.8.5" }
  };
  files["package.json"] = JSON.stringify(pkg, null, 2);
  files["README.md"] = `# ${appName} API\n\n${desc}\n\nGenerated on ${nowISO()} by Colabe AI Notes Builder.`;
  files["src/index.js"] = `import express from 'express'; import cors from 'cors'; const app=express(); app.use(cors()); app.use(express.json()); const items=[]; app.get('/health',(_req,res)=>res.json({ok:true})); app.get('/items',(_req,res)=>res.json(items)); app.post('/items',(req,res)=>{const it={id:crypto.randomUUID(),...req.body}; items.push(it); res.json(it)}); const port=process.env.PORT||3001; app.listen(port, ()=>console.log('API on :'+port));`;
  if (opt.docker) {
    files["Dockerfile"] = `FROM node:20-alpine\nWORKDIR /srv\nCOPY package*.json ./\nRUN npm ci\nCOPY . .\nEXPOSE 3001\nCMD [\"npm\",\"start\"]`;
  }
  return files;
}

function fastapiTemplate(appName:string, desc:string, opt:Options) {
  const files: Record<string,string> = {};
  files["README.md"] = `# ${appName} (FastAPI)\n\n${desc}\n\nGenerated on ${nowISO()} by Colabe AI Notes Builder.`;
  files["requirements.txt"] = `fastapi==0.115.0\nuvicorn==0.30.6`;
  files["app/main.py"] = `from fastapi import FastAPI\nfrom pydantic import BaseModel\nfrom uuid import uuid4\napp = FastAPI(title='${appName}')\nclass Item(BaseModel):\n    name: str\nitems = []\n@app.get('/health')\nasync def health():\n    return {'ok': True}\n@app.get('/items')\nasync def list_items():\n    return items\n@app.post('/items')\nasync def create_item(item: Item):\n    obj = {'id': str(uuid4()), 'name': item.name}\n    items.append(obj)\n    return obj\n`;
  if (opt.docker) {
    files["Dockerfile"] = `FROM python:3.11-slim\nWORKDIR /app\nCOPY requirements.txt ./\nRUN pip install -r requirements.txt\nCOPY ./app ./app\nEXPOSE 8000\nCMD [\"uvicorn\",\"app.main:app\",\"--host\",\"0.0.0.0\",\"--port\",\"8000\"]`;
  }
  return files;
}

export async function POST(req: NextRequest) {
  const { idea, stack, options } = (await req.json()) as Spec;
  const appName = safeName(idea.split('\n')[0] || 'New App');
  const desc = idea;
  const zip = new JSZip();

  let files: Record<string,string> = {};
  if (stack === 'nextjs') files = nextTemplate(appName, desc, options || {});
  else if (stack === 'express') files = expressTemplate(appName, desc, options || {});
  else files = fastapiTemplate(appName, desc, options || {});

  Object.entries(files).forEach(([path, content]) => zip.file(path, content));
  const blob = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  return new Response(blob, {
    status: 200,
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${slugify(appName)}_${stack}.zip"`
    }
  });
}
