import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  const { workspace_id, user_id, role } = await req.json();
  // RLS: only owner/admin should be able to update; enforced in DB via policy (update policy not shown here; use upsert to replace row)
  const { error } = await supabase.from('workspace_members').upsert({ workspace_id, user_id, role });
  if (error) return new Response(error.message, { status: 403 });
  return new Response('OK', { status: 200 });
}
