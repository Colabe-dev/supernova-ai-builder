import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';

export async function GET(_req: NextRequest) {
  const { data, error } = await supabase.from('daily_metrics').select('*').limit(500);
  if (error) return new Response(error.message, { status: 500 });
  return new Response(JSON.stringify({ rows: data }), { status: 200, headers: { 'Content-Type': 'application/json' } });
}
