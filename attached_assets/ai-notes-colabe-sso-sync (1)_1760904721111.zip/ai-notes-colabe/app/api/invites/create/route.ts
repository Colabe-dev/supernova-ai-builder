import { NextRequest } from 'next/server';
import { json } from '../../ai/_shared';
import { supabase } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  const { workspace_id, email, role='viewer' } = await req.json();
  const token = crypto.randomUUID().replace(/-/g,'');
  const { data: { user } } = await (await import('@/lib/supabaseClient')).supabase.auth.getUser();
  // Insert invite (RLS requires admin/owner)
  const { error } = await supabase.from('invites').insert({ token, workspace_id, email, role, created_by: user?.id });
  if (error) return new Response(error.message, { status: 403 });
  return json({ token, url: `/invites/${token}` });
}
