import { NextRequest } from 'next/server';
import { supabase } from '@/lib/supabaseServer';
import { json } from '../../ai/_shared';

export async function POST(req: NextRequest) {
  const { token } = await req.json();
  const { data: inv } = await supabase.from('invites').select('*').eq('token', token).single();
  if (!inv || inv.used_at) return new Response('Invalid or used invite.', { status: 400 });

  // Get auth user via client context is not available here; this route expects the caller to supply user via RLS
  // Insert membership: member inserts self allowed by policy
  const { data: { user } } = await (await import('@/lib/supabaseClient')).supabase.auth.getUser();
  if (!user) return new Response('Not signed in', { status: 401 });
  await supabase.from('workspace_members').upsert({ workspace_id: inv.workspace_id, user_id: user.id, role: inv.role });
  await supabase.from('invites').update({ used_at: new Date().toISOString(), accepted_by: user.id }).eq('token', token);
  return json({ ok: true, workspace_id: inv.workspace_id });
}
