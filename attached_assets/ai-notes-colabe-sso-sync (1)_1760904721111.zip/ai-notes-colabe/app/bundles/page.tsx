'use client';
import { useEffect, useState } from 'react';
import BundleCard from '@/components/BundleCard';
import { useWorkspace } from '@/contexts/WorkspaceContext';

const defaultPlans = [
  { id: 'starter', name: 'Starter Bundle', description: 'Notes + Chat + Images', services: ['docs','chat','images'], price_cents: 0, currency: 'EUR' },
  { id: 'studio', name: 'Studio Bundle', description: 'Everything in Starter + Automations + Analytics', services: ['docs','chat','images','automations','analytics'], price_cents: 1200, currency: 'EUR' },
  { id: 'pro', name: 'Pro Bundle', description: 'All services + Payments integration', services: ['docs','chat','images','automations','analytics','payments'], price_cents: 2400, currency: 'EUR' }
];

export default function BundlesPage() {
  const [plans, setPlans] = useState<any[]>(defaultPlans);
  const { workspaceId } = useWorkspace();

  useEffect(() => {
    // Try to read from DB (if seeded), fallback to defaults
    fetch('/api/colabe/services').catch(()=>{});
  }, []);

  async function activate(bundle_id:string) {
    if (!workspaceId) return alert('Select a workspace first.');
    const res = await fetch('/api/colabe/bundle/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workspace_id: workspaceId, bundle_id })
    });
    const j = await res.json().catch(()=>({}));
    alert(j.message || 'Activated (stub)');
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Ecosystem Bundles</h1>
        <div className="text-sm opacity-70">Workspace: {workspaceId || '(none)'}</div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {plans.map(p => <BundleCard key={p.id} plan={p} onBuy={activate} />)}
      </div>
    </div>
  );
}
