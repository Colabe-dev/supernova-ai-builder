'use client';
import { useState } from 'react';

export default function BillingPage() {
  const [status, setStatus] = useState<string>('');

  async function action(kind:'subscribe'|'coins') {
    setStatus('Processing…');
    const res = await fetch('/api/payments/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind })
    });
    const j = await res.json();
    setStatus(j.message || 'Done');
  }

  return (
    <div className="neon-card p-6 space-y-4">
      <h2 className="text-2xl font-bold">Billing</h2>
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="p-4 bg-black/30 rounded-xl">
          <div className="font-semibold">Pro subscription</div>
          <div className="opacity-70 text-sm">Unlock higher limits, team features, and priority AI.</div>
          <button onClick={()=>action('subscribe')} className="mt-3 px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Subscribe €12/mo</button>
        </div>
        <div className="p-4 bg-black/30 rounded-xl">
          <div className="font-semibold">Buy coins</div>
          <div className="opacity-70 text-sm">Use coins for heavy exports and AI renders.</div>
          <button onClick={()=>action('coins')} className="mt-3 px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Buy 1,000 coins (€10)</button>
        </div>
      </div>
      <div className="text-sm opacity-70">{status}</div>
    </div>
  );
}
