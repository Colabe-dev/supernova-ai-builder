'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useWorkspace } from '@/contexts/WorkspaceContext';

export default function WorkspacesPage() {
  const [name, setName] = useState('My Workspace');
  const [rows, setRows] = useState<any[]>([]);
  const { workspaceId, setWorkspaceId } = useWorkspace();

  async function refresh() {
    const { data } = await supabase.from('workspaces').select('id,name,created_at').order('created_at', { ascending: false });
    setRows(data || []);
  }

  useEffect(() => { refresh(); }, []);

  async function create() {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from('workspaces').insert({ name, created_by: user?.id }).select().single();
    if (!error && data) {
      await supabase.from('workspace_members').insert({ workspace_id: data.id, user_id: user?.id, role: 'owner' });
      setWorkspaceId(data.id);
      setName('My Workspace');
      refresh();
    } else alert(error?.message || 'Failed');
  }

  return (
    <div className="space-y-6">
      <div className="neon-card p-4">
        <h2 className="font-semibold mb-2">Create Workspace</h2>
        <div className="flex gap-2">
          <input className="bg-black/30 p-2 rounded-lg border border-white/10" value={name} onChange={(e)=>setName(e.target.value)} />
          <button onClick={create} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Create</button>
        </div>
      </div>

      <div className="neon-card p-4">
        <h2 className="font-semibold mb-2">Your Workspaces</h2>
        <ul className="space-y-2">
          {rows.map(r => (
            <li key={r.id} className={"flex items-center justify-between bg-black/30 p-3 rounded-lg " + (workspaceId===r.id ? "ring-1 ring-brand/40" : "")}>
              <div>
                <div className="font-medium">{r.name}</div>
                <div className="text-xs opacity-60">{new Date(r.created_at).toLocaleString()}</div>
              </div>
              <div className="flex gap-2">
                <button onClick={()=>setWorkspaceId(r.id)} className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-sm">Use</button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
