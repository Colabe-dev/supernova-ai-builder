'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useWorkspace } from '@/contexts/WorkspaceContext';

const roles = ['owner','admin','editor','viewer'] as const;

export default function MembersPage() {
  const { workspaceId } = useWorkspace();
  const [members, setMembers] = useState<any[]>([]);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<(typeof roles)[number]>('viewer');
  const [inviteURL, setInviteURL] = useState('');

  async function refresh() {
    if (!workspaceId) return;
    const { data, error } = await supabase
      .from('workspace_members')
      .select('user_id, role, users:profiles(email)')
      .eq('workspace_id', workspaceId);
    setMembers(data || []);
  }

  useEffect(() => { refresh(); }, [workspaceId]);

  async function invite() {
    if (!workspaceId) return;
    const res = await fetch('/api/invites/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workspace_id: workspaceId, email, role })
    });
    if (!res.ok) return alert(await res.text());
    const j = await res.json();
    setInviteURL(window.location.origin + j.url);
  }

  async function setMemberRole(user_id:string, newRole:string) {
    if (!workspaceId) return;
    const res = await fetch('/api/workspaces/members/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workspace_id: workspaceId, user_id, role: newRole })
    });
    if (!res.ok) return alert(await res.text());
    refresh();
  }

  return (
    <div className="space-y-6">
      <div className="neon-card p-4">
        <h2 className="font-semibold mb-2">Invite member</h2>
        <div className="flex flex-wrap items-center gap-2">
          <input className="bg-black/30 p-2 rounded-lg border border-white/10" placeholder="email@example.com" value={email} onChange={(e)=>setEmail(e.target.value)} />
          <select className="bg-black/30 p-2 rounded-lg border border-white/10" value={role} onChange={(e)=>setRole(e.target.value as any)}>
            {roles.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
          <button onClick={invite} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Create invite</button>
          {inviteURL && <a className="text-sm underline" href={inviteURL} target="_blank">Copy invite link</a>}
        </div>
      </div>

      <div className="neon-card p-4">
        <h2 className="font-semibold mb-2">Members</h2>
        <table className="w-full text-sm">
          <thead><tr className="text-left opacity-60"><th>Email</th><th>Role</th><th></th></tr></thead>
          <tbody>
            {members.map(m => (
              <tr key={m.user_id} className="border-t border-white/10">
                <td className="py-2">{m.users?.email || m.user_id}</td>
                <td>
                  <select className="bg-black/30 p-1 rounded-lg border border-white/10" value={m.role} onChange={(e)=>setMemberRole(m.user_id, e.target.value)}>
                    {roles.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                </td>
                <td></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
