'use client';
import { useState } from 'react';

export default function LogoStudio() {
  const [prompt, setPrompt] = useState('Neon, cyber-lux Colabe style logo for "AI Notes" on dark.');
  const [note, setNote] = useState('Use your preferred image generator (e.g., SDXL) with this prompt.');

  return (
    <div className="neon-card p-4 space-y-4">
      <h2 className="text-2xl font-bold">Logo Prompt Studio</h2>
      <input className="w-full bg-black/30 p-3 rounded-lg" value={prompt} onChange={(e)=>setPrompt(e.target.value)} />
      <pre className="bg-black/30 p-3 rounded-lg whitespace-pre-wrap">{prompt}</pre>
      <div className="opacity-70 text-sm">{note}</div>
    </div>
  );
}
