'use client';
import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function VoiceStudio() {
  const [recording, setRecording] = useState(false);
  const [audioURL, setAudioURL] = useState<string>('');
  const [text, setText] = useState('');
  const mr = useRef<MediaRecorder | null>(null);
  const chunks = useRef<BlobPart[]>([]);

  async function start() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const rec = new MediaRecorder(stream);
    mr.current = rec;
    chunks.current = [];
    rec.ondataavailable = e => chunks.current.push(e.data);
    rec.onstop = async () => {
      const blob = new Blob(chunks.current, { type: 'audio/webm' });
      const url = URL.createObjectURL(blob);
      setAudioURL(url);
      const fd = new FormData();
      fd.append('file', blob, 'note.webm');
      const res = await fetch('/api/voice/whisper', { method: 'POST', body: fd });
      if (res.ok) {
        const j = await res.json();
        setText(j.text || '');
      } else {
        setText('Transcription unavailable (no API key).');
      }
    };
    rec.start();
    setRecording(true);
  }

  function stop() {
    mr.current?.stop();
    setRecording(false);
  }

  async function saveAsNote() {
    const id = crypto.randomUUID();
    const note = { id, title: text.split('\n')[0] || 'Voice Note', content: text, created_at: new Date().toISOString() };
    // Save locally
    try { await supabase.from('notes').upsert(note, { onConflict: 'id' }); } catch {}
    window.location.href = `/notes/${id}`;
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="neon-card p-4">
        <h2 className="text-xl font-semibold mb-2">Record</h2>
        <div className="flex gap-2">
          {!recording ? (
            <button onClick={start} className="px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Start</button>
          ) : (
            <button onClick={stop} className="px-3 py-2 rounded-xl bg-red-500/30 hover:bg-red-500/40">Stop</button>
          )}
        </div>
        {audioURL && <audio controls src={audioURL} className="mt-4 w-full" />}
      </div>
      <div className="neon-card p-4">
        <h2 className="text-xl font-semibold mb-2">Transcription</h2>
        <textarea className="w-full h-80 bg-black/30 p-3 rounded-lg" value={text} onChange={(e)=>setText(e.target.value)} />
        <button onClick={saveAsNote} className="mt-3 px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Save as Note</button>
      </div>
    </div>
  );
}
