'use client';
import { useState } from 'react';
import { callAI } from '@/lib/ai';

export default function EmailStudio() {
  const [src, setSrc] = useState<string>('');
  const [out, setOut] = useState<string>('');

  async function draft() {
    const res = await callAI('structure', { text: src });
    const body = `Subject: ${src.split('\n')[0] || 'Follow-up'}\n\n${res.text}\n\nBest regards,\n`;
    setOut(body);
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="neon-card p-4">
        <h2 className="font-semibold mb-2">From Note</h2>
        <textarea className="w-full h-80 bg-black/30 p-3 rounded-lg" value={src} onChange={(e)=>setSrc(e.target.value)} />
        <button onClick={draft} className="mt-3 px-3 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Draft Email</button>
      </div>
      <div className="neon-card p-4">
        <h2 className="font-semibold mb-2">Draft Output</h2>
        <textarea className="w-full h-80 bg-black/30 p-3 rounded-lg" value={out} onChange={(e)=>setOut(e.target.value)} />
        <div className="text-xs opacity-60 mt-2">Copy/paste into your mail client.</div>
      </div>
    </div>
  );
}
