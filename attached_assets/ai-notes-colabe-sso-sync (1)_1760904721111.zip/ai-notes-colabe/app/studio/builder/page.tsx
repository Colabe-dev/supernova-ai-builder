'use client';
import { useState } from 'react';

type Stack = 'nextjs' | 'express' | 'fastapi';

export default function BuilderStudio() {
  const [idea, setIdea] = useState('A minimal SaaS landing + notes CRUD');
  const [stack, setStack] = useState<Stack>('nextjs');
  const [tailwind, setTailwind] = useState(true);
  const [auth, setAuth] = useState(true);
  const [crud, setCrud] = useState(true);
  const [docker, setDocker] = useState(true);
  const [busy, setBusy] = useState(false);

  async function generate() {
    setBusy(true);
    try {
      const res = await fetch('/api/builder/zip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea, stack, options: { tailwind, auth, crud, docker } })
      });
      if (!res.ok) {
        const text = await res.text();
        alert(text || 'Failed');
        return;
      }
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `project_${stack}.zip`;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(()=>URL.revokeObjectURL(a.href), 3000);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="neon-card p-6 space-y-4">
      <h2 className="text-2xl font-bold">Idea → Code: Project Builder</h2>
      <textarea className="w-full h-32 bg-black/30 p-3 rounded-lg" value={idea} onChange={(e)=>setIdea(e.target.value)} placeholder="Describe your idea. Tech constraints, pages, API, DB, etc." />
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="bg-black/30 p-3 rounded-xl space-y-2">
          <div className="text-sm opacity-70">Stack</div>
          <select className="w-full bg-black/30 p-2 rounded-lg border border-white/10" value={stack} onChange={(e)=>setStack(e.target.value as Stack)}>
            <option value="nextjs">Next.js + TypeScript</option>
            <option value="express">Node Express API</option>
            <option value="fastapi">Python FastAPI</option>
          </select>
        </div>
        <div className="bg-black/30 p-3 rounded-xl grid grid-cols-2 gap-2">
          <label className="flex items-center gap-2"><input type="checkbox" checked={tailwind} onChange={(e)=>setTailwind(e.target.checked)} />Tailwind</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={auth} onChange={(e)=>setAuth(e.target.checked)} />Auth</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={crud} onChange={(e)=>setCrud(e.target.checked)} />CRUD example</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={docker} onChange={(e)=>setDocker(e.target.checked)} />Dockerfile</label>
        </div>
      </div>
      <button onClick={generate} disabled={busy} className="px-4 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">{busy ? 'Generating…' : 'Generate & Download ZIP'}</button>
      <div className="text-xs opacity-60">
        Results are **offline-capable**. If `OPENAI_API_KEY` is set, future versions can embellish code with AI.
      </div>
    </div>
  );
}
