export default function Exports() {
  return (
    <div className="neon-card p-6">
      <h2 className="text-2xl font-bold mb-2">Exports</h2>
      <p className="opacity-80">Coming soon: Export to PDF, DOCX, HTML, and Markdown directly from your notes.</p>
    </div>
  );
}
