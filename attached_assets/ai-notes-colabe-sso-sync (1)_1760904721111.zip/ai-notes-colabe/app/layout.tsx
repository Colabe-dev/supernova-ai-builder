import './globals.css';
import type { Metadata } from 'next';
import NeonGridBackground from '@/components/NeonGridBackground';
import { Navbar } from '@/components/Navbar';
import { WorkspaceProvider } from '@/contexts/WorkspaceContext';

export const metadata: Metadata = {
  title: 'Colabe AI Notes',
  description: 'AI-first notes that export everywhere. Offline-ready.',
  manifest: '/manifest.json',
  icons: { icon: '/favicon.ico' },
  themeColor: '#0a84ff'
};

export default function RootLayout({ children }:{ children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <NeonGridBackground />
        <Navbar />
        <WorkspaceProvider>
          <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
        </WorkspaceProvider>
      </body>
    </html>
  );
}
