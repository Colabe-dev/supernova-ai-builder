import Link from 'next/link';

export default function Home() {
  return (
    <div className="grid lg:grid-cols-2 gap-6 items-center">
      <div className="space-y-6">
        <h1 className="text-4xl font-extrabold leading-tight">
          AI-first notes with <span className="text-brand">structure</span>, <span className="text-brand">exports</span>, and <span className="text-brand">offline</span> sync.
        </h1>
        <p className="opacity-80">
          Turn messy thoughts into polished docs, code, diagrams, and emails. Built for the Colabe ecosystem—ready for Supabase auth and Colabe Payments.
        </p>
        <div className="flex gap-3">
          <Link href="/notes" className="px-4 py-2 rounded-xl bg-brand/30 hover:bg-brand/40">Open Notes</Link>
          <Link href="/studio/email" className="px-4 py-2 rounded-xl border border-white/10 hover:bg-white/5">Email from Note</Link>
        </div>
        <div className="text-xs opacity-60">PWA enabled · Works offline · Europe/Madrid timezone</div>
      </div>
      <div className="neon-card p-6 neon-glow">
{`# Welcome to Colabe AI Notes

- Write in Markdown
- Use **AI Command Bar** to structure, summarize, translate
- Create diagrams with \`mermaid\` code blocks
- Export to PDF/DOCX/MD/HTML (coming in /exports)
- Works offline. Syncs when you're back online.
`}
      </div>
    </div>
  );
}
