'use client';
import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

export default function AcceptInvitePage() {
  const { token } = useParams() as { token: string };
  const [msg, setMsg] = useState('Accepting invite…');
  const router = useRouter();

  useEffect(() => {
    (async () => {
      const res = await fetch('/api/invites/accept', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) });
      if (res.ok) {
        setMsg('Invite accepted. Redirecting…');
        setTimeout(()=>router.push('/workspaces'), 1200);
      } else {
        setMsg(await res.text());
      }
    })();
  }, [token]);

  return <div className="neon-card p-6">{msg}</div>;
}
