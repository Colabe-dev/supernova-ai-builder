'use client';
import { useEffect, useState } from 'react';
import ServiceCard from '@/components/ServiceCard';
import { useWorkspace } from '@/contexts/WorkspaceContext';

export default function EcosystemHub() {
  const [services, setServices] = useState<any[]>([]);
  const [health, setHealth] = useState<any[]>([]);
  const { workspaceId } = useWorkspace();

  useEffect(() => {
    fetch('/api/colabe/services').then(r=>r.json()).then(j=>setServices(j.services));
    fetch('/api/colabe/health').then(r=>r.json()).then(j=>setHealth(j.statuses || []));
  }, []);

  async function onConnect(service_id:string) {
    if (!workspaceId) return alert('Select a workspace first.');
    const external_account_id = prompt('Enter external account id (MVP)') || '';
    const res = await fetch('/api/colabe/connect', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workspace_id: workspaceId, service_id, external_account_id, scopes: [] })
    });
    if (!res.ok) alert(await res.text());
    else alert('Linked!');
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Colabe Ecosystem</h1>
        <div className="text-sm opacity-70">Workspace: {workspaceId || '(none)'}</div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {services.map(s => {
          const st = health.find((h:any)=>h.id===s.id)?.status || 'unknown';
          return (
            <div key={s.id}>
              <div className="text-xs opacity-60 mb-1">Status: {st}</div>
              <ServiceCard svc={s} onConnect={onConnect} />
            </div>
          );
        })}
      </div>
    </div>
  );
}
