'use client';
import { useEffect, useState } from 'react';

export default function ChatUI() {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    setUrl(process.env.NEXT_PUBLIC_COLABE_CHAT_URL || (window as any).COLABE_SERVICE_CHAT_URL || '');
  }, []);
  return (
    <div className="neon-card p-6">
      <h2 className="text-2xl font-bold mb-3">Colabe Chat</h2>
      {url ? <iframe src={url} className="w-full h-[70vh] rounded-xl border border-white/10" /> : <div className="opacity-70">Configure COLABE_SERVICE_CHAT_URL to embed Chat.</div>}
    </div>
  );
}
