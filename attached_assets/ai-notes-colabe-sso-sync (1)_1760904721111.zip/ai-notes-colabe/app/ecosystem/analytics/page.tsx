'use client';
import { useEffect, useState } from 'react';
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

type Row = { day: string; service_id: string; type: string; events: number };

export default function Analytics() {
  const [rows, setRows] = useState<Row[]>([]);
  useEffect(() => { fetch('/api/metrics/daily').then(r=>r.json()).then(j=>setRows(j.rows || [])); }, []);
  // Format for chart: group by day, sum events
  const byDay: Record<string, number> = {};
  rows.forEach(r => { byDay[r.day] = (byDay[r.day] || 0) + Number(r.events || 0); });
  const data = Object.entries(byDay).map(([day, events]) => ({ day, events }));

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Usage Analytics</h1>
      <div className="neon-card p-4">
        <div className="text-sm opacity-70 mb-2">Total ecosystem events / day</div>
        <div className="w-full h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="events" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
