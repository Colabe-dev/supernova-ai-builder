import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: ['class'],
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#0a84ff',
          yellow: '#ffcc00',
          accent: '#00ffd5'
        }
      },
      backgroundImage: {
        'neon-grid':
          'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.06) 1px, transparent 1px)'
      },
      backgroundSize: {
        'grid': '32px 32px'
      },
      animation: {
        'hue-shift': 'hue 20s linear infinite',
        'float': 'float 6s ease-in-out infinite'
      },
      keyframes: {
        hue: { '0%': { filter: 'hue-rotate(0deg)' }, '100%': { filter: 'hue-rotate(360deg)' } },
        float: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-4px)' }
        }
      }
    }
  },
  plugins: []
}
export default config;
