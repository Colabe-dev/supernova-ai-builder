import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { authMiddleware } from './src/security/auth.js';
import { limiterRead, limiterWrite } from './src/security/ratelimit.js';
import devFsRouter from './src/dev/fs.js';
import devTermRouter from './src/dev/terminal.js';
import tokensRouter, { getTokens } from './src/design/tokens.js';
import diffsRouter from './src/dev/diffs.js';
import sseRouter from './src/dev/sse.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Health
app.get('/healthz', (req, res) => res.json({ ok: true, ts: Date.now() }));

// Auth (dev-open by default)
app.use(authMiddleware);

// SSE events for live preview
app.use('/api/dev/events', sseRouter);

// Dev FS + Terminal (dev-only)
if (process.env.NODE_ENV !== 'production') {
  app.use('/api/dev/fs', limiterWrite, devFsRouter);
  app.use('/api/dev/terminal', limiterRead, devTermRouter);
}

// Design tokens
app.use('/api/design/tokens', limiterWrite, tokensRouter);

// Diffs
app.use('/api/dev/diffs', limiterRead, diffsRouter);

// Serve static client build if present
const publicDir = path.join(__dirname, 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
  fs.writeFileSync(path.join(publicDir, '.keep'), '');
}
app.use(express.static(publicDir));

// Fallback index.html
app.get('*', (req, res) => {
  const indexPath = path.join(publicDir, 'index.html');
  if (fs.existsSync(indexPath)) res.sendFile(indexPath);
  else res.send('<!doctype html><html><body><h1>Supernova Server</h1><p>Client not built yet.</p></body></html>');
});

const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`[server] listening on :${port}`));
