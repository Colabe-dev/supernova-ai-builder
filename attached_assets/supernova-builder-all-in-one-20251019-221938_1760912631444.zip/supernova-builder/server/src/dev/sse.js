import { Router } from 'express';

const clients = new Set();
export function publishEvent(evt) {
  const line = `data: ${JSON.stringify(evt)}\n\n`;
  for (const res of clients) res.write(line);
}

const r = Router();
r.get('/', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive'
  });
  res.write('\n');
  clients.add(res);
  req.on('close', () => clients.delete(res));
});
export default r;
