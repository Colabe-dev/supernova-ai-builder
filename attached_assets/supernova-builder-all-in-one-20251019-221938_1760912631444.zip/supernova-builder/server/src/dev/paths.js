import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(path.join(__dirname, '..', '..', '..'));

const ALLOWED = [
  'client/src',
  'server',
  'shared',
  'public'
].map(p => path.join(ROOT, p));

export function normalizeAllowed(p) {
  const abs = path.resolve(ROOT, p);
  for (const base of ALLOWED) {
    if (abs.startsWith(base)) return abs;
  }
  throw new Error('path not allowed');
}

export function ensureDir(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

export const STATE_DIR = path.join(ROOT, 'server', '.supernova');
export function statePath(p) {
  if (!fs.existsSync(STATE_DIR)) fs.mkdirSync(STATE_DIR, { recursive: true });
  return path.join(STATE_DIR, p);
}
