import { Router } from 'express';
import { listDiffs } from './diffStore.js';

const r = Router();
r.get('/', (req, res) => res.json({ diffs: listDiffs() }));
export default r;
