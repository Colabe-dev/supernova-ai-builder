import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import { normalizeAllowed, ensureDir } from './paths.js';
import { recordDiff } from './diffStore.js';
import { diffLines } from 'diff';
import { publishEvent } from './sse.js';

const r = Router();

r.get('/list', (req, res) => {
  try {
    const rel = req.query.path || '';
    const abs = normalizeAllowed(rel || 'client/src');
    const entries = fs.readdirSync(abs, { withFileTypes: true })
      .filter(d => !d.name.startsWith('.'))
      .map(d => ({
        name: d.name,
        type: d.isDirectory() ? 'dir' : 'file'
      }));
    res.json({ ok: true, base: abs, entries });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

r.get('/read', (req, res) => {
  try {
    const abs = normalizeAllowed(req.query.path);
    const content = fs.readFileSync(abs, 'utf-8');
    res.json({ ok: true, path: abs, content });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

r.post('/write', (req, res) => {
  try {
    const { path: rel, content } = req.body || {};
    const abs = normalizeAllowed(rel);
    const before = fs.existsSync(abs) ? fs.readFileSync(abs, 'utf-8') : '';
    ensureDir(abs);
    fs.writeFileSync(abs, content ?? '', 'utf-8');

    // diff
    const unified = [];
    const parts = diffLines(before, content ?? '');
    for (const p of parts) {
      if (p.added) unified.push('+' + p.value);
      else if (p.removed) unified.push('-' + p.value);
    }
    recordDiff({ path: rel, ts: Date.now(), diff: unified.join('') });

    // notify live preview
    publishEvent({ type: 'fs:write', path: rel, ts: Date.now() });

    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

export default r;
