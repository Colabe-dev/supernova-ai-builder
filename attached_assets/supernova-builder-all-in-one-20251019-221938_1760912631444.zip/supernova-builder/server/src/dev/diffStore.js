import fs from 'fs';
import { statePath } from './paths.js';

const DIFFS = statePath('diffs.json');

function readAll() {
  if (!fs.existsSync(DIFFS)) return [];
  try { return JSON.parse(fs.readFileSync(DIFFS, 'utf-8')); }
  catch { return []; }
}
function writeAll(arr) {
  fs.writeFileSync(DIFFS, JSON.stringify(arr, null, 2));
}

export function recordDiff(entry) {
  const arr = readAll();
  arr.push(entry);
  arr.sort((a,b) => b.ts - a.ts);
  writeAll(arr.slice(0, 2000)); // cap
}
export function listDiffs() { return readAll(); }
