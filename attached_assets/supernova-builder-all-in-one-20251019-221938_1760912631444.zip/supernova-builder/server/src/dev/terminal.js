import { Router } from 'express';
import { spawn } from 'child_process';

const ALLOW = new Map([
  ['node -v', ['node','-v']],
  ['npm -v', ['npm','-v']],
  ['npm run build', ['npm','run','build']],
  ['npm run lint', ['npm','run','lint']]
]);

const r = Router();
r.post('/exec', (req, res) => {
  const { cmd } = req.body || {};
  const spec = ALLOW.get(cmd);
  if (!spec) return res.status(400).json({ error: 'command not allowed' });

  const [bin, ...args] = spec;
  const child = spawn(bin, args, { cwd: process.cwd(), shell: false });
  let out = '', err = '';
  child.stdout.on('data', d => out += d.toString());
  child.stderr.on('data', d => err += d.toString());
  child.on('close', code => {
    res.json({ ok: code === 0, code, stdout: out, stderr: err });
  });
});
export default r;
