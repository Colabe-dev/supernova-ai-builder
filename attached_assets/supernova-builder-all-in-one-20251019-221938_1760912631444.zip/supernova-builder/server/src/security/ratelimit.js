import rateLimit from 'express-rate-limit';

const windowMs = parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000', 10);
export const limiterRead = rateLimit({
  windowMs,
  limit: parseInt(process.env.RATE_LIMIT_READ_MAX || '120', 10)
});
export const limiterWrite = rateLimit({
  windowMs,
  limit: parseInt(process.env.RATE_LIMIT_WRITE_MAX || '30', 10)
});
