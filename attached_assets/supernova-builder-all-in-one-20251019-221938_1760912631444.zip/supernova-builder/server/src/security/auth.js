import jwt from 'jsonwebtoken';

export function authMiddleware(req, res, next) {
  const open = (process.env.DEV_AUTH_OPEN || 'true') === 'true';
  if (open) return next();

  const hdr = req.headers['authorization'] || '';
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing token' });

  try {
    // For production wire a proper JWKS verifier. Here, accept HS256 with a dev secret.
    const verified = jwt.verify(token, process.env.JWT_DEV_SECRET || 'dev-secret', {
      audience: process.env.AUTH_AUDIENCE || 'supernova-api',
      issuer: process.env.AUTH_ISSUER || 'http://localhost:3001/auth'
    });
    req.user = verified;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'invalid token' });
  }
}
