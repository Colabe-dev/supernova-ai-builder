import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TOKENS = path.resolve(path.join(__dirname, '..', '..', 'design.tokens.json'));

export function getTokens() {
  if (!fs.existsSync(TOKENS)) {
    const defaults = { meta: { brand: 'Supernova' }, theme: { bg: '#0b1f3a', text: '#ffffff', primary: '#fec72e' } };
    fs.writeFileSync(TOKENS, JSON.stringify(defaults, null, 2));
    return defaults;
  }
  return JSON.parse(fs.readFileSync(TOKENS, 'utf-8'));
}

const r = Router();
r.get('/', (req, res) => res.json(getTokens()));
r.post('/', (req, res) => {
  const t = req.body;
  fs.writeFileSync(TOKENS, JSON.stringify(t, null, 2));
  res.json({ ok: true });
});
export default r;
