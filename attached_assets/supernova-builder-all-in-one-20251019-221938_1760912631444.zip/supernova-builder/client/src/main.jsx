import React from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider, Link } from 'react-router-dom'
import App from './pages/App.jsx'
import Dev from './pages/Dev.jsx'
import Diff from './pages/Diff.jsx'

const router = createBrowserRouter([
  { path: '/', element: <App/> },
  { path: '/dev', element: <Dev/> },
  { path: '/diff', element: <Diff/> },
])

createRoot(document.getElementById('root')).render(<RouterProvider router={router} />)
