import React, { useEffect } from 'react'

export default function App() {
  useEffect(() => {
    fetch('/api/design/tokens').then(r=>r.json()).then(t => {
      const theme = t.theme || {}
      if (theme.bg) document.documentElement.style.setProperty('--bg', theme.bg)
      if (theme.text) document.documentElement.style.setProperty('--text', theme.text)
      if (theme.primary) document.documentElement.style.setProperty('--primary', theme.primary)
    })
  }, [])
  return (
    <>
      <header>
        <a href="/">Home</a>
        <a href="/dev">Dev Console</a>
        <a href="/diff">Diffs</a>
      </header>
      <div style={{padding:16}}>
        <h1>Supernova Builder</h1>
        <p>Open <a href="/dev">Dev Console</a> to edit files and preview.</p>
      </div>
    </>
  )
}
