import React, { useEffect, useState, useRef } from 'react'
import Editor from '@monaco-editor/react'

function FileTree({ base='client/src', onSelect }) {
  const [path, setPath] = useState(base)
  const [entries, setEntries] = useState([])
  const [stack, setStack] = useState([])

  const load = async (p) => {
    const q = new URLSearchParams({ path: p })
    const res = await fetch('/api/dev/fs/list?'+q)
    const data = await res.json()
    setEntries(data.entries || [])
    setPath(p)
  }
  useEffect(()=>{ load(base) }, [])

  const enter = (name) => {
    const np = path + '/' + name
    setStack(s => [...s, path])
    load(np)
  }
  const up = () => { const prev = stack.pop(); if (prev) { setStack(stack); load(prev) } }

  return (
    <div className="sidebar">
      <div className="row" style={{padding:8}}>
        <button className="btn" onClick={up}>Up</button>
        <span style={{opacity:.7, fontSize:12}}>{path}</span>
      </div>
      {entries.map(e => (
        <div key={e.name} style={{padding:'6px 12px', cursor:'pointer'}} onClick={()=> e.type==='dir'? enter(e.name) : onSelect(path + '/' + e.name)}>
          {e.type==='dir' ? '📁' : '📄'} {e.name}
        </div>
      ))}
    </div>
  )
}

export default function Dev(){
  const [file, setFile] = useState(null)
  const [content, setContent] = useState('')
  const [term, setTerm] = useState({cmd:'node -v', out:''})
  const iframeRef = useRef(null)

  const loadFile = async (p) => {
    const q = new URLSearchParams({ path: p })
    const res = await fetch('/api/dev/fs/read?'+q)
    const data = await res.json()
    setFile(p); setContent(data.content || '')
  }

  const saveFile = async () => {
    if (!file) return
    await fetch('/api/dev/fs/write', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ path:file, content }) })
  }

  const runCmd = async () => {
    const res = await fetch('/api/dev/terminal/exec', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ cmd: term.cmd }) })
    const data = await res.json()
    setTerm(t => ({...t, out: (data.stdout||'') + (data.stderr||'')}))
  }

  useEffect(() => {
    const ev = new EventSource('/api/dev/events')
    ev.onmessage = (e) => {
      try {
        const payload = JSON.parse(e.data)
        if (payload.type === 'fs:write') {
          // refresh iframe to reflect changes
          if (iframeRef.current) iframeRef.current.src = iframeRef.current.src
        }
      } catch {}
    }
    return () => ev.close()
  }, [])

  // Design tokens editor
  const [tokens, setTokens] = useState(null)
  useEffect(()=>{ fetch('/api/design/tokens').then(r=>r.json()).then(setTokens) }, [])
  const saveTokens = async () => {
    await fetch('/api/design/tokens', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(tokens) })
  }

  return (
    <>
      <header>
        <a href="/">Home</a>
        <a href="/dev">Dev Console</a>
        <a href="/diff">Diffs</a>
      </header>
      <div className="app">
        <FileTree onSelect={loadFile}/>
        <div className="content">
          <div className="row" style={{marginBottom:8}}>
            <button className="btn" onClick={saveFile}>Save</button>
            <input className="input" value={file||''} readOnly />
          </div>
          <div style={{height:'40vh', border:'1px solid rgba(255,255,255,0.15)', borderRadius:8, overflow:'hidden', marginBottom:8}}>
            <Editor language="javascript" value={content} onChange={setContent} options={{fontSize:14, minimap:{enabled:false}}} />
          </div>

          <div className="row" style={{gap:16}}>
            <div style={{flex:1}}>
              <h3>Terminal</h3>
              <div className="row">
                <select className="input" value={term.cmd} onChange={e=>setTerm({...term, cmd:e.target.value})}>
                  <option>node -v</option>
                  <option>npm -v</option>
                  <option>npm run build</option>
                  <option>npm run lint</option>
                </select>
                <button className="btn" onClick={runCmd}>Run</button>
              </div>
              <pre style={{whiteSpace:'pre-wrap', background:'rgba(0,0,0,0.3)', padding:8, borderRadius:8, marginTop:8}}>{term.out}</pre>
            </div>
            <div style={{flex:1}}>
              <h3>Live Preview</h3>
              <iframe ref={iframeRef} title="preview" src="/index.html" style={{width:'100%', height:300, background:'#fff', borderRadius:8}}/>
            </div>
          </div>

          <div style={{marginTop:16}}>
            <h3>Design Mode</h3>
            <div className="row">
              <label>bg</label><input className="input" value={tokens?.theme?.bg||''} onChange={e=>setTokens(t=>({...t, theme:{...t.theme, bg:e.target.value}}))}/>
              <label>text</label><input className="input" value={tokens?.theme?.text||''} onChange={e=>setTokens(t=>({...t, theme:{...t.theme, text:e.target.value}}))}/>
              <label>primary</label><input className="input" value={tokens?.theme?.primary||''} onChange={e=>setTokens(t=>({...t, theme:{...t.theme, primary:e.target.value}}))}/>
              <button className="btn" onClick={saveTokens}>Save Theme</button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
