import React, { useEffect, useState } from 'react'

export default function Diff(){
  const [diffs, setDiffs] = useState([])
  useEffect(()=>{
    fetch('/api/dev/diffs').then(r=>r.json()).then(d=> setDiffs(d.diffs||[]))
  },[])
  return (
    <>
      <header>
        <a href="/">Home</a>
        <a href="/dev">Dev Console</a>
        <a href="/diff">Diffs</a>
      </header>
      <div style={{padding:16}}>
        <h2>Recent Changes</h2>
        {diffs.map((d,i)=> (
          <details key={i} style={{margin:'8px 0', background:'rgba(255,255,255,0.05)', padding:8, borderRadius:8}}>
            <summary>{new Date(d.ts).toLocaleString()} — {d.path}</summary>
            <pre style={{whiteSpace:'pre-wrap'}}>{d.diff}</pre>
          </details>
        ))}
      </div>
    </>
  )
}
