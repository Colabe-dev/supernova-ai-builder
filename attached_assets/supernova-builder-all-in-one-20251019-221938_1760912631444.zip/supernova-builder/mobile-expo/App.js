import React from 'react';
import { SafeAreaView, Text } from 'react-native';
export default function App(){
  return <SafeAreaView><Text>Supernova Mobile — Sprint base</Text></SafeAreaView>;
}
