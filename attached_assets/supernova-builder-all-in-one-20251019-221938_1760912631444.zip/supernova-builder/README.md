# Supernova Builder — All-in-One (20251019-221938)

A full, **copy-paste runnable** builder stack:
- **Server** (Express): `/dev` APIs for file editing, diffs, design tokens, terminal (whitelist), SSE events, health.
- **Client** (Vite + React + Monaco): `/dev` console, `/diff` viewer, theme editor & live preview.
- **Mobile** (Expo skeleton): Ready for later Sprints.
- **Deploy (Helm + Helmfile)**: minimal chart + helmfile for dev/staging/prod.

## Quick start (local)

### 1) Server
```bash
cd server
npm install
npm run dev
```
Server on `http://localhost:3001`

### 2) Client
```bash
cd client
npm install
npm run dev
```
Client on `http://localhost:5173` (Vite dev). It proxies API calls to `3001`.

**Prod build:** `npm run build && npm run preview` (client) — or copy `client/dist` into `server/public` for single-process hosting.

## Security Defaults
- `DEV_AUTH_OPEN=true` in `.env` → disables JWT verification for local dev.
- Terminal **whitelist only**: `node -v`, `npm -v`, `npm run build`, `npm run lint`.
- File ops **whitelist** paths: `client/src`, `server`, `shared`, `public`.
- Path traversal blocked via normalization + allowlist checks.
- Diff store persisted to `server/.supernova/diffs.json`.

## Deploy (quick Helmfile path)
```bash
export IMAGE_REPO=ghcr.io/<org>/supernova-server
export IMAGE_TAG=dev-local
cd helmfile && helmfile -e dev apply
```

See `deploy/` and `helmfile/` folders for details.
