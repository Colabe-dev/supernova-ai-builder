# Supernova — Seed Hook + Exponential Retry Patch

This patch adds:
1) **Data Seed Hook** (`seed-hook.yaml`) — optional Helm hook Job for seeding data.
2) **Exponential Retry Policy** — opt‑in wrapper for both `migrate` and `seed` Jobs.

It targets **both** chart locations:
- `supernova-server/...` (standalone chart)
- `helmfile/charts/supernova-server/...` (embedded chart used by Helmfile)

## Enable (values)
```yaml
# Migrations retry (optional)
migrations:
  enabled: true
  retry:
    exponential:
      enabled: true
      initialSeconds: 2
      maxSeconds: 60
      maxAttempts: 6

# Seed hook
seeds:
  enabled: true
  when: ["post-install","post-upgrade"]  # or ["post-install"] only
  weight: 20
  command: ["node","db/seed.mjs"]
  retry:
    exponential:
      enabled: true
      initialSeconds: 2
      maxSeconds: 60
      maxAttempts: 6
```

> Default behavior remains unchanged unless you set `*.retry.exponential.enabled=true` or `seeds.enabled=true`.

## Apply
Copy files from this patch into your repo (choose one path):
- `supernova-server/templates/*` (standalone chart), and example values.
- `helmfile/charts/supernova-server/templates/*` (embedded chart), and example values.

Then deploy as usual (Helm or Helmfile). Hooks fire automatically on install/upgrade.
