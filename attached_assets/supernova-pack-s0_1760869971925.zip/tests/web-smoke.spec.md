Open /, click Buy Pro (stub), send chat message, expect render.
