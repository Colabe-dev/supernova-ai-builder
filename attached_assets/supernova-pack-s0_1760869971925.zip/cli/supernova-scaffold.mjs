#!/usr/bin/env node
import fs from 'fs'
import path from 'path'
import url from 'url'
const __dirname = path.dirname(url.fileURLToPath(import.meta.url))
const root = path.resolve(__dirname, '..')

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true })
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name)
    const d = path.join(dest, entry.name)
    if (entry.isDirectory()) copyDir(s, d)
    else fs.copyFileSync(s, d)
  }
}
function writeEnv(dest, env) {
  const lines = Object.entries(env||{}).map(([k,v]) => `${k}=${v}`)
  fs.writeFileSync(dest, lines.join('\n') + '\n')
}
function main() {
  const args = process.argv.slice(2)
  const specIdx = args.indexOf('--spec'), outIdx = args.indexOf('--out')
  if (specIdx === -1 || outIdx === -1) {
    console.error('Usage: node supernova-scaffold.mjs --spec ./project.json --out ./out'); process.exit(1)
  }
  const spec = JSON.parse(fs.readFileSync(path.resolve(args[specIdx+1]), 'utf8'))
  const outDir = path.resolve(args[outIdx+1])
  fs.mkdirSync(outDir, { recursive: true })

  // targets
  if (spec.targets?.web_next) {
    copyDir(path.join(root,'templates','web-next'), path.join(outDir,'web-next'))
    copyDir(path.join(root,'sdk'), path.join(outDir,'web-next','sdk'))
    writeEnv(path.join(outDir,'web-next','.env.example'), spec.env||{})
  }
  if (spec.targets?.mobile_expo) {
    copyDir(path.join(root,'templates','mobile-expo'), path.join(outDir,'mobile-expo'))
    copyDir(path.join(root,'sdk'), path.join(outDir,'mobile-expo','sdk'))
    writeEnv(path.join(outDir,'mobile-expo','.env.example'), spec.env||{})
  }
  // shared
  copyDir(path.join(root,'src'), path.join(outDir,'src'))
  copyDir(path.join(root,'publish'), path.join(outDir,'publish'))
  copyDir(path.join(root,'tests'), path.join(outDir,'tests'))
  copyDir(path.join(root,'docs'), path.join(outDir,'docs'))
  fs.writeFileSync(path.join(outDir,'project.spec.json'), JSON.stringify(spec,null,2))
  console.log('Scaffolded to', outDir)
}
main()
