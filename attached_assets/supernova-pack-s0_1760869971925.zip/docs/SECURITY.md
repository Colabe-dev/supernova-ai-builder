RLS ON, secrets via env, webhook signature verification utility in payments, two-person rule to be enforced in CI.
