Endpoints: /payments/*, /subscriptions/*, /coins/* ; chat REST+WS; registry JSON; trigger bus publish.
