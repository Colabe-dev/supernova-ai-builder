Collab Payments / Chat / Service Registry / Trigger Bus patterns; set envs to point to real endpoints.
