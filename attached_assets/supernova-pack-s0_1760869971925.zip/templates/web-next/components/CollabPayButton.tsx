'use client'
import { useState } from 'react'
import { createPayments } from '../sdk/collab/payments'
export function CollabPayButton({ amount, label, coins=false }:{ amount:number, label:string, coins?:boolean }){
  const [busy,setBusy]=useState(false)
  async function run(){
    setBusy(true)
    try{
      const cfg:any = { payApiBase: process.env.NEXT_PUBLIC_COLLAB_PAY_API_BASE||'', chatWsBase:'', chatRestBase:'', registryUrl:'', triggerBusUrl:'', jwksUrl:'' }
      const pay = createPayments(cfg)
      if(coins) await pay.creditCoins(amount,'topup'); else await pay.createIntent(amount,'EUR')
      alert('Success (stub). Wire real checkout.')
    }catch(e:any){ alert('Payment failed: '+e.message) } finally{ setBusy(false) }
  }
  return <button className="btn" onClick={run} disabled={busy}>{busy?'Processing…':label}</button>
}
