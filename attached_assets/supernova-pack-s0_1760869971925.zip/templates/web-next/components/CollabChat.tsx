'use client'
import { useEffect, useState } from 'react'
import { createChat } from '../sdk/collab/chat'
export function CollabChat({ channel }:{ channel:string }){
  const [msgs,setMsgs]=useState<any[]>([]); const [text,setText]=useState('')
  useEffect(()=>{ const cfg:any={ chatWsBase: process.env.NEXT_PUBLIC_COLLAB_CHAT_WS||'wss://echo.websocket.events', chatRestBase: process.env.NEXT_PUBLIC_COLLAB_CHAT_REST||'', payApiBase:'', registryUrl:'', triggerBusUrl:'', jwksUrl:'' }
    const chat=createChat(cfg); let ws:WebSocket|null=null; try{ ws=chat.connect(channel,(m:any)=>setMsgs(v=>[...v,m])) }catch{} return ()=>{ try{ws?.close()}catch{} }
  },[channel])
  return(<div><div className="h-48 overflow-auto p-2 bg-white/5 rounded-xl">{msgs.map((m,i)=>(<div key={i} className={m.me?'text-sunYellow':'text-white'}>{m.content??JSON.stringify(m)}</div>))}</div>
  <div className="flex gap-2 mt-2"><input className="flex-1 px-3 py-2 rounded-lg text-black" value={text} onChange={e=>setText(e.target.value)} placeholder="Type…" /><button className="btn" onClick={()=>{setMsgs(v=>[...v,{content:text,me:true}]);setText('')}}>Send</button></div></div>)
}
