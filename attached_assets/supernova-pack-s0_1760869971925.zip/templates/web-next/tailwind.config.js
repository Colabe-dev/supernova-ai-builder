module.exports = { content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"], theme:{ extend:{ colors:{ collabBlue:'#0b1f3a', sunYellow:'#fec72e' } } }, plugins:[] }
