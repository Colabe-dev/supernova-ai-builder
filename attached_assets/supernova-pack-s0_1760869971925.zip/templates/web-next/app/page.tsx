'use client'
import { CollabPayButton } from '../components/CollabPayButton'
import { CollabChat } from '../components/CollabChat'
export default function Home(){
  return(<main className="min-h-screen p-8">
    <header className="flex items-center justify-between mb-8"><h1 className="text-2xl font-bold">Supernova — Collab Builder</h1><a className="btn" href="/publish">Publish</a></header>
    <section className="grid md:grid-cols-2 gap-6">
      <div className="card"><h2 className="text-xl font-semibold mb-2">Payments</h2><p className="opacity-80 mb-4">Collab Payments stubs</p><div className="flex gap-3"><CollabPayButton amount={9900} label="Buy Pro (€99.00)" /><CollabPayButton amount={500} label="Top-up 500 coins" coins /></div></div>
      <div className="card"><h2 className="text-xl font-semibold mb-2">Chat</h2><p className="opacity-80 mb-4">Project channel</p><CollabChat channel={'project:demo'} /></div>
    </section></main>)
}
