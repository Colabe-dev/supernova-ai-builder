export type CollabConfig = { payApiBase:string; chatWsBase:string; chatRestBase:string; registryUrl:string; triggerBusUrl:string; jwksUrl:string; fetch?:typeof fetch; wsFactory?: (url:string)=>WebSocket }
export type PaymentIntent = { id:string; client_secret?:string; amount:number; currency:string }
export type Subscription = { id:string; plan:string; status:'active'|'trial'|'canceled' }
export type CoinTx = { id:string; delta:number; reason?:string }
