import type { CollabConfig, PaymentIntent, Subscription, CoinTx } from './types'
export function createPayments(cfg: CollabConfig){
  const f = cfg.fetch ?? fetch; const base = cfg.payApiBase.replace(/\/$/,'')
  return {
    async createIntent(amount:number, currency='EUR'):Promise<PaymentIntent>{
      const r = await f(`${base}/payments/intent`, {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({amount, currency})})
      if(!r.ok) throw new Error('pay.intent failed'); return r.json()
    },
    async createSubscription(plan:string):Promise<Subscription>{
      const r = await f(`${base}/subscriptions/create`, {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({plan})})
      if(!r.ok) throw new Error('sub.create failed'); return r.json()
    },
    async creditCoins(amount:number, reason?:string):Promise<CoinTx>{
      const r = await f(`${base}/coins/credit`, {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({amount, reason})})
      if(!r.ok) throw new Error('coins.credit failed'); return r.json()
    }
  }
}
