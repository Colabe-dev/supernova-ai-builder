import type { CollabConfig } from './types'
export type ServiceMeta = { id:string; name:string; version:string; base_url:string; caps:string[] }
export async function fetchServices(cfg: CollabConfig): Promise<ServiceMeta[]>{ const f = cfg.fetch ?? fetch; const r = await f(cfg.registryUrl); if(!r.ok) throw new Error('registry'); const {services} = await r.json(); return services }
