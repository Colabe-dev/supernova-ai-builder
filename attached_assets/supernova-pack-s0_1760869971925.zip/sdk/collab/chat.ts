import type { CollabConfig } from './types'
export function createChat(cfg: CollabConfig){
  const f = cfg.fetch ?? fetch; const rest = cfg.chatRestBase.replace(/\/$/,'')
  return {
    async history(channel:string){ const r = await f(`${rest}/channels/${encodeURIComponent(channel)}/messages`); if(!r.ok) throw new Error('chat.history failed'); return r.json() },
    connect(channel:string, onMessage:(msg:any)=>void){ const wsUrl = cfg.chatWsBase+`?channel=${encodeURIComponent(channel)}`; const ws = (cfg.wsFactory?cfg.wsFactory(wsUrl):new WebSocket(wsUrl)); ws.onmessage=e=>onMessage(JSON.parse(e.data)); return ws },
    async send(channel:string, content:string){ const r = await f(`${rest}/channels/${encodeURIComponent(channel)}/send`, {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({content})}); if(!r.ok) throw new Error('chat.send failed'); return r.json() }
  }
}
