# Supernova Builder — Pack S0 (Scaffolder, Collab Edition)
Date: 2025-10-19

Copy-pasteable scaffolder:
- `cli/` scaffolder
- `specs/` schema + example
- `sdk/collab/` TS SDK (payments, chat, registry, triggerbus)
- `templates/` Next.js (web) + Expo (mobile)
- `src/infra/supabase/` SQL + RLS
- `publish/` Vercel + EAS
- `tests/` smoke
- `docs/` SECURITY/ECOSYSTEM/INTEGRATIONS
