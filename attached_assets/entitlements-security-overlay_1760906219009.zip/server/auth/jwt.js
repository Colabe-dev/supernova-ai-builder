import jwt from 'jsonwebtoken';
const DEV_OPEN = process.env.DEV_AUTH_OPEN === 'true';

export function parseAuth(req, _res, next){
  try {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : null;
    if (!token) { if (DEV_OPEN) return next(); return next(); }
    const secret = process.env.APP_JWT_SECRET || 'dev-secret';
    req.user = jwt.verify(token, secret);
    next();
  } catch (_e) {
    next(); // don't crash; downstream will enforce
  }
}

export function requireAuth(opts = {}){
  const roles = opts.roles || [];
  return (req, res, next) => {
    if (DEV_OPEN) return next();
    const u = req.user;
    if (!u) return res.status(401).json({ error: 'unauthorized' });
    if (roles.length && !roles.some(r => (u.roles || []).includes(r))) {
      return res.status(403).json({ error: 'forbidden' });
    }
    next();
  };
}
