# S4 — Entitlements Security Overlay (RBAC + Rate Limit)

Adds JWT-based RBAC and lightweight in-memory rate limits. Secures entitlements endpoints.

## Install
```bash
npm i jsonwebtoken
```

## Env
```
APP_JWT_SECRET=<your-secret>
DEV_AUTH_OPEN=true           # allow all in dev (optional)
```

## Wire
```js
// server/index.js
import entitlementsRoutes from './entitlements/routes.db.secured.js'; // if using Postgres routes
app.use('/api', entitlementsRoutes);
```
