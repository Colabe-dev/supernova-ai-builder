import React, { useState } from 'react'
import Dev from '../pages/Dev.jsx'
import Diff from '../pages/Diff.jsx'

export default function WorkspaceTabs(){
  const [tab, setTab] = useState('project')

  return (
    <div className="workspace-tabs">
      <div className="tabbar">
        {['project','diffs','preview','usage','settings'].map(t => (
          <div key={t} className={'tab ' + (tab===t?'active':'')} onClick={()=>setTab(t)}>{t[0].toUpperCase()+t.slice(1)}</div>
        ))}
      </div>
      <div className={'content ' + (tab==='usage' || tab==='settings' ? 'scroll':'')}>
        {tab==='project' && <Dev/>}
        {tab==='diffs' && <Diff/>}
        {tab==='preview' && <iframe className="full" title="Preview" src="/" />}
        {tab==='usage' && (
          <div style={{padding:16}}>
            <h3>Usage</h3>
            <p>Coming next: tokens, tasks, credits. (Hooks: /api/usage/summary, /api/usage/series)</p>
          </div>
        )}
        {tab==='settings' && (
          <div style={{padding:16, display:'grid', gap:8}}>
            <a className="btn" href="/settings/supabase">Supabase</a>
            <a className="btn" href="/settings/referrals">Referrals</a>
            <a className="btn" href="/settings/collab">Collab Ecosystem</a>
          </div>
        )}
      </div>
    </div>
  )
}
