import React, { useEffect, useRef, useState } from 'react'

const WS_PATH = import.meta?.env?.VITE_WS_PATH || '/ws'

function wsUrl(path=WS_PATH){
  const u = new URL(path, window.location.origin)
  u.protocol = u.protocol.replace('http','ws')
  return u.toString()
}

export default function ChatEmbedded(){
  const [log, setLog] = useState([])
  const [text, setText] = useState('')
  const [autonomy, setAutonomy] = useState(false)
  const [llm, setLlm] = useState(true)
  const [model, setModel] = useState('')
  const wsRef = useRef(null)
  const logRef = useRef(null)

  useEffect(() => {
    const ws = new WebSocket(wsUrl())
    wsRef.value = ws
    ws.addEventListener('message', (e)=>{
      try{
        const m = JSON.parse(e.data)
        setLog(prev => prev.concat(m))
      }catch{}
    })
    ws.addEventListener('open', ()=> setLog(prev => prev.concat({type:'status', text:'Connected'})))
    ws.addEventListener('close', ()=> setLog(prev => prev.concat({type:'status', text:'Disconnected'})))
    return () => ws.close()
  }, [])

  useEffect(() => {
    if (!logRef.current) return
    logRef.current.scrollTop = logRef.current.scrollHeight
  }, [log])

  const send = () => {
    if (!text.trim()) return
    const payload = { type:'user', text, autonomy, llm, model }
    try { wsRef.value?.send(JSON.stringify(payload)) } catch {}
    setLog(prev => prev.concat({ type:'user', text }))
    setText('')
  }

  return (
    <div className="chat-embed">
      <div className="log" ref={logRef}>
        {log.map((m,i)=>(
          <div key={i} className={'msg ' + (m.type==='user'?'user':m.type==='tool_result'?'tool':'')}>
            <div style={{opacity:.7, fontSize:12}}>{m.type}</div>
            {m.text && <div>{m.text}</div>}
            {m.stdout && <pre style={{whiteSpace:'pre-wrap'}}>{m.stdout}</pre>}
            {m.stderr && <pre style={{whiteSpace:'pre-wrap', color:'#ffb3b3'}}>{m.stderr}</pre>}
            {m.diff && <pre style={{whiteSpace:'pre-wrap'}}>{m.diff}</pre>}
            {m.path && <div style={{opacity:.8}}>file: <code>{m.path}</code></div>}
          </div>
        ))}
      </div>
      <div className="composer">
        <div className="row">
          <label><input type="checkbox" checked={autonomy} onChange={e=>setAutonomy(e.target.checked)} /> Autonomy</label>
          <label><input type="checkbox" checked={llm} onChange={e=>setLlm(e.target.checked)} /> LLM Planner v2</label>
          <input className="input" placeholder="Model (optional, e.g. gpt-4o-mini)" value={model} onChange={e=>setModel(e.target.value)} />
        </div>
        <textarea className="input" placeholder="Describe what you want..." value={text} onChange={e=>setText(e.target.value)} />
        <div className="row">
          <button className="btn" onClick={send}>Send</button>
          <div style={{opacity:.7, fontSize:12}}>Tip: “Create a new agent & scaffold a Next.js app.”</div>
        </div>
      </div>
    </div>
  )
}
