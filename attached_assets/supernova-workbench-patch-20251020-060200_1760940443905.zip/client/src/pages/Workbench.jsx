import React, { useRef, useState } from 'react'
import '../styles/workbench.css'
import ChatEmbedded from '../components/ChatEmbedded.jsx'
import WorkspaceTabs from '../components/WorkspaceTabs.jsx'

export default function Workbench(){
  const [leftPct, setLeftPct] = useState(38)  // percent
  const dragging = useRef(false)

  const onDown = (e) => { dragging.current = true; e.preventDefault() }
  const onMove = (e) => {
    if (!dragging.current) return
    const rect = e.currentTarget.parentElement.getBoundingClientRect()
    const x = e.clientX - rect.left
    const pct = Math.max(20, Math.min(70, (x/rect.width)*100))
    setLeftPct(pct)
  }
  const onUp = ()=> dragging.current = false

  return (
    <div className="workbench" style={{gridTemplateColumns: `${leftPct}% 8px 1fr`}} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp}>
      <div className="pane">
        <ChatEmbedded/>
      </div>
      <div className="resizer" onMouseDown={onDown} />
      <div className="pane">
        <WorkspaceTabs/>
      </div>
    </div>
  )
}
