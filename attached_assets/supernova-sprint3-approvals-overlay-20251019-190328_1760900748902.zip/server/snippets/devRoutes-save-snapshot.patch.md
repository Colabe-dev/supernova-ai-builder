/* patch content from prior message */
