/* submit bar component from prior message */
