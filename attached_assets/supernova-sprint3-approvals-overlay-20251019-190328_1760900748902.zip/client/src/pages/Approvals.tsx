/* Approvals page content from prior message */
