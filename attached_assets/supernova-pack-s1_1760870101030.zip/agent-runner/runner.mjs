#!/usr/bin/env node
import fs from 'fs'; import path from 'path'; import url from 'url'
import { plan } from './src/planner.mjs'
import { implement } from './src/implementer.mjs'
import { runTests } from './src/tester.mjs'
import { proposeFixes } from './src/fixer.mjs'
const __dirname = path.dirname(url.fileURLToPath(import.meta.url))
function args(){ const a=process.argv.slice(2); const g=(k,d=null)=>{const i=a.indexOf(k); return i===-1?d:a[i+1]}; return { project: path.resolve(g('--project','./out')), mode: g('--mode','auto') } }
async function main(){ const {project,mode}=args(); fs.mkdirSync(path.join(project,'.supernova'),{recursive:true}); const rp=path.join(project,'.supernova/last-run.json')
  if(mode==='plan'||mode==='auto'){ const p=await plan(project); fs.writeFileSync(rp, JSON.stringify({plan:p},null,2)); if(mode!=='auto') return }
  if(mode==='implement'||mode==='auto'){ const out=await implement(project); const rpt=JSON.parse(fs.readFileSync(rp,'utf8')); rpt.implement=out; fs.writeFileSync(rp, JSON.stringify(rpt,null,2)); if(mode!=='auto') return }
  if(mode==='test'||mode==='auto'){ const res=await runTests(project); const rpt=JSON.parse(fs.readFileSync(rp,'utf8')); rpt.test=res; fs.writeFileSync(rp, JSON.stringify(rpt,null,2)); if(mode!=='auto') return }
  if(mode==='fix'||mode==='auto'){ const fix=await proposeFixes(project); const rpt=JSON.parse(fs.readFileSync(rp,'utf8')); rpt.fix=fix; fs.writeFileSync(rp, JSON.stringify(rpt,null,2)) }
}
main().catch(e=>{ console.error(e); process.exit(1) })
