import fs from 'fs'; import path from 'path'
function ensureFile(p,c){ fs.mkdirSync(path.dirname(p),{recursive:true}); if(!fs.existsSync(p)) fs.writeFileSync(p,c) }
export async function implement(project){ const web=path.join(project,'web-next'); const changed=[]
  if(fs.existsSync(web)){
    const page=path.join(web,'app/approvals/page.tsx'); if(!fs.existsSync(page)){ ensureFile(page,`
'use client'
import { useEffect, useState } from 'react'
export default function Approvals(){ const [items,setItems]=useState<any[]>([]); useEffect(()=>{refresh()},[]); async function refresh(){ const r=await fetch('/api/approvals'); setItems(await r.json()) } async function approve(id:string){ await fetch('/api/approvals',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,action:'approve'})}); await refresh() } return(<main className="min-h-screen p-8"><h1 className="text-2xl font-bold mb-6">Approvals</h1><div className="space-y-3">{items.length===0&&<div className="opacity-70">No pending changes.</div>}{items.map((it)=>(<div key={it.id} className="card"><div className="font-semibold">{it.title}</div><pre className="text-xs opacity-80 overflow-auto">{it.diff}</pre><button className="btn mt-2" onClick={()=>approve(it.id)}>Approve</button></div>))}</div></main>) }`); changed.push('app/approvals/page.tsx') }
    const api=path.join(web,'app/api/approvals/route.ts'); if(!fs.existsSync(api)){ ensureFile(api,`
import { NextRequest, NextResponse } from 'next/server'
type Item={id:string,title:string,diff:string,approved?:boolean}; const g:any=globalThis as any; g.__approvals=g.__approvals??[] as Item[]
export async function GET(){ return NextResponse.json((g.__approvals as Item[]).filter(i=>!i.approved)) }
export async function POST(req:NextRequest){ const {id,action,title,diff}=await req.json(); if(action==='seed'){ g.__approvals.push({id,title:title||'Proposed change',diff:diff||''}); return NextResponse.json({ok:true}) } if(action==='approve'){ const it=(g.__approvals as Item[]).find(x=>x.id===id); if(it) it.approved=true; return NextResponse.json({ok:true}) } return NextResponse.json({ok:false},{status:400}) }`); changed.push('app/api/approvals/route.ts') }
  }
  return { changed }
}
