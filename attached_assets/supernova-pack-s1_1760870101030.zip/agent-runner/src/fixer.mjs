export async function proposeFixes(){ return { proposals: [{ id: 'fix-1', title:'Autofix demo', diff:'+ Improve CTA contrast'}] } }
