export { default } from '../../../../out/web-next/app/approvals/page.tsx'
