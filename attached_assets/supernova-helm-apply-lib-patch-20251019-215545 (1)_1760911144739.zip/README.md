# Apply Library Refactor — Patch

This refactors the **supernova-server** Helm chart to use the **collab-lib** Helm library.
The library is vendored under `supernova-server/charts/collab-lib` so you can install immediately.

## Apply
1) Place the `supernova-server/` folder from this patch into your repo at the path where your chart lives (replace/merge files).
2) Build deps (no network fetch needed):
```bash
helm dependency build supernova-server
```
3) Install/upgrade as usual, e.g.:
```bash
helm upgrade --install supernova -n supernova supernova-server   -f supernova-server/values-prod.yaml   --set image.repository=ghcr.io/<org>/supernova-server   --set image.tag=<tag>
```

No values changes are required. The templates now render via the library includes.
