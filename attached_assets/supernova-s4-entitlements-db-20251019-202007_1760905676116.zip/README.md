# S4 — Entitlements DB Overlay (Postgres)

This overlay replaces the file-based entitlements with a **Postgres-backed** store, including migrations, a tiny migration runner, and Express routes.

## What you get
- `server/db/migrations/*.sql` — schema & indexes
- `server/db/migrate.mjs` — minimal migration runner
- `server/entitlements/db.js` — DB access layer (coins ledger, balances, subscriptions)
- `server/entitlements/routes.db.js` — Express routes backed by Postgres
- `server/entitlements/hmac.js` — HMAC verify (unchanged pattern)
- `docker-compose.db.yml` — local Postgres 15 + healthcheck
- `env/.env.db.sample.append` — env keys to add

## Install
```bash
npm i pg
```

## Run migrations
```bash
# Ensure DATABASE_URL is set in your environment or .env
node server/db/migrate.mjs
```

## Wire server
```js
// server/index.js
import entitlementsRoutes from './entitlements/routes.db.js';
app.use('/api', entitlementsRoutes);
```

## Tables
- `ent_coins_balance(profile_id, balance)` — integer coins balance (use smallest currency unit)
- `ent_coins_ledger(id, profile_id, amount, reason, source, external_ref, created_at)` — append-only
- `ent_subscriptions(profile_id, plan, status, started_at, renewed_at, cancelled_at, source)` — upsert per plan

> Idempotency: pass `externalRef` when crediting from IAP or webhooks; it’s unique if provided.
