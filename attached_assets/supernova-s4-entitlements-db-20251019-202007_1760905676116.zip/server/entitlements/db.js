import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function getEntitlements(profileId){
  const client = await pool.connect();
  try {
    const bal = await client.query('select balance from ent_coins_balance where profile_id=$1', [profileId]);
    const subs = await client.query('select plan, status, started_at as "startedAt", renewed_at as "renewedAt", cancelled_at as "cancelledAt", source from ent_subscriptions where profile_id=$1 and status=$2', [profileId, 'active']);
    return { coins: Number(bal.rows[0]?.balance || 0), subscriptions: subs.rows };
  } finally { client.release(); }
}

// Idempotent coin grant using optional externalRef
export async function grantCoins(profileId, amount, reason, source, externalRef){
  if (!Number.isFinite(Number(amount))) throw new Error('invalid amount');
  const client = await pool.connect();
  try {
    await client.query('begin');
    if (externalRef) {
      const ex = await client.query('select id from ent_coins_ledger where external_ref=$1', [externalRef]);
      if (ex.rowCount > 0) {
        const b = await client.query('select balance from ent_coins_balance where profile_id=$1', [profileId]);
        await client.query('commit');
        return { id: ex.rows[0].id, balance: Number(b.rows[0]?.balance || 0), duplicate: true };
      }
    }
    const ins = await client.query(
      'insert into ent_coins_ledger(profile_id, amount, reason, source, external_ref) values($1,$2,$3,$4,$5) returning id',
      [profileId, Number(amount), reason || null, source || null, externalRef || null]
    );
    const up = await client.query('update ent_coins_balance set balance = balance + $1 where profile_id=$2', [Number(amount), profileId]);
    if (up.rowCount === 0) {
      await client.query('insert into ent_coins_balance(profile_id, balance) values($1,$2)', [profileId, Number(amount)]);
    }
    const b = await client.query('select balance from ent_coins_balance where profile_id=$1', [profileId]);
    await client.query('commit');
    return { id: ins.rows[0].id, balance: Number(b.rows[0]?.balance || 0) };
  } catch (e) {
    await client.query('rollback'); throw e;
  } finally { client.release(); }
}

export async function activateSubscription(profileId, plan, source){
  const client = await pool.connect();
  try {
    const q = await client.query(`
      insert into ent_subscriptions(profile_id, plan, status, started_at, renewed_at, source)
      values ($1,$2,'active', now(), now(), $3)
      on conflict (profile_id, plan) do update
        set status='active', renewed_at=excluded.renewed_at, cancelled_at=null, source=excluded.source
      returning plan, status, started_at as "startedAt", renewed_at as "renewedAt", cancelled_at as "cancelledAt", source
    `, [profileId, plan, source || null]);
    return q.rows[0];
  } finally { client.release(); }
}

export async function cancelSubscription(profileId, plan, source){
  const client = await pool.connect();
  try {
    const q = await client.query(`
      update ent_subscriptions set status='cancelled', cancelled_at=now(), source=$3
      where profile_id=$1 and plan=$2
      returning plan, status, started_at as "startedAt", renewed_at as "renewedAt", cancelled_at as "cancelledAt", source
    `, [profileId, plan, source || null]);
    return q.rows[0] || null;
  } finally { client.release(); }
}
