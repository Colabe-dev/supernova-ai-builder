import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { Pool } from 'pg';
import 'dotenv/config';

const ROOT = process.cwd();
const MIGDIR = path.join(ROOT, 'server', 'db', 'migrations');
const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('DATABASE_URL is not set'); process.exit(1);
}

const pool = new Pool({ connectionString: DATABASE_URL });

async function ensureMigrationsTable(client){
  await client.query(`create table if not exists schema_migrations (filename text primary key, applied_at timestamptz not null default now())`);
}

async function appliedSet(client){
  const { rows } = await client.query(`select filename from schema_migrations`);
  return new Set(rows.map(r => r.filename));
}

async function applyOne(client, file){
  const sql = await fsp.readFile(path.join(MIGDIR, file), 'utf8');
  console.log('Applying', file);
  await client.query('begin');
  try {
    await client.query(sql);
    await client.query('insert into schema_migrations(filename) values($1)', [file]);
    await client.query('commit');
  } catch (e) {
    await client.query('rollback'); throw e;
  }
}

async function main(){
  const files = (await fsp.readdir(MIGDIR)).filter(f => f.endsWith('.sql')).sort();
  const client = await pool.connect();
  try {
    await ensureMigrationsTable(client);
    const done = await appliedSet(client);
    for (const f of files) {
      if (done.has(f)) continue;
      await applyOne(client, f);
    }
    console.log('Migrations complete.');
  } finally {
    client.release(); await pool.end();
  }
}
main().catch(e => { console.error(e); process.exit(1); });
