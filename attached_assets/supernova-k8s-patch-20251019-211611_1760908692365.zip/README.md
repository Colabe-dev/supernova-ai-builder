# Supernova — Kubernetes Patch (Kustomize)

This overlay ships **production-ready** manifests for the **server** app, with base Kustomize and three overlays: `dev`, `staging`, and `prod`.

## Structure
```
k8s/
  base/
    deployment.yaml
    service.yaml
    ingress.yaml
    hpa.yaml
    pdb.yaml
    networkpolicy.yaml
    configmap.env.yaml
    secret.example.yaml
    tokens.configmap.yaml
    kustomization.yaml
  overlays/
    dev/kustomization.yaml
    staging/kustomization.yaml
    prod/kustomization.yaml
```

## Quick start
```bash
# DEV (no TLS, cluster DNS only)
kubectl apply -k k8s/overlays/dev

# STAGING (ingress + TLS)
kubectl apply -k k8s/overlays/staging

# PROD (replicas + stricter limits)
kubectl apply -k k8s/overlays/prod
```

## Image
Set the image once via Kustomize (or your CI):
```
IMAGE=ghcr.io/<org>/supernova-server:<tag>
kustomize edit set image server-image=$IMAGE
```
Or override with `kubectl -k ... --enable-helm` style workflows as needed.

## Notes
- **Design tokens** are shipped via a ConfigMap and **mounted at `/app/design.tokens.json`** to match current code. Update your server later to read `DESIGN_TOKENS_PATH` if you prefer.
- **Secrets**: `secret.example.yaml` is a template; replace with your secret management (SealedSecrets/ExternalSecrets) before prod.
- **Ingress** assumes NGINX. Adjust annotations for your ingress controller (ALB, Traefik, etc.).
- **Redis/Postgres** are external; set `DATABASE_URL` and `REDIS_URL` in the Secret.
