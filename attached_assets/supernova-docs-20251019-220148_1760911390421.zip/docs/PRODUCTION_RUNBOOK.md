# Supernova — Production Runbook (Helm/Helmfile)

> Scope: `supernova-server` API (Express + Security Pro + Entitlements + IAP), deployed on Kubernetes using **Helm** or **Helmfile**.

---

## 0) TL;DR — Golden Path (Helmfile)
```bash
# Pick env: dev | staging | prod
export ENV=prod
export IMAGE_REPO=ghcr.io/<org>/supernova-server
export IMAGE_TAG=v1.0.0

cd helmfile
helmfile -e $ENV apply
```

Post-deploy smoke:
```bash
kubectl -n $ENV get pods
kubectl -n $ENV port-forward deploy/supernova-server 3001:3001 &
curl -s http://localhost:3001/healthz
curl -s http://localhost:3001/api/design/tokens
```

Rollback (to previous revision):
```bash
helm -n $ENV history supernova
helm -n $ENV rollback supernova <REVISION>
```

---

## 1) Environments & Domains
- **dev** → `api-dev.supernova.example.com`
- **staging** → `api-staging.supernova.example.com`
- **prod** → `api.supernova.example.com`

Namespace per env. One chart, values per env (`values-dev.yaml`, `values-staging.yaml`, `values-prod.yaml`).

## 2) Prerequisites
Cluster:
- NGINX Ingress or equivalent (adjust annotations).
- metrics-server (for HPA).
- Optional: ExternalDNS, cert-manager (TLS automation).
- Optional: External Secrets Operator (for secret sync).

External services:
- **Postgres**: reachable from cluster, `DATABASE_URL` configured.
- **Redis**: single/replica, Sentinel, or Cluster; set one of `REDIS_URL` / sentinel / cluster envs.
- **JWKS issuer**: `AUTH_JWKS_URL` reachable publicly.
- **Collab Pay**: `COLLAB_PAY_API_BASE` accessible from cluster.

## 3) Configuration (non-secret vs secret)
Non-secrets (ConfigMap `*-env`):
```
AUTH_ISSUER=https://collab.supernova.auth
AUTH_AUDIENCE=supernova-api
DEV_AUTH_OPEN=false
RATE_LIMIT_* (window/read/write/webhook)
SENTRY_ENV=production
NODE_ENV=production
PORT=3001
```

Secrets (Secret or ExternalSecret → Secret):
```
DATABASE_URL=postgres://user:pass@pg:5432/supernova
REDIS_URL=redis://redis:6379
SENTRY_DSN=...
AUTH_JWKS_URL=https://api.supernova.example.com/auth/.well-known/jwks.json
COLLAB_PAY_API_BASE=https://pay.collab.example.com
COLLAB_PAY_SECRET=...
COLLAB_PAY_WEBHOOK_SECRET=...
IAP_STRICT=true|false
DEV_IAP_OPEN=false
GOOGLE_SERVICE_ACCOUNT_KEY={...service account json...}
GOOGLE_PACKAGE_NAME=com.collab.supernova
APPLE_BUNDLE_ID=com.collab.supernova
IAP_USE_SANDBOX=false
APPLE_SHARED_SECRET=...
```

## 4) Deploy Options

### A) Helmfile (recommended)
```bash
export ENV=staging
export IMAGE_REPO=ghcr.io/<org>/supernova-server
export IMAGE_TAG=staging-<gitsha>
cd helmfile && helmfile -e $ENV apply
```

### B) Helm (direct)
```bash
helm upgrade --install supernova ./supernova-server   -n supernova --create-namespace   -f supernova-server/values-prod.yaml   --set image.repository=$IMAGE_REPO   --set image.tag=$IMAGE_TAG
```

## 5) Migrations
Run once per deploy when schema changes.

**Manual:**
```bash
# exec into a pod
kubectl -n $ENV exec -it deploy/supernova-server -- bash -lc 'node db/migrate.mjs'
```

**Optional Job (snippet):**
```yaml
apiVersion: batch/v1
kind: Job
metadata: { name: supernova-migrate }
spec:
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: migrate
          image: ghcr.io/<org>/supernova-server:<tag>
          envFrom:
            - configMapRef: { name: supernova-server-env }
            - secretRef: { name: supernova-server-secrets }
          command: ["node","db/migrate.mjs"]
```

## 6) Health, Probes & SLOs
- **Readiness/Liveness**: `/healthz`
- Suggested SLOs:
  - Availability: ≥ 99.9%
  - p95 latency: ≤ 250ms for GET `/api/entitlements/:profileId`
  - Error rate: ≤ 0.5% over 5m
- Alerting: 5xx rate spikes, 401/403 surges, sustained 429s, HPA at max for >10m.

## 7) Observability
- Pino structured logs → ship to your log stack.
- Sentry DSN set in secrets; release + env tags recommended.

## 8) Security Controls
- **JWT** via JWKS (`AUTH_JWKS_URL`, `iss`, `aud` match).
- **Role gating**:
  - GET `/api/entitlements/:profileId`: self or roles `admin|finance`.
  - POST `/api/entitlements/grant`: roles `admin|finance` only.
- **Rate limiting** (webhook path has a higher cap).
- **HMAC** on `/api/webhooks/collabpay` (header `x-collab-signature`).

## 9) Key Procedures
### JWKS Rotation
1) Rotate keys at issuer (`tools/gen-jwks.mjs` or your IdP).
2) Verify JWKS endpoint publishes new `kid`.
3) Deploy issuer; *no app-side change* if `AUTH_JWKS_URL` is stable.
4) Invalidate caches (CDN) ≤ 5m if used.

### Redis Outage
- Limiter falls back to in-memory *only if Redis envs unset*.
- Quick mitigation: temporarily remove `REDIS_*` envs (redeploy) → in-memory limiter (single-pod safe).

### Database Incident
- Switch to read-only mode by locking write routes (toggle feature flag if you add one) or set HPA minReplicas=0 for write workers if split.
- Restore from last snapshot; re-run `migrate.mjs` if required.

### IAP Strict Mode
1) Set `IAP_STRICT=true`, `IAP_USE_SANDBOX=false` in prod.
2) Provide `GOOGLE_SERVICE_ACCOUNT_KEY`, `APPLE_*` secrets.
3) Smoke with real receipts/tokens from store sandbox.

## 10) Post-Deploy Validation
```bash
# Health
curl -s https://<host>/healthz

# JWKS reachable
curl -s https://<host>/auth/.well-known/jwks.json | jq .

# Entitlements (authed)
curl -sH "authorization: Bearer <JWT>" https://<host>/api/entitlements/u1 | jq .

# Grant write-path (admin)
curl -sX POST https://<host>/api/entitlements/grant   -H 'authorization: Bearer <JWT>' -H 'content-type: application/json'   -d '{"profileId":"u1","grant":{"type":"coins","amount":100},"externalRef":"smoke-001"}' | jq .

# Idempotency check
(repeat same request) → should not double-credit
```

## 11) Rollback Playbook
- **Helm**: `helm -n $ENV rollback supernova <REV>`
- **Config-only revert**: restore previous Secret/ConfigMap (kubectl rollout restart deployment/supernova-server)
- **Ingress quick-off**: add `nginx.ingress.kubernetes.io/ssl-redirect: "false"` and point to maintenance or remove ingress rule temporarily.
- **Kill switch**: set `DEV_AUTH_OPEN=true` only as last resort for auth failures (flip back ASAP).

## 12) Change Management
- Use tags for prod (e.g., `v1.0.0`). Avoid deploying SHAs directly to prod.
- Keep `values-prod.yaml` drift-free; override only image tag and absolute minimum via Helmfile.
- Record deployment in CHANGELOG with commit SHAs and Helm revision.
