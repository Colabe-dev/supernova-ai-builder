# Supernova — CI/CD Guide (GitHub Actions + Helmfile)

## Overview
Two pipelines:
1) **Build & Publish Docker** → GHCR image
2) **Deploy via Helmfile** → dev/staging/prod, env chosen from branch/tag

Branch→Env mapping:
- `develop` → **dev** with `IMAGE_TAG=dev-<sha>`
- `main` → **staging** with `IMAGE_TAG=staging-<sha>`
- tags `v*` → **prod** with `IMAGE_TAG=<tag>`

## Required GitHub Secrets
- `KUBE_CONFIG_BASE64` — base64 kubeconfig for cluster access (or switch to OIDC).
- `GHCR_PAT` (optional) — PAT with `write:packages` if org’s `GITHUB_TOKEN` cannot push to GHCR.
- (If using External Secrets) your cloud secret store credentials reside **in the cluster**, not GitHub.

## Workflow: Build & Publish (`.github/workflows/docker-build-publish.yml`)
- Triggers: PRs, pushes to `develop` / `main`, and tags `v*`.
- Uses buildx with GHA cache.
- Tags:
  - `develop` → `dev-<sha>`
  - `main` → `staging-<sha>`
  - `vX.Y.Z` tag → `vX.Y.Z`

Local parity:
```bash
docker build -t ghcr.io/<org>/supernova-server:dev-$(git rev-parse --short HEAD) .
docker push ghcr.io/<org>/supernova-server:dev-$(git rev-parse --short HEAD)
```

## Workflow: Deploy Helmfile (`.github/workflows/deploy-helmfile.yml`)
- Derives ENV + IMAGE_TAG by ref type.
- Exports `IMAGE_REPO` and `IMAGE_TAG` to Helmfile.
- Runs:
```bash
cd helmfile
helmfile -e <env> apply
```

### Protected Deployments (recommended)
- Protect `main` and tag releases with **required reviews**.
- Use **Environments** in GitHub with manual approvals for `staging` and `prod` deployments.
- Optionally restrict deploy job with branch rules and environment protection rules.

## Promotions
- **Staging → Prod**: create a tag from the staging commit (e.g., `v1.0.0`). The deploy workflow detects the tag and deploys to prod using the *same image digest* tag if you enforce immutable tags.
- Immutable digests (recommended):
  - Use `docker/metadata-action` to publish digest output.
  - Pass `--set-string image.tag=@sha256:<digest>` or add `IMAGE_DIGEST` to Helmfile values to remove tag immutability risks.

## Canary & Blue/Green (option snippets)
**Nginx canary by header or weight:**
```yaml
ingress:
  annotations:
    nginx.ingress.kubernetes.io/canary: "true"
    nginx.ingress.kubernetes.io/canary-weight: "10"  # 10%
```
Deploy a second release `supernova-canary` with the canary annotations and scaled-down replicas; gradually increase weight.

**Blue/Green with separate host:**
- `api-green.supernova.example.com` routes to new release; switch DNS or Ingress after validation.

## Database Migrations in CI/CD
- Option A: Manual step post-deploy (`kubectl exec ... migrate.mjs`).
- Option B: Helm post-upgrade hook Job (add a Job template with `helm.sh/hook: post-upgrade`). Ensure idempotent migration scripts (yours are idempotent by filename).

## Observability & Alerts
- Wire Sentry release tagging:
  - Add a CI step that sets `SENTRY_RELEASE=$GITHUB_SHA` env var and injects it into the chart via values.
- Alerts to implement:
  - 5xx > 1% for 5m
  - p95 latency > 500ms for 5m
  - 429 surge vs baseline
  - pod restarts > N in 1h
  - HPA at maxReplicas for > 10m

## Security in CI
- Prefer **OIDC to cluster** (no kubeconfig secret). Grant GitHub OIDC a role to your cluster (IRSA/GKE Workload Identity).
- Restrict GHCR PAT scope; rotate quarterly.
- Never store IAP receipts/tokens in logs; redact in Actions.

## Release Checklist (Prod)
- [ ] CHANGELOG updated (features, migrations, breaking changes).
- [ ] Helm values reviewed (`values-prod.yaml`) and diffs approved.
- [ ] Image built & scanned (if using container scanning).
- [ ] Tag pushed `vX.Y.Z` → watch deploy.
- [ ] Post-deploy smoke tests (Runbook §10).
- [ ] Set SLO dashboards to release timestamp & monitor 30 minutes.
- [ ] Create rollback point (`helm -n prod history supernova` screenshot / record).

## Incident Playbooks (CI/CD)
- **Bad deploy**: `helm -n <env> rollback supernova <REV>`.
- **Secret mistake**: fix Secret (or ExternalSecret data), then `kubectl -n <env> rollout restart deploy/supernova-server`.
- **Image 404**: re-run build workflow; verify GHCR permissions; override `IMAGE_TAG` via manual Helmfile dispatch if needed.

## Appendix
- **Helm library usage**: chart already refactored to `collab-lib`. One change to library macros updates all consuming charts.
- **Mobile CI (EAS)**: managed separately; set `EAS_TOKEN` for the Expo workflow. (Out of scope for server Helmfile deploys.)
