import { callLLM } from '../../llm/provider.js'

const SYS = `You are PlannerV2 for Supernova.
Return STRICT JSON only with keys: question(optional), choices(optional), test(build|lint|test), actions[].
Each action: {kind: "edit"|"command", path?, content?, cmd?, auto?}.
Use only allowed paths: client/, server/, shared/, public/.`;

export async function plannerV2(userText){
  const messages = [
    { role:'system', content: SYS },
    { role:'user', content: userText || '' }
  ];
  const { parsed } = await callLLM(messages, { schemaJSON: true });
  if (parsed?.actions) return parsed;
  return { question:'Choose next step?', choices:[{id:'prepare-build',label:'Build project'}], test:'build', actions:[] };
}
