import { callLLM } from '../../llm/provider.js'

const SYS = `Return JSON: {"steps":["..."]}.`;
export async function explainerV2({ stdout, stderr }){
  const body = (stderr||'') + '\n' + (stdout||'');
  const { parsed } = await callLLM([{role:'system',content:SYS},{role:'user',content:body.slice(-6000)}], { schemaJSON: true });
  if (parsed?.steps?.length) return { text:'Steps:', steps: parsed.steps };
  return { text:'Steps:', steps:['Apply patch and rebuild.'] };
}
