import { callLLM } from '../../llm/provider.js'
const SYS = `Return JSON: {"actions":[{"kind":"edit","path":"client/...|server/...","content":"...","auto":true}]}`;
export async function fixerV2({ stdout, stderr }){
  const body = (stderr||'') + '\n' + (stdout||'');
  const { parsed } = await callLLM([{role:'system',content:SYS},{role:'user',content:body.slice(-6000)}], { schemaJSON: true });
  return parsed?.actions ? parsed : { actions: [] };
}
