const DEFAULTS = {
  provider: process.env.LLM_PROVIDER || 'openai',
  baseUrl: process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1',
  model: process.env.LLM_MODEL || 'gpt-4o-mini',
  temperature: parseFloat(process.env.LLM_TEMPERATURE || '0.2'),
  max_tokens: parseInt(process.env.LLM_MAX_TOKENS || '1200', 10)
};

async function doFetch(url, opts){
  if (typeof fetch !== 'function') {
    const mod = await import('node-fetch');
    return mod.default(url, opts);
  }
  return fetch(url, opts);
}

export async function callLLM(messages, options={}, overrides={}){
  const cfg = { ...DEFAULTS, ...overrides };
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error('OPENAI_API_KEY missing');

  const payload = { model: cfg.model, temperature: cfg.temperature, max_tokens: cfg.max_tokens, messages };
  const res = await doFetch(`${cfg.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { 'authorization': `Bearer ${key}`, 'content-type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(`LLM HTTP ${res.status}`);
  const j = await res.json();
  const text = j.choices?.[0]?.message?.content || '';
  let parsed = null;
  if (options.schemaJSON) { try { parsed = JSON.parse(text) } catch {} }
  return { text, parsed };
}
