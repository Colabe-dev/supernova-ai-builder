import { NextRequest, NextResponse } from 'next/server'; import fs from 'fs'; import path from 'path'
const TOK=path.join(process.cwd(),'app','design.tokens.json')
export async function GET(){ try{ return NextResponse.json(JSON.parse(fs.readFileSync(TOK,'utf8'))) }catch{ return NextResponse.json({ theme:{ primary:'#fec72e', background:'#0b1f3a', text:'#ffffff' } }) } }
export async function POST(req:NextRequest){ const body=await req.json(); fs.writeFileSync(TOK, JSON.stringify(body,null,2)); return NextResponse.json({ok:true}) }
