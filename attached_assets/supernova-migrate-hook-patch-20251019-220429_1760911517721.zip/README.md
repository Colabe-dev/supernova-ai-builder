# Supernova — Helm Migration Hook Patch

This patch adds a **Helm hook Job** that runs database migrations automatically on **post-install** and **post-upgrade**.

It supports both locations:
- `supernova-server/` (standalone chart)
- `helmfile/charts/supernova-server/` (embedded chart in Helmfile package)

## How it works
- Creates a `Job` named: `<release>-migrate-<revision>`
- Hook annotations:
  - `helm.sh/hook: post-install,post-upgrade`
  - `helm.sh/hook-weight: 10` (runs after main resources)
  - `helm.sh/hook-delete-policy: before-hook-creation,hook-succeeded`
- Uses the **app image** by default, or override via `.Values.migrations.image`.
- Inherits environment via the chart’s ConfigMap & Secret (`*-env`, `*-secrets`).

## Install (copy files)
Copy the appropriate folder from this patch into your repo, preserving paths:

- If you deploy with plain Helm:
  - Copy `supernova-server/templates/migrate-hook.yaml`
  - Optionally copy `supernova-server/values-migrations.example.yaml` into your repo as a reference.

- If you deploy with Helmfile and the embedded chart:
  - Copy `helmfile/charts/supernova-server/templates/migrate-hook.yaml`
  - Optionally copy `helmfile/charts/supernova-server/values-migrations.example.yaml`

Then deploy as usual. The hook will fire automatically on install/upgrade.

## Configuration (values)
```yaml
migrations:
  enabled: true
  when: ["post-install", "post-upgrade"]
  weight: 10
  image:
    repository: ""   # default: uses .Values.image.repository
    tag: ""          # default: uses .Values.image.tag
    pullPolicy: ""   # default: inherit chart default
  command: ["node", "db/migrate.mjs"]
  backoffLimit: 0
  activeDeadlineSeconds: 300
  ttlSecondsAfterFinished: 300
  serviceAccountName: ""  # optional
```

> If you need **pre-upgrade** instead (run before rollout), set `when: ["pre-upgrade","pre-install"]` and consider `weight: -10`. Use only if migrations must precede new pods.
