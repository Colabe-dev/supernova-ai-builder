# Collab Helm Library (collab-lib)

A **Helm library chart** with reusable templates for deployments, services, ingress, HPA, PDB, and network policies,
plus common labels, probes, and security contexts.

## Use in your app chart

1) Add as a dependency in your app's `Chart.yaml`:
```yaml
dependencies:
  - name: collab-lib
    version: 0.1.0
    repository: "file://../charts/collab-lib"   # or your OCI registry later
```

2) In your app's templates (e.g., `templates/deployment.yaml`):
```yaml
{{- include "collab.lib.deployment" (dict
  "root" .
  "name" (include "supernova.fullname" .)
  "image" (printf "%s:%s" .Values.image.repository .Values.image.tag)
  "containerPort" .Values.service.targetPort
  "envFrom" (list (dict "configMapRef" (dict "name" (printf "%s-env" (include "supernova.fullname" .)))) (dict "secretRef" (dict "name" (printf "%s-secrets" (include "supernova.fullname" .)))))
  "tokensConfigName" (printf "%s-tokens" (include "supernova.fullname" .))
  "resources" .Values.resources
  "readiness" (dict "path" "/healthz" "port" "http" "initialDelaySeconds" 5)
  "liveness"  (dict "path" "/healthz" "port" "http" "initialDelaySeconds" 10)
) ) }}

---
{{- include "collab.lib.service" (dict
  "root" .
  "name" (include "supernova.fullname" .)
  "port" .Values.service.port
) ) }}

{{- if .Values.ingress.enabled }}
---
{{- include "collab.lib.ingress" (dict
  "root" .
  "name" (include "supernova.fullname" .)
  "className" .Values.ingress.className
  "annotations" .Values.ingress.annotations
  "hosts" .Values.ingress.hosts
  "tls" .Values.ingress.tls
) ) }}
{{- end }}

{{- if .Values.autoscaling.enabled }}
---
{{- include "collab.lib.hpa" (dict
  "root" .
  "name" (include "supernova.fullname" .)
  "minReplicas" .Values.autoscaling.minReplicas
  "maxReplicas" .Values.autoscaling.maxReplicas
  "cpu" .Values.autoscaling.targetCPUUtilizationPercentage
  "memory" .Values.autoscaling.targetMemoryUtilizationPercentage
) ) }}
{{- end }}

---
{{- include "collab.lib.pdb" (dict "root" . "name" (include "supernova.fullname" .) "minAvailable" .Values.pdb.minAvailable ) }}

{{- if .Values.networkPolicy.enabled }}
---
{{- include "collab.lib.networkPolicy" (dict
  "root" .
  "name" (printf "%s-deny-by-default" (include "supernova.fullname" .))
  "ingressPort" .Values.service.port
  "allowIngressNamespaces" .Values.networkPolicy.allowIngressNamespaces
  "allowEgressCidrs" .Values.networkPolicy.allowEgressCidrs
  "allowEgressPorts" .Values.networkPolicy.allowEgressPorts
) ) }}
{{- end }}
```

3) Package the library and push to OCI (optional):
```bash
helm package charts/collab-lib
helm push collab-lib-0.1.0.tgz oci://ghcr.io/<org>/helm
```

See `examples/supernova-server-consumer` for a minimal consumer chart.
