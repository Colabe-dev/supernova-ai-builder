import { supabaseAdmin as s } from '../integrations/supabase.js'

export async function processCollabEvent({ eventId, type, data }){
  if (!s) throw new Error('supabase not configured')

  // idempotency by eventId
  const { error: rerr } = await s.from('webhook_receipts')
    .upsert({ id: String(eventId) }, { onConflict: 'id', ignoreDuplicates: true })
  if (rerr && !String(rerr.message||rerr).includes('duplicate')) throw rerr

  // ledger
  const amount = data.amount_usd != null ? Number(data.amount_usd)
             : data.amount_cents != null ? Number(data.amount_cents)/100
             : data.amount != null ? Number(data.amount)
             : null
  const row = {
    id: String(eventId),
    customer_id: data.customer_id || data.user_id || null,
    amount_usd: amount,
    currency: (data.currency || 'USD').toUpperCase(),
    product: data.product || data.plan || null,
    meta: data
  }
  const { error: lerr } = await s.from('payments_ledger').upsert(row, { onConflict: 'id', ignoreDuplicates: true })
  if (lerr && !String(lerr.message||lerr).includes('duplicate')) throw lerr

  // referral
  const ref = data.metadata?.ref_code || data.metadata?.ref || data.metadata?.affiliate || null
  if (ref && (String(type).toLowerCase().includes('payment') || String(type).toLowerCase().includes('purchase') || String(type).toLowerCase().includes('subscription'))) {
    const { error: ferr } = await s.from('referrals_events').insert({
      code: String(ref).toUpperCase(),
      event_type: 'purchase',
      amount_usd: amount,
      customer_id: row.customer_id,
      meta: data
    })
    if (ferr) throw ferr
  }
}
