import crypto from 'crypto'
import { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { processCollabEvent } from './processor.js'
import { supabaseAdmin as s } from '../integrations/supabase.js'

const r = Router()
const limiter = rateLimit({
  windowMs: 60_000,
  limit: parseInt(process.env.RATE_LIMIT_WEBHOOK_MAX || '1200', 10)
})
r.use('/api/webhooks/', limiter)

function safeEq(a, b) {
  const A = Buffer.from(a || '', 'utf8')
  const B = Buffer.from(b || '', 'utf8')
  if (A.length !== B.length) return false
  return crypto.timingSafeEqual(A, B)
}

function expectedSignature(secret, timestamp, raw) {
  const toSign = `${timestamp}.${raw.toString('utf8')}`
  return crypto.createHmac('sha256', secret).update(toSign).digest('hex')
}

function parseV1(sigHeader) {
  if (!sigHeader) return null
  const s = String(sigHeader)
  if (s.startsWith('v1=')) return s.slice(3)
  return s
}

async function enqueueDLQ(reason, headers, payload, last_error) {
  if (!s) return
  await s.from('webhook_dead_letters').insert({
    event_id: headers['x-collab-id'] || null,
    reason, headers, payload,
    attempts: 0,
    next_attempt_at: new Date().toISOString(),
    last_error: last_error ? String(last_error) : null
  })
}

r.post('/api/webhooks/collab-pay', async (req, res) => {
  const secret = process.env.COLLAB_PAY_WEBHOOK_SECRET
  if (!secret) return res.status(503).json({ ok:false, error:'COLLAB_PAY_WEBHOOK_SECRET not set' })

  const id = String(req.headers['x-collab-id'] || '').trim()
  const ts = parseInt(String(req.headers['x-collab-timestamp'] || '0'), 10)
  const now = Math.floor(Date.now() / 1000)
  const skew = parseInt(process.env.WEBHOOK_MAX_SKEW_SEC || '300', 10)
  const sig = parseV1(req.headers['x-collab-signature'])

  if (!id || !ts || !sig) {
    await enqueueDLQ('missing_headers', req.headers, req.body, 'Missing id/timestamp/signature')
    return res.status(400).json({ ok:false, error:'missing headers' })
  }
  if (Math.abs(now - ts) > skew) {
    await enqueueDLQ('timestamp_out_of_window', req.headers, req.body, `now=${now} ts=${ts} skew=${skew}`)
    return res.status(401).json({ ok:false, error:'timestamp out of tolerance' })
  }
  const raw = req.rawBody
  if (!raw) {
    await enqueueDLQ('raw_body_missing', req.headers, req.body, null)
    return res.status(400).json({ ok:false, error:'raw body missing' })
  }
  const exp = expectedSignature(secret, ts, raw)
  if (!safeEq(sig, exp)) {
    await enqueueDLQ('bad_signature', req.headers, req.body, 'signature mismatch')
    return res.status(401).json({ ok:false, error:'bad signature' })
  }

  // process async; reply fast
  ;(async () => {
    try {
      const evt = req.body || {}
      const type = evt.type || 'payment.unknown'
      const data = evt.data || {}
      await processCollabEvent({ eventId: id, type, data })
    } catch (e) {
      await enqueueDLQ('processing_error', req.headers, req.body, e.message || String(e))
    }
  })()

  res.json({ ok:true })
})

// Protected DLQ processor (HTTP-triggered)
r.get('/api/webhooks/dlq/process', async (req, res) => {
  try {
    if (!s) return res.status(503).json({ ok:false, error:'supabase not configured' })
    const token = req.query.token
    if (!token || token !== process.env.WEBHOOK_DLQ_TOKEN) return res.status(401).json({ ok:false, error:'unauthorized' })

    const nowIso = new Date().toISOString()
    const { data: jobs, error } = await s
      .from('webhook_dead_letters')
      .select('*')
      .lte('next_attempt_at', nowIso)
      .order('next_attempt_at', { ascending: true })
      .limit(25)

    if (error) throw error
    let ok=0, fail=0
    for (const j of (jobs||[])) {
      try {
        const evt = j.payload || {}
        const id = j.event_id || evt.id || `dlq_${j.id}`
        await processCollabEvent({ eventId: id, type: evt.type || 'dlq.retry', data: evt.data || {} })
        // delete on success
        await s.from('webhook_dead_letters').delete().eq('id', j.id)
        ok++
      } catch (e) {
        const attempts = (j.attempts || 0) + 1
        const delay = Math.min(3600, 2 ** attempts) // 1s,2s,4s,... capped at 1h
        const next = new Date(Date.now() + delay*1000).toISOString()
        await s.from('webhook_dead_letters').update({
          attempts, next_attempt_at: next, last_error: e.message || String(e)
        }).eq('id', j.id)
        fail++
      }
    }
    res.json({ ok:true, processed: ok, failed: fail })
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message || String(e) })
  }
})

export default r
