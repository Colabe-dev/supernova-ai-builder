import 'dotenv/config'
import fetch from 'node-fetch'

const url = process.env.DLQ_PROCESS_URL || `http://localhost:${process.env.PORT||3001}/api/webhooks/dlq/process?token=${process.env.WEBHOOK_DLQ_TOKEN}`

async function main(){
  const r = await fetch(url)
  const t = await r.text()
  console.log('[dlq-worker]', r.status, t)
}
main().catch(e => { console.error(e); process.exit(1) })
