# Supernova — Hardened Webhooks
Date: 20251020-002250

This patch upgrades the Collab Pay webhook integration with:
- **Signature timestamp tolerance** (`x-collab-timestamp`, default ±300s).
- **HMAC v1** signature over `"{timestamp}.{rawBody}"` with header `x-collab-signature: v1=<hex>`.
- **Replay protection** using `webhook_receipts` (event id) plus timestamp window.
- **Dead Letter Queue (DLQ)** table with exponential backoff.
- **Worker** (`server/scripts/webhook-dlq-worker.mjs`) and **protected endpoint** (`/api/webhooks/dlq/process?token=...`).

## Env
Set in `server/.env` or Helm:
```
COLLAB_PAY_WEBHOOK_SECRET=...
WEBHOOK_MAX_SKEW_SEC=300
WEBHOOK_DLQ_TOKEN=some-long-random-token
```
(If `WEBHOOK_MAX_SKEW_SEC` not set, defaults to 300 seconds.)

## Apply
1) Unzip over your repo.
2) Run SQL in Supabase: `sql/collab_webhooks_harden.sql`
3) Restart server.
4) (Optional) run worker: `node server/scripts/webhook-dlq-worker.mjs` or call `GET /api/webhooks/dlq/process?token=$WEBHOOK_DLQ_TOKEN`.

**Webhook headers required:**
- `x-collab-id`: unique event id (string)
- `x-collab-timestamp`: unix seconds (UTC)
- `x-collab-signature`: `v1=<hex>` where hex = HMAC_SHA256( secret, "{timestamp}.{rawBody}" )
- `content-type: application/json`
