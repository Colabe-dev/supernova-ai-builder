-- Receipts include processed_at (already), ensure table exists
create table if not exists public.webhook_receipts (
  id text primary key,
  processed_at timestamptz default now()
);

-- DLQ for failed webhooks
create table if not exists public.webhook_dead_letters (
  id bigserial primary key,
  event_id text,
  reason text,
  headers jsonb,
  payload jsonb,
  attempts int default 0,
  next_attempt_at timestamptz default now(),
  last_error text,
  received_at timestamptz default now()
);

create index if not exists webhook_dead_letters_sched_idx on public.webhook_dead_letters (next_attempt_at asc);
